---
name: base-dataset-demo
description: Thiết lập và dựng dữ liệu cho app BASE DATASET (dataset.base.com.vn) — kho dữ liệu dạng bảng của Base. Dùng khi user nói - setup Dataset, tạo bảng dữ liệu trên Base, dựng danh mục vật tư/nhà cung cấp/sản phẩm/khách hàng, bơm dữ liệu hàng loạt vào Dataset, làm demo Dataset cho khách, tạo liên kết hai chiều giữa các bảng, dọn dataset cũ. Chứa bản đồ 28 loại field, toàn bộ REST API đã kiểm chứng, các lỗi im lặng (ngày ra 1970, option id bị cắt 32 ký tự, record/update trả 500) kèm cách xử lý, bộ dữ liệu mẫu ngành cơ khí và checklist nghiệm thu.
---

# Base Dataset — dựng cấu trúc và dữ liệu

App: `https://dataset.base.com.vn` · Mở dataset: `/dataset/<dataset_id>`

**Nguyên tắc số 1: dùng REST API qua `javascript_tool`, không click chuột để nhập liệu.**
Nhập 400 bản ghi bằng UI mất hàng giờ và dính đủ lỗi toạ độ trôi; qua API mất ~15 phút.
Chỉ dùng UI để khảo sát menu và để nghiệm thu bằng mắt.

---

## 1. Bootstrap (chạy lại sau MỖI lần navigate / F5)

Điều hướng trang xoá sạch `window.__*`. Trước mỗi loạt call, kiểm tra `typeof __api`;
nếu `undefined` thì dán lại **Phụ lục A** ở cuối file này.

Bootstrap cung cấp: `__api` (tự lấy lại CSRF khi xoay vòng), `__mkds`, `__addlinks`,
`__idx`, `__lk`, `__rows`, `__D`, `__fixdates`, `__relabel`.

`__B` (map key → {id, f, t, links, r}) được lưu trong `localStorage` nên sống sót qua F5.

---

## 2. Anatomy

### Điều hướng
Home · Apps · Datasets · Databases · FOLDERS · DATABASES · Templates · Settings

### Toolbar dataset
Add record | Fields | Filter | Group | Sort | Colour | Height
View tabs: Grid · Gallery · Kanban · (+)

### Dataset settings (5 pane)
General info · Accesses & visibility · Manage fields · Manage views · AI grounding

### 3 scope field
| Scope | Ý nghĩa | Tạo bằng |
|---|---|---|
| Global Field | dùng chung toàn tenant | UI |
| Service Field | scope `servicemodel`, mặc định của API | `/api/field/create` |
| Internal Field | chỉ thuộc dataset này; **bắt buộc** cho link 2 chiều | `/api/service/update-input-model` |

### 28 loại field (menu New Field)
Two-way link dataset record · Text · Long Text · Integer · Decimal · Date · Date & Time ·
Time · Checkbox · Dropdown · Multi-Select · File · Files · Rich Text · Formula · Lines ·
Rating · User · Table · Email · URL · Phone · Currency · Message · Progress · Users ·
Two-way link rollup · Two-way link lookup

Mã type dùng trong API:
`text` `textarea`(Long Text) `editor`(Rich Text) `int` `float` `date` `datetime` `checkbox`
`select`(Dropdown) `select-m`(Multi-Select) `file` `files` `lines` `rating` `user` `table`
`email` `url` `phone` `currency` `message` `progress` `internal-link-record`(Two-way link)

---

## 3. Bảng tham chiếu API

Mọi call là `POST` + header `X-CSRF-Token` (lấy từ `GET /auth/me` → `csrfToken`).

| Endpoint | Body | Ghi chú |
|---|---|---|
| `/api/dataset/list` | `{}` | |
| `/api/dataset/create` | `{name,icon,color,folder_id}` | icon = tên lucide: Table2, Truck, Package, Cog, Users, Warehouse, Layers, Tag, Wallet, Ruler, GitBranch, HardHat, FileText, Building2, Network, ShoppingCart |
| `/api/dataset/info` | `{id}` | trả `input_model{field_ids,field_config,internal_fields}` |
| `/api/dataset/fields` | `{id}` | field đã gắn + `_name` (primary) |
| `/api/dataset/attach-field` | `{id,field_id}` | |
| `/api/dataset/remove` | `{id}` | lỗi nếu còn record |
| `/api/dataset/sync-internal-link-reverses` | `{id}` | tạo back-link ở dataset đích |
| `/api/field/create` | `{dataset_id,name,code,type}` | `data` bị bỏ qua ở bước này |
| `/api/field/update` | `{id,dataset_id,name,type,data}` | set options / format |
| `/api/field/list-all` | `{}` | mọi field toàn tenant |
| `/api/service/update-input-model` | `{id,input_model}` | **cách duy nhất** tạo link 2 chiều |
| `/api/record/create` | `{dataset_id,name,cfields:[{id,value,type}]}` | |
| `/api/record/list` | `{dataset_id}` | |
| `/api/record/batch-remove` | `{dataset_id,ids:[…]}` | |
| `/api/record/update` | — | **HỎNG, luôn 500** → xoá và tạo lại |
| `/api/folder/create` / `/api/folder/remove` | `{name}` / `{id}` | |
| `/api/view/list` `create` `update` `remove` | xem §6 | |

### Định dạng `cfields[].value`
| type | value |
|---|---|
| text, textarea, editor, email, url, phone | string |
| int, float, currency, progress, rating | number |
| checkbox | true / false |
| **date, datetime** | **UNIX epoch giây** — `Date.UTC(y,m-1,d)/1000` |
| select | `id` của option |
| select-m | mảng `id` |
| user | user_id (number) |
| internal-link-record | `[{id,name,dataset_id}]` |

---

## 4. QUIRKS — đọc trước khi gõ dòng đầu tiên

**Đây là phần đắt giá nhất của skill này. Bỏ qua là mất vài giờ làm lại.**

1. **Ngày phải là epoch giây.** API nhận chuỗi `"2026-03-04"` không báo lỗi, trả về nguyên
   vẹn, nhưng grid hiển thị **Jan 1, 1970**. Đây là lỗi im lặng nguy hiểm nhất.
   Dùng `__D('2026-03-04')`. Nếu lỡ nhập sai: `__fixdates(key)`.
2. **`option.id` bị cắt còn 32 ký tự.** Giữ nhãn option ≤ 32 ký tự.
3. **Kanban lấy `option.id` làm tiêu đề cột**, không lấy `name`.
   → **Luôn đặt `option.id = option.name`** (tiếng Việt có dấu, có màu) ngay từ lúc tạo field.
   Không đặt id kiểu `chienluoc`, `hoanthanh` — cột kanban sẽ hiện chữ code.
   Lỡ đặt rồi: `__relabel(key)` đổi id thành name và ghi lại toàn bộ bản ghi.
4. **Card kanban render thô**: date ra số epoch, user ra user_id, link ra `[object Object]`.
   → chỉ bật `kanbanCardVisibility` cho field `text`/`textarea`.
5. `data.options` bị bỏ qua ở `/api/field/create` → phải gọi thêm `/api/field/update`.
6. Link 2 chiều không tạo được bằng `/api/field/create`
   (lỗi *"must be created as internal fields"*) → xem §5.
7. **Field tạo qua API không tự gắn vào grid.** Và nếu một call trong chuỗi tạo dataset
   thất bại (thường do CSRF xoay vòng) thì `field_ids` rỗng mà **không có thông báo nào**.
   → Luôn nghiệm thu `input_model.field_ids.length === số field khai báo`.
8. `/api/record/update` trả `Internal server error` với mọi biến thể payload.
   Muốn sửa: đọc `cfields` → `batch-remove` → `record/create` lại.
9. **CSRF token xoay vòng giữa phiên.** Bọc `__api` bằng retry: gặp `{code:'csrf_mismatch'}`
   thì lấy token mới rồi gọi lại. Không có retry sẽ mất bản ghi giữa chừng.
10. Khi xoá-rồi-tạo-lại hàng loạt: **snapshot payload vào localStorage TRƯỚC khi xoá**,
    và đếm lại sau khi tạo. Đã có lần mất 8/30 bản ghi vì token hết hạn giữa vòng lặp.
11. `javascript_tool` báo *"Tool failed in the extension"* khi biểu thức ném lỗi —
    thường do `__api` undefined sau reload. Kiểm tra `typeof __api` trước khi chẩn đoán.
12. Dataset vừa tạo qua API chưa click được từ danh sách (client cache `/auth/me` cũ)
    → F5 hoặc mở thẳng `/dataset/<id>`.
13. `/service/<id>` redirect về Home. Đường đúng là `/dataset/<id>`.
14. Không xoá được dataset còn record → `batch-remove` trước.
15. `javascript_tool` chặn output trông giống cookie/query-string → trả về số đếm và mã lỗi,
    đừng dump JSON lớn.

---

## 5. Luồng dựng chuẩn

```
folder/create                      # nhóm dataset theo phân hệ
  → dataset/create
  → field/create × N               # ĐẶT CODE BẰNG TAY, không để auto
  → field/update                   # chỉ field có options / format
  → service/update-input-model      # field_ids + field_config → thứ tự cột
  → service/update-input-model      # internal_fields = link 2 chiều
  → dataset/sync-internal-link-reverses
  → __idx(dataset đích)             # map tên → id trước khi tạo link
  → record/create × M
  → view/update (sorts) + view/create (kanban)
  → NGHIỆM THU §7
```

Thứ tự bắt buộc: **link tạo sau khi cả hai dataset đã tồn tại**; **bản ghi tạo sau khi
đã `__idx` dataset đích**, nếu không link sẽ rỗng.

### Cấu trúc một internal link field
```js
{id:'int_1',code:'int_1',fls:0,name:'Nhà cung cấp',type:'internal-link-record',
 vtype:'string',config:{},attrs:{forms:1,views:1,required:0,important:0},
 data:{auto:false,multiple:false,dataset_id:<TARGET>,linked_field_id:'int_1',
       source_dataset_id:<SELF>,view_condition:'',validation_condition:'',
       view_condition_enabled:false,validation_condition_enabled:false}}
```
`id` phải là `int_1`, `int_2`, … theo thứ tự. Nhớ push vào `field_ids` và `field_config`.
Helper: `__addlinks('VT',[['Nhà cung cấp chính','NCC',false,'ncc'],
                          ['Nhà cung cấp thay thế','NCC',true,'ncc2']])`
(tham số: nhãn, key dataset đích, cho phép nhiều, code dùng khi nhập liệu).

---

## 6. View config

Keys: `sorts` `groups` `filters` `rowHeight` `decorators` `columnOrder` `frozenCount`
`wrapHeaders` `columnSizing` `kanbanCardWrap` `columnSummarize` `kanbanCardOrder`
`kanbanHideEmpty` `columnVisibility` `galleryCardOrder` `kanbanImageFieldId`
`kanbanStackFieldId` `kanbanCardVisibility` `galleryCardVisibility`

- **Sort mặc định** (nên đặt cho mọi dataset, nếu không bản ghi xếp theo thứ tự tạo):
  `view/update {id, dataset_id, config:{...cfg, sorts:[{fieldId:<id>, dir:'asc'}]}}`
  Danh mục → sort theo mã tăng dần. Chứng từ → sort theo ngày giảm dần.
- **Kanban**: `view/create {dataset_id,name:'Theo trạng thái',metatype:'kanban'}` rồi
  `view/update` với `kanbanStackFieldId:<id field select>`, `kanbanHideEmpty:false`,
  và `kanbanCardVisibility` chỉ bật 1–2 field text.

---

## 7. Checklist nghiệm thu (chạy bằng script, không tin toast)

```
[ ] input_model.field_ids.length === số field khai báo, với TỪNG dataset
[ ] 100% giá trị date/datetime là number (không còn chuỗi ISO)
[ ] 100% giá trị select/select-m nằm trong tập option.id hiện tại
[ ] 100% phần tử internal-link có .id (không có link gãy)
[ ] Phép tính khớp: đơn giá × số lượng = thành tiền; VAT đúng suất; tổng = trước thuế + thuế;
    tồn cuối = tồn đầu + nhập − xuất; giá trị tồn = tồn cuối × đơn giá; thực chi ≤ ngân sách
[ ] Không còn từ khoá: demo / test / thử / mẫu / abc / xxx / lorem / Nguyễn Văn A / Công ty ABC
[ ] Mọi field đã gắn đều có ít nhất một bản ghi có dữ liệu (emptyFields = 0)
[ ] Mở BẰNG MẮT ít nhất 3 dataset + 1 kanban: ngày không phải 1970, cột kanban là tiếng Việt
```
Script sẵn: **Phụ lục C** ở cuối file này.

**Rà mùi demo** — chụp list view rồi tự hỏi *"nếu đây là ảnh chụp hệ thống của một khách
hàng đang dùng, mình có tin không?"*. Chỗ nào gợn là chỗ phải sửa.

---

## 8. Chuẩn dữ liệu "công ty thật"

- Số tiền phải lẻ: `47.850.000`, `1.275.000` — không bao giờ `50.000.000`.
- Mọi phép cộng nhân phải khớp; người xem demo hay bấm máy tính đúng chỗ VAT và tổng cộng.
- Ngày trải 3–6 tháng gần nhất, không dồn vào ngày dựng tenant. Tránh Chủ nhật/lễ.
- Trạng thái đa dạng: ~60% hoàn thành · ~25% đang chạy ở các bước khác nhau ·
  ~10% bị từ chối/trả lại **kèm lý do nghiệp vụ thật** · ~5% quá hạn.
  Một chứng từ bị trả rồi trình lại là "vàng" khi demo.
- Ghi chú và ý kiến duyệt viết bằng giọng công sở thật, cụ thể, có số liệu —
  không phải "Đã xử lý" hay "Approved".
- Tên file đính kèm như người thật đặt: `BaoGia_MinhLong_20260812.pdf`.
- Mã số thuế 10 chữ số đúng đầu tỉnh (Đồng Nai 3603…, Bình Dương 3702…, TP.HCM 031…,
  Long An 1101…). Địa chỉ tới cấp phường/xã có thật. Điện thoại đúng đầu số vùng/nhà mạng.
- Không dùng tên doanh nghiệp có thật để gán số liệu bịa — đặt tên na ná ngành là đủ.
- Không gán dữ liệu nhạy cảm (lương, kỷ luật, đánh giá kém) cho tên người thật trong tenant.
- Danh từ riêng phải trùng khớp ở mọi nơi xuất hiện. Tra bảng danh mục dùng chung
  trước khi gõ tên mới.

---

## 9. Bộ 15 bảng chuẩn cho doanh nghiệp sản xuất

Script dựng sẵn 15 bảng: **Phụ lục B**. Dữ liệu mẫu, demo cast và mạch chuyện: **Phụ lục D**.

| Folder | Dataset |
|---|---|
| Danh mục nền | Danh mục phòng ban và trung tâm chi phí · Danh mục đơn vị tính và quy đổi · Danh mục khoản mục chi phí |
| Mua hàng – Vật tư | Danh mục nhà cung cấp · Danh mục vật tư – hàng hoá · Bảng giá mua theo nhà cung cấp · Đơn đặt hàng mua |
| Bán hàng – Khách hàng | Danh mục khách hàng · Danh mục sản phẩm · Đơn hàng bán và hợp đồng |
| Kho – Sản xuất | Danh mục kho và vị trí lưu trữ · Thẻ kho – Tồn kho theo vật tư · Định mức nguyên vật liệu (BOM) |
| Nhân sự – Tài sản | Danh mục nhân sự · Danh mục tài sản và thiết bị |

Sơ đồ liên kết:
```
Vật tư ──┬─► Nhà cung cấp (chính, thay thế)
         │
Bảng giá ─┴─► Nhà cung cấp        Đơn mua ──► Nhà cung cấp + Vật tư (n)
Thẻ kho  ───► Vật tư + Kho        Đơn bán ──► Khách hàng + Sản phẩm (n)
BOM      ───► Sản phẩm + Vật tư   Sản phẩm ─► Khách hàng chủ lực
Nhân sự  ───► Phòng ban           Tài sản ──► Phòng ban + Kho
```

Cách xây mạch chuyện (bắt buộc để demo không rời rạc): chọn 1 đơn hàng bán lớn, truy ngược
BOM → tồn kho thiếu → đơn mua → gia công thuê ngoài → giao hàng. Thêm 1 nhánh đơn mua
bị từ chối rồi trình lại, và 1 lô hàng bị khách trả kèm báo cáo khắc phục.

---
---

# PHỤ LỤC A — bootstrap.js

Dán TOÀN BỘ khối dưới đây vào `javascript_tool` sau mỗi lần navigate/F5.
Kiểm tra trước bằng `typeof __api` — nếu `'undefined'` thì dán lại.

```js
/* Base Dataset — bootstrap cho javascript_tool (Claude in Chrome).
   Dán TOÀN BỘ file này vào javascript_tool sau mỗi lần navigate/F5.
   Kiểm tra trước bằng: typeof __api   -> nếu 'undefined' thì dán lại. */

window.__tok = (await (await fetch('/auth/me')).json()).csrfToken;

window.__api0 = async (p, b) => {
  const r = await fetch(p, {method:'POST',
    headers:{'Content-Type':'application/json','X-CSRF-Token':window.__tok},
    body: JSON.stringify(b||{})});
  const t = await r.text();
  try { return JSON.parse(t) } catch(e) { return {raw:t.slice(0,300), status:r.status} }
};

/* CSRF token xoay vòng giữa phiên -> luôn retry */
window.__api = async (p, b) => {
  for (let i=0;i<4;i++){
    const r = await __api0(p,b);
    if (r && r.code === 'csrf_mismatch'){
      window.__tok = (await (await fetch('/auth/me')).json()).csrfToken;
      continue;
    }
    return r;
  }
  return {message:'csrf_retry_exhausted'};
};

window.__B = JSON.parse(localStorage.getItem('__B')||'{}');
window.__F = JSON.parse(localStorage.getItem('__F')||'{}');
window.__save = () => localStorage.setItem('__B', JSON.stringify(window.__B));

/* ngày -> epoch giây (BẮT BUỘC, chuỗi ISO sẽ hiển thị Jan 1 1970) */
window.__D = (s) => { const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(s); return Date.UTC(+m[1],+m[2]-1,+m[3])/1000; };

/* helper tạo options: option.id PHẢI bằng option.name (kanban dùng id làm tiêu đề cột),
   và name phải <= 32 ký tự (server cắt id ở 32). */
window.__C = (arr) => arr.map(x => {
  if (x[0].length > 32) throw new Error('Option name > 32 ký tự: '+x[0]);
  return {id:x[0], name:x[0], color:x[1]||''};
});

/* tạo dataset + field + gắn vào grid.
   fields: [[label, code, type, dataOrNull], ...] */
window.__mkds = async (key, name, icon, color, folder_id, fields) => {
  const d = (await __api('/api/dataset/create',{name,icon,color,folder_id})).dataset;
  const map={}, types={}, ids=[], cfg={};
  for (const f of fields){
    const r = await __api('/api/field/create',{dataset_id:d.id,name:f[0],code:f[1],type:f[2]});
    const id = r.field.id; map[f[1]]=id; types[f[1]]=f[2]; ids.push(id); cfg[id]={visible:true};
    if (f[3]) await __api('/api/field/update',{id,dataset_id:d.id,name:f[0],type:f[2],data:f[3]});
  }
  await __api('/api/service/update-input-model',{id:d.id,input_model:{field_ids:ids,field_config:cfg}});
  __B[key]={id:d.id,f:map,t:types,links:{}}; __save();
  const chk=(await __api('/api/dataset/info',{id:d.id})).dataset.input_model.field_ids.length;
  if (chk!==ids.length) return 'MISMATCH '+chk+'/'+ids.length+' — chạy lại update-input-model';
  return d.id;
};

/* link 2 chiều. L: [[label, targetKey, multiple, code], ...] */
window.__addlinks = async (key, L) => {
  const b=__B[key];
  const info=(await __api('/api/dataset/info',{id:b.id})).dataset;
  const im=JSON.parse(JSON.stringify(info.input_model));
  im.internal_fields = im.internal_fields||[];
  let n = im.internal_fields.length;
  for (const x of L){
    n++; const fid='int_'+n;
    im.internal_fields.push({id:fid,code:fid,fls:0,name:x[0],type:'internal-link-record',
      vtype:'string',config:{},attrs:{forms:1,views:1,required:0,important:0},
      data:{auto:false,multiple:!!x[2],dataset_id:__B[x[1]].id,linked_field_id:fid,
            source_dataset_id:b.id,view_condition:'',validation_condition:'',
            view_condition_enabled:false,validation_condition_enabled:false}});
    im.field_ids.push(fid); im.field_config[fid]={visible:true};
    b.links[x[3]]=fid; b.t[x[3]]='internal-link-record';
  }
  const r = await __api('/api/service/update-input-model',{id:b.id,input_model:im});
  await __api('/api/dataset/sync-internal-link-reverses',{id:b.id});
  __save(); return !!r.success;
};

/* map tên bản ghi -> id, chạy TRƯỚC khi tạo bản ghi có link tới dataset này */
window.__idx = async (key) => {
  const r = await __api('/api/record/list',{dataset_id:__B[key].id});
  const m={}; (r.records||[]).forEach(x=>m[x.name]=x.id);
  __B[key].r=m; __save(); return Object.keys(m).length;
};
window.__lk = (key,names) => {
  const b=__B[key];
  return (Array.isArray(names)?names:[names]).map(n=>{
    if(!b.r[n]) throw new Error('Không tìm thấy bản ghi "'+n+'" trong '+key);
    return {id:b.r[n],name:n,dataset_id:b.id};
  });
};

/* rows: [[Name, v1, v2, ...], ...] khớp thứ tự `codes` */
window.__rows = async (key, codes, rows) => {
  const b=__B[key]; let ok=0, fail=[];
  for (const r of rows){
    const cf=[];
    codes.forEach((c,i)=>{ const v=r[i+1];
      if(v===null||v===undefined||v==='') return;
      cf.push({id:b.f[c]||b.links[c]||c, value:v, type:b.t[c]||'text'});});
    const res=await __api('/api/record/create',{dataset_id:b.id,name:r[0],cfields:cf});
    if(res.success) ok++; else fail.push(r[0]);
  }
  for (const nm of fail.slice()){
    const r=rows.find(x=>x[0]===nm); const cf=[];
    codes.forEach((c,i)=>{const v=r[i+1]; if(v===null||v===undefined||v==='')return;
      cf.push({id:b.f[c]||b.links[c]||c,value:v,type:b.t[c]||'text'});});
    const res=await __api('/api/record/create',{dataset_id:b.id,name:nm,cfields:cf});
    if(res.success){ok++; fail=fail.filter(x=>x!==nm);}
  }
  return 'ok='+ok+'/'+rows.length+(fail.length?' FAIL='+fail.join(','):'');
};

/* CỨU HỘ 1 — đổi ngày chuỗi ISO thành epoch (khi lỡ nhập sai) */
window.__fixdates = async (key) => {
  const b=__B[key];
  const r=await __api('/api/record/list',{dataset_id:b.id});
  const conv=(v)=>{const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(v);return m?Date.UTC(+m[1],+m[2]-1,+m[3])/1000:v;};
  const payload=(r.records||[]).map(rec=>({name:rec.name,cfields:rec.cfields.map(c=>
    ({id:c.id,type:c.type,value:(c.type==='date'||c.type==='datetime')?conv(c.value):c.value}))}));
  localStorage.setItem('__snap_'+key,JSON.stringify(payload));   // snapshot TRƯỚC khi xoá
  const ids=(r.records||[]).map(x=>x.id);
  await __api('/api/record/batch-remove',{dataset_id:b.id,ids,record_ids:ids});
  return await __restore(key,payload);
};

/* CỨU HỘ 2 — đổi option.id thành option.name (cho kanban đọc được) */
window.__relabel = async (key) => {
  const b=__B[key];
  const fr=await __api('/api/dataset/fields',{id:b.id});
  const sel=(fr.fields||[]).filter(f=>(f.type==='select'||f.type==='select-m')&&f.data&&f.data.options&&f.data.options.length);
  const maps={}; const dup=[];
  for (const f of sel){ const m={}, seen=new Set();
    f.data.options.forEach(o=>{ m[o.id]=o.name;
      if(o.name.length>32) dup.push(f.name+' > 32 ký tự: '+o.name);
      if(seen.has(o.name)) dup.push(f.name+' trùng nhãn: '+o.name); seen.add(o.name);});
    maps[f.id]=m; }
  if (dup.length) return key+' CHẶN: '+dup.join(' | ');
  const rr=await __api('/api/record/list',{dataset_id:b.id});
  const payload=(rr.records||[]).map(rec=>({name:rec.name,cfields:rec.cfields.map(c=>{
    const m=maps[c.id]; if(!m) return {id:c.id,type:c.type,value:c.value};
    let v=c.value; v=Array.isArray(v)?v.map(x=>m[x]||x):(m[v]||v);
    return {id:c.id,type:c.type,value:v};})}));
  localStorage.setItem('__snap_'+key,JSON.stringify(payload));
  for (const f of sel){
    const opts=f.data.options.map(o=>({id:o.name,name:o.name,color:o.color||''}));
    await __api('/api/field/update',{id:f.id,dataset_id:b.id,name:f.name,type:f.type,
      data:Object.assign({},f.data,{options:opts})});
  }
  const ids=(rr.records||[]).map(x=>x.id);
  await __api('/api/record/batch-remove',{dataset_id:b.id,ids,record_ids:ids});
  return await __restore(key,payload);
};

window.__restore = async (key,payload) => {
  const b=__B[key];
  payload = payload || JSON.parse(localStorage.getItem('__snap_'+key)||'[]');
  let ok=0, fail=[];
  for (const p of payload){const r=await __api('/api/record/create',{dataset_id:b.id,name:p.name,cfields:p.cfields});
    if(r.success)ok++; else fail.push(p.name);}
  for (const nm of fail.slice()){const p=payload.find(x=>x.name===nm);
    const r=await __api('/api/record/create',{dataset_id:b.id,name:p.name,cfields:p.cfields});
    if(r.success){ok++; fail=fail.filter(x=>x!==nm);}}
  return key+':'+ok+'/'+payload.length+(fail.length?' FAIL='+fail.join(','):'');
};

/* dọn sạch tenant (chỉ khi user đã xác nhận đây là môi trường demo) */
window.__wipe = async () => {
  const l=await __api('/api/dataset/list'); let ok=0,fail=0;
  for (const d of (l.datasets||[])){
    const rr=await __api('/api/record/list',{dataset_id:d.id});
    const ids=(rr.records||[]).map(x=>x.id);
    if(ids.length) await __api('/api/record/batch-remove',{dataset_id:d.id,ids,record_ids:ids});
    const rm=await __api('/api/dataset/remove',{id:d.id}); rm.success?ok++:fail++;
  }
  return 'deleted='+ok+' failed='+fail;
};

'ready :: ' + Object.keys(__B).join(',')
```

---

# PHỤ LỤC B — dataset-spec.js (dựng sẵn 15 bảng)

Chạy SAU Phụ lục A. Chia nhỏ thành nhiều lần gọi `javascript_tool`
(mỗi lần 1–3 dataset) để tránh timeout và kiểm tra kết quả giữa chừng.

```js
/* ============================================================================
   Base Dataset — định nghĩa 15 dataset chuẩn cho doanh nghiệp sản xuất.
   Chạy SAU bootstrap.js. Chia nhỏ thành nhiều lần gọi javascript_tool
   (mỗi lần 1–3 dataset) để tránh timeout và để kiểm tra kết quả giữa chừng.

   QUY ƯỚC: option.id === option.name (helper __C tự làm) và name <= 32 ký tự.
   ============================================================================ */

/* ---- BƯỚC 0: folder ---- */
window.__F={};
for (const n of ['Danh mục nền','Mua hàng – Vật tư','Bán hàng – Khách hàng',
                 'Kho – Sản xuất','Nhân sự – Tài sản']){
  __F[n]=(await __api('/api/folder/create',{name:n})).folder.id;
}
localStorage.setItem('__F',JSON.stringify(__F));

/* ---- 1. NHÀ CUNG CẤP ---- */
await __mkds('NCC','Danh mục nhà cung cấp','Truck','#0ea5e9',__F['Mua hàng – Vật tư'],[
 ['Mã nhà cung cấp','ma_ncc','text'],
 ['Tên pháp lý đầy đủ','ten_phap_ly','textarea'],
 ['Mã số thuế','mst','text'],
 ['Nhóm hàng cung cấp','nhom_hang','select-m',{options:__C([
   ['Thép & kim loại','#64748b'],['Vòng bi & truyền động','#0ea5e9'],['Dụng cụ cắt gọt','#f59e0b'],
   ['Khí nén – Thuỷ lực','#06b6d4'],['Điện – Tự động hoá','#8b5cf6'],['Hoá chất & sơn','#ec4899'],
   ['Vật tư hàn','#ef4444'],['Nhựa & cao su kỹ thuật','#84cc16'],['Vật tư tiêu hao','#a3a3a3'],
   ['Bao bì & đóng gói','#d97706'],['Gia công thuê ngoài','#14b8a6'],['Vận tải & logistics','#3b82f6'],
   ['Khí công nghiệp','#22c55e'],['Thiết bị đo lường','#6366f1']])}],
 ['Phân loại','phan_loai','select',{options:__C([['Chiến lược','#16a34a'],['Thường xuyên','#2563eb'],
   ['Dự phòng','#f59e0b'],['Tạm ngừng hợp tác','#dc2626']]),radio_display:false}],
 ['Địa chỉ','dia_chi','textarea'],
 ['Người liên hệ','nguoi_lien_he','text'],
 ['Chức danh người liên hệ','chuc_danh_lh','text'],
 ['Điện thoại','dien_thoai','phone'],
 ['Email','email','email'],
 ['Website','website','url'],
 ['Điều khoản thanh toán','dieu_khoan_tt','select',{options:__C([['Trả ngay khi nhận hàng','#dc2626'],
   ['Công nợ 15 ngày','#f59e0b'],['Công nợ 30 ngày','#2563eb'],['Công nợ 45 ngày','#16a34a'],
   ['Công nợ 60 ngày','#7c3aed']]),radio_display:false}],
 ['Hạn mức công nợ (VNĐ)','han_muc_cong_no','currency'],
 ['Lead time (ngày)','lead_time','int'],
 ['Đánh giá nhà cung cấp','danh_gia','rating'],
 ['Tỷ lệ giao đúng hạn 12T (%)','ty_le_dung_han','progress'],
 ['Ngày bắt đầu hợp tác','ngay_hop_tac','date'],
 ['Đạt chứng nhận ISO 9001','co_iso','checkbox'],
 ['Chuyên viên phụ trách','nguoi_phu_trach','user'],
 ['Ghi chú','ghi_chu','textarea']]);

/* ---- 2. VẬT TƯ – HÀNG HOÁ ---- */
const DVT_VT=__C([['Cái','#64748b'],['Bộ','#0ea5e9'],['Kg','#f59e0b'],['Tấn','#ef4444'],
 ['Mét','#8b5cf6'],['M2','#14b8a6'],['Tấm','#6366f1'],['Cây','#84cc16'],['Cuộn','#ec4899'],
 ['Lít','#06b6d4'],['Thùng','#d97706'],['Hộp','#22c55e'],['Chai','#a855f7'],['Đôi','#f43f5e']]);
await __mkds('VT','Danh mục vật tư – hàng hoá','Package','#f59e0b',__F['Mua hàng – Vật tư'],[
 ['Mã vật tư','ma_vt','text'],
 ['Nhóm vật tư','nhom_vt','select',{options:__C([['Nguyên vật liệu chính','#dc2626'],
   ['Bán thành phẩm mua ngoài','#ea580c'],['Chi tiết truyền động','#0ea5e9'],['Dụng cụ cắt gọt','#f59e0b'],
   ['Vật tư điện – tự động hoá','#8b5cf6'],['Khí nén – Thuỷ lực','#06b6d4'],['Hoá chất – Dầu mỡ','#ec4899'],
   ['Vật tư hàn','#ef4444'],['Vật tư tiêu hao','#a3a3a3'],['Bao bì – Đóng gói','#d97706']]),radio_display:false}],
 ['Đơn vị tính','dvt','select',{options:DVT_VT,radio_display:false}],
 ['Quy cách – Thông số kỹ thuật','quy_cach','textarea'],
 ['Vật liệu / Tiêu chuẩn','vat_lieu','text'],
 ['Hãng sản xuất','hang_sx','text'],
 ['Xuất xứ','xuat_xu','select',{options:__C([['Việt Nam','#dc2626'],['Nhật Bản','#e11d48'],
   ['Hàn Quốc','#2563eb'],['Đức','#111827'],['Trung Quốc','#f59e0b'],['Đài Loan','#0ea5e9'],
   ['Thái Lan','#7c3aed'],['Ý','#16a34a'],['Hoa Kỳ','#1d4ed8'],['Ấn Độ','#ea580c'],
   ['Indonesia','#f97316']]),radio_display:false}],
 ['Đơn giá kế hoạch (VNĐ)','don_gia_kh','currency'],
 ['Tồn tối thiểu','ton_min','float'],
 ['Điểm đặt hàng lại','diem_dat_hang','float'],
 ['Tồn tối đa','ton_max','float'],
 ['Lead time (ngày)','lead_time','int'],
 ['Thuế suất GTGT','vat','select',{options:__C([['8%','#16a34a'],['10%','#2563eb'],
   ['Không chịu thuế','#a3a3a3']]),radio_display:false}],
 ['Kiểm soát chất lượng đầu vào','kcs','checkbox'],
 ['Vật tư trọng yếu','trong_yeu','checkbox'],
 ['Trạng thái','trang_thai','select',{options:__C([['Đang sử dụng','#16a34a'],
   ['Hạn chế sử dụng','#f59e0b'],['Ngừng sử dụng','#dc2626']]),radio_display:false}],
 ['Ngày mở mã','ngay_mo_ma','date'],
 ['Người mở mã','nguoi_mo_ma','user'],
 ['Ghi chú','ghi_chu','textarea']]);
await __addlinks('VT',[['Nhà cung cấp chính','NCC',false,'ncc'],
                       ['Nhà cung cấp thay thế','NCC',true,'ncc2']]);

/* ---- 3. KHÁCH HÀNG ---- */
await __mkds('KH','Danh mục khách hàng','Building2','#16a34a',__F['Bán hàng – Khách hàng'],[
 ['Mã khách hàng','ma_kh','text'],
 ['Tên pháp lý đầy đủ','ten_phap_ly','textarea'],
 ['Mã số thuế','mst','text'],
 ['Ngành hàng','nganh','select',{options:__C([['Điện tử – Linh kiện','#8b5cf6'],['Ô tô – Xe máy','#ef4444'],
   ['Chế biến thực phẩm','#22c55e'],['Dệt may – Da giày','#ec4899'],['Xây dựng – Hạ tầng','#f59e0b'],
   ['Năng lượng – Điện','#0ea5e9'],['Bao bì – Nhựa','#14b8a6'],['Cơ khí – Chế tạo máy','#64748b']]),radio_display:false}],
 ['Phân khúc','phan_khuc','select',{options:__C([['Nhóm A – Trọng điểm','#16a34a'],
   ['Nhóm B – Thường xuyên','#2563eb'],['Nhóm C – Vãng lai','#a3a3a3'],
   ['Tiềm năng – Chưa phát sinh','#f59e0b']]),radio_display:false}],
 ['Loại hình vốn','loai_von','select',{options:__C([['FDI Nhật Bản','#e11d48'],['FDI Hàn Quốc','#2563eb'],
   ['FDI Đài Loan','#0ea5e9'],['FDI Châu Âu','#111827'],['Doanh nghiệp trong nước','#16a34a']]),radio_display:false}],
 ['Địa chỉ giao hàng','dia_chi','textarea'],
 ['Người liên hệ','nguoi_lien_he','text'],
 ['Chức danh người liên hệ','chuc_danh_lh','text'],
 ['Điện thoại','dien_thoai','phone'],
 ['Email','email','email'],
 ['Website','website','url'],
 ['Điều khoản thanh toán','dieu_khoan_tt','select',{options:__C([['Trả ngay khi giao hàng','#dc2626'],
   ['Công nợ 30 ngày','#2563eb'],['Công nợ 45 ngày','#16a34a'],['Công nợ 60 ngày','#7c3aed'],
   ['L/C at sight','#f59e0b']]),radio_display:false}],
 ['Hạn mức công nợ (VNĐ)','han_muc','currency'],
 ['Doanh thu 12 tháng gần nhất (VNĐ)','doanh_thu_12t','currency'],
 ['Tỷ trọng trong tổng doanh thu (%)','ty_trong','progress'],
 ['Mức độ tín nhiệm','tin_nhiem','rating'],
 ['Ngày ký hợp đồng khung','ngay_ky_hd','date'],
 ['Đã ký thoả thuận bảo mật (NDA)','co_nda','checkbox'],
 ['Nhân viên phụ trách','nv_phu_trach','user'],
 ['Trạng thái','trang_thai','select',{options:__C([['Đang giao dịch','#16a34a'],
   ['Tạm dừng đơn hàng','#f59e0b'],['Ngừng hợp tác','#dc2626']]),radio_display:false}],
 ['Ghi chú','ghi_chu','textarea']]);

/* ---- 4. SẢN PHẨM ---- */
await __mkds('SP','Danh mục sản phẩm','Cog','#7c3aed',__F['Bán hàng – Khách hàng'],[
 ['Mã sản phẩm','ma_sp','text'],
 ['Dòng sản phẩm','dong_sp','select',{options:__C([['Chi tiết gia công CNC','#2563eb'],
   ['Cụm lắp ráp cơ khí','#7c3aed'],['Kết cấu thép – Khung máy','#64748b'],
   ['Băng tải – Hệ vận chuyển','#0ea5e9'],['Đồ gá – Dụng cụ kiểm tra','#f59e0b'],
   ['Chi tiết dập – Uốn','#ef4444']]),radio_display:false}],
 ['Đơn vị tính','dvt','select',{options:__C([['Cái','#64748b'],['Bộ','#0ea5e9'],['Hệ','#7c3aed'],
   ['Tấn','#ef4444']]),radio_display:false}],
 ['Số bản vẽ','so_ban_ve','text'],
 ['Phiên bản bản vẽ','phien_ban','text'],
 ['Thông số kỹ thuật chính','thong_so','textarea'],
 ['Vật liệu chính','vat_lieu','text'],
 ['Khối lượng tinh (kg)','khoi_luong','float'],
 ['Công đoạn sản xuất','cong_doan','select-m',{options:__C([['Cắt phôi','#a3a3a3'],['Tiện CNC','#2563eb'],
   ['Phay CNC','#7c3aed'],['Khoan – Ta rô','#0ea5e9'],['Hàn','#ef4444'],['Dập – Chấn','#f59e0b'],
   ['Mài phẳng','#14b8a6'],['Nhiệt luyện','#dc2626'],['Sơn tĩnh điện','#ec4899'],['Mạ kẽm','#84cc16'],
   ['Lắp ráp','#16a34a'],['Kiểm tra – Đo CMM','#6366f1']])}],
 ['Thời gian gia công (giờ/SP)','tg_gia_cong','float'],
 ['Giá vốn kế hoạch (VNĐ)','gia_von','currency'],
 ['Giá bán niêm yết (VNĐ)','gia_ban','currency'],
 ['Tỷ lệ lãi gộp (%)','lai_gop','progress'],
 ['Trạng thái vòng đời','vong_doi','select',{options:__C([['Đang sản xuất hàng loạt','#16a34a'],
   ['Đang làm mẫu','#f59e0b'],['Đang thiết kế','#0ea5e9'],['Ngừng sản xuất','#dc2626']]),radio_display:false}],
 ['Đã phê duyệt PPAP','ppap','checkbox'],
 ['Mức độ ưu tiên','uu_tien','rating'],
 ['Ngày phát hành bản vẽ','ngay_ph','date'],
 ['Kỹ sư phụ trách','ks_phu_trach','user'],
 ['Ghi chú kỹ thuật','ghi_chu','textarea']]);
await __addlinks('SP',[['Khách hàng chủ lực','KH',false,'kh']]);

/* ---- 5. KHO ---- */
await __mkds('KHO','Danh mục kho và vị trí lưu trữ','Warehouse','#0891b2',__F['Kho – Sản xuất'],[
 ['Mã kho','ma_kho','text'],
 ['Loại kho','loai_kho','select',{options:__C([['Kho nguyên vật liệu','#dc2626'],
   ['Kho bán thành phẩm','#f59e0b'],['Kho thành phẩm','#16a34a'],['Kho vật tư phụ tùng','#2563eb'],
   ['Kho hoá chất','#ec4899'],['Bãi phế liệu','#a3a3a3']]),radio_display:false}],
 ['Khu vực','khu_vuc','select',{options:__C([['Nhà máy Nhơn Trạch','#0ea5e9'],
   ['Văn phòng Quận 7','#7c3aed']]),radio_display:false}],
 ['Vị trí cụ thể','vi_tri','textarea'],
 ['Thủ kho phụ trách','thu_kho','user'],
 ['Diện tích (m2)','dien_tich','float'],
 ['Số vị trí lưu trữ','so_vi_tri','int'],
 ['Tỷ lệ lấp đầy (%)','lap_day','progress'],
 ['Có kiểm soát nhiệt độ – độ ẩm','kiem_soat_nd','checkbox'],
 ['Ngày kiểm kê gần nhất','ngay_kiem_ke','date'],
 ['Trạng thái','trang_thai','select',{options:__C([['Đang hoạt động','#16a34a'],
   ['Tạm ngừng để sửa chữa','#f59e0b'],['Đã đóng','#dc2626']]),radio_display:false}],
 ['Ghi chú','ghi_chu','textarea']]);

/* ---- 6. PHÒNG BAN ---- */
await __mkds('PB','Danh mục phòng ban và trung tâm chi phí','Network','#475569',__F['Danh mục nền'],[
 ['Mã đơn vị','ma_pb','text'],
 ['Khối','khoi','select',{options:__C([['Khối Điều hành','#111827'],['Khối Sản xuất','#dc2626'],
   ['Khối Kỹ thuật – Chất lượng','#2563eb'],['Khối Chuỗi cung ứng','#f59e0b'],
   ['Khối Kinh doanh','#16a34a'],['Khối Hỗ trợ','#7c3aed']]),radio_display:false}],
 ['Mã trung tâm chi phí','cost_center','text'],
 ['Trưởng đơn vị','truong_dv','user'],
 ['Địa điểm làm việc','dia_diem','select',{options:__C([['Nhà máy Nhơn Trạch','#0ea5e9'],
   ['Văn phòng Quận 7','#7c3aed'],['Cả hai địa điểm','#a3a3a3']]),radio_display:false}],
 ['Số nhân sự','so_nhan_su','int'],
 ['Ngân sách chi phí năm 2026 (VNĐ)','ngan_sach','currency'],
 ['Tỷ lệ giải ngân ngân sách (%)','giai_ngan','progress'],
 ['Chức năng chính','chuc_nang','textarea'],
 ['Ngày thành lập','ngay_tl','date'],
 ['Là đơn vị sản xuất trực tiếp','truc_tiep','checkbox'],
 ['Trạng thái','trang_thai','select',{options:__C([['Đang hoạt động','#16a34a'],
   ['Đã sáp nhập','#a3a3a3']]),radio_display:false}]]);

/* ---- 7. NHÂN SỰ ---- */
await __mkds('NS','Danh mục nhân sự','Users','#e11d48',__F['Nhân sự – Tài sản'],[
 ['Mã nhân viên','ma_nv','text'],
 ['Chức danh','chuc_danh','text'],
 ['Cấp bậc','cap_bac','select',{options:__C([['Ban Giám đốc','#111827'],
   ['Trưởng phòng – Quản đốc','#dc2626'],['Tổ trưởng – Giám sát','#f59e0b'],
   ['Chuyên viên – Kỹ sư','#2563eb'],['Nhân viên – Công nhân','#16a34a']]),radio_display:false}],
 ['Loại hợp đồng','loai_hd','select',{options:__C([['Không xác định thời hạn','#16a34a'],
   ['Xác định thời hạn 12 tháng','#2563eb'],['Xác định thời hạn 24 tháng','#0ea5e9'],
   ['Thử việc','#f59e0b'],['Thời vụ dưới 12 tháng','#a3a3a3']]),radio_display:false}],
 ['Ngày vào làm','ngay_vao','date'],
 ['Giới tính','gioi_tinh','select',{options:__C([['Nam','#2563eb'],['Nữ','#ec4899']]),radio_display:false}],
 ['Năm sinh','nam_sinh','int'],
 ['Email công việc','email','email'],
 ['Điện thoại','dien_thoai','phone'],
 ['Địa điểm làm việc','dia_diem','select',{options:__C([['Nhà máy Nhơn Trạch','#0ea5e9'],
   ['Văn phòng Quận 7','#7c3aed']]),radio_display:false}],
 ['Trình độ chuyên môn','trinh_do','select',{options:__C([['Sau đại học','#111827'],['Đại học','#2563eb'],
   ['Cao đẳng','#0ea5e9'],['Trung cấp nghề','#f59e0b'],['Trung học phổ thông','#a3a3a3']]),radio_display:false}],
 ['Bậc tay nghề','bac_tay_nghe','rating'],
 ['Chứng chỉ – Kỹ năng','chung_chi','select-m',{options:__C([['Vận hành máy CNC','#2563eb'],
   ['CAD/CAM','#7c3aed'],['Chứng chỉ hàn 3G/4G','#ef4444'],['Vận hành cầu trục','#f59e0b'],
   ['Lái xe nâng','#d97706'],['An toàn lao động nhóm 3','#16a34a'],['Nghiệp vụ PCCC','#dc2626'],
   ['Đánh giá viên nội bộ ISO','#0ea5e9'],['Vận hành máy đo CMM','#6366f1'],
   ['Tiếng Nhật N3 trở lên','#e11d48'],['Tiếng Anh giao tiếp','#14b8a6']])}],
 ['Đang làm việc','dang_lam','checkbox'],
 ['Quản lý trực tiếp','ql_truc_tiep','user'],
 ['Trạng thái','trang_thai','select',{options:__C([['Chính thức','#16a34a'],['Đang thử việc','#f59e0b'],
   ['Đã nghỉ việc','#dc2626'],['Nghỉ thai sản','#ec4899']]),radio_display:false}],
 ['Ghi chú','ghi_chu','textarea']]);
await __addlinks('NS',[['Phòng ban','PB',false,'pb']]);

/* ---- 8. TÀI SẢN ---- */
await __mkds('TS','Danh mục tài sản và thiết bị','HardHat','#ca8a04',__F['Nhân sự – Tài sản'],[
 ['Mã tài sản','ma_ts','text'],
 ['Nhóm tài sản','nhom_ts','select',{options:__C([['Máy công cụ CNC','#2563eb'],
   ['Máy công cụ vạn năng','#0ea5e9'],['Máy dập – chấn – cắt','#ef4444'],['Thiết bị hàn','#dc2626'],
   ['Thiết bị nâng hạ','#f59e0b'],['Thiết bị đo lường','#6366f1'],['Thiết bị phụ trợ','#14b8a6'],
   ['Phương tiện vận tải','#84cc16'],['Thiết bị văn phòng – CNTT','#a3a3a3']]),radio_display:false}],
 ['Model','model','text'],['Số serial','serial','text'],['Hãng sản xuất','hang_sx','text'],
 ['Xuất xứ','xuat_xu','select',{options:__C([['Nhật Bản','#e11d48'],['Hàn Quốc','#2563eb'],
   ['Đài Loan','#0ea5e9'],['Đức','#111827'],['Trung Quốc','#f59e0b'],['Việt Nam','#16a34a'],
   ['Ý','#7c3aed'],['Hoa Kỳ','#1d4ed8']]),radio_display:false}],
 ['Năm sản xuất','nam_sx','int'],
 ['Ngày đưa vào sử dụng','ngay_su_dung','date'],
 ['Nguyên giá (VNĐ)','nguyen_gia','currency'],
 ['Giá trị còn lại (VNĐ)','gtcl','currency'],
 ['Mức độ khấu hao (%)','khau_hao','progress'],
 ['Thời gian khấu hao (tháng)','tg_khau_hao','int'],
 ['Người quản lý','nguoi_ql','user'],
 ['Tình trạng','tinh_trang','select',{options:__C([['Hoạt động tốt','#16a34a'],
   ['Hoạt động – cần theo dõi','#f59e0b'],['Đang sửa chữa','#dc2626'],['Chờ thanh lý','#a3a3a3']]),radio_display:false}],
 ['Chu kỳ bảo trì','chu_ky_bt','select',{options:__C([['Hàng tháng','#2563eb'],['Hàng quý','#0ea5e9'],
   ['6 tháng một lần','#f59e0b'],['Hàng năm','#a3a3a3']]),radio_display:false}],
 ['Bảo trì gần nhất','bt_gan_nhat','date'],
 ['Bảo trì kế tiếp','bt_ke_tiep','date'],
 ['Thuộc diện kiểm định bắt buộc','kiem_dinh','checkbox'],
 ['Mức độ trọng yếu','trong_yeu','rating'],
 ['Ghi chú','ghi_chu','textarea']]);
await __addlinks('TS',[['Đơn vị quản lý','PB',false,'pb'],['Vị trí đặt','KHO',false,'kho']]);

/* ---- 9. BẢNG GIÁ MUA ---- */
await __mkds('BG','Bảng giá mua theo nhà cung cấp','Tag','#b45309',__F['Mua hàng – Vật tư'],[
 ['Đơn giá (VNĐ)','don_gia','currency'],['Đơn vị tính','dvt','text'],
 ['Số lượng đặt tối thiểu','moq','float'],['Lead time (ngày)','lead_time','int'],
 ['Điều kiện giao hàng','dk_giao','select',{options:__C([['Giao tại nhà máy','#16a34a'],
   ['Nhận tại kho nhà cung cấp','#f59e0b'],['Theo thoả thuận từng lô','#a3a3a3']]),radio_display:false}],
 ['Tỷ lệ chiết khấu (%)','chiet_khau','progress'],
 ['Hiệu lực từ','hl_tu','date'],['Hiệu lực đến','hl_den','date'],
 ['Số báo giá gốc','so_bao_gia','text'],['Đang áp dụng','dang_ap_dung','checkbox'],
 ['Trạng thái','trang_thai','select',{options:__C([['Còn hiệu lực','#16a34a'],
   ['Sắp hết hiệu lực','#f59e0b'],['Đã hết hiệu lực','#a3a3a3'],['Đang đàm phán lại','#0ea5e9']]),radio_display:false}],
 ['Người đàm phán','nguoi_dp','user'],['Ghi chú điều khoản','ghi_chu','textarea']]);
await __addlinks('BG',[['Vật tư','VT',false,'vt'],['Nhà cung cấp','NCC',false,'ncc']]);

/* ---- 10. ĐƠN ĐẶT HÀNG MUA ---- */
await __mkds('PO','Đơn đặt hàng mua','ShoppingCart','#dc2626',__F['Mua hàng – Vật tư'],[
 ['Ngày đặt hàng','ngay_dat','date'],['Nội dung mua','noi_dung','textarea'],
 ['Người mua','nguoi_mua','user'],['Giá trị trước thuế (VNĐ)','tien_truoc_thue','currency'],
 ['Thuế suất GTGT','vat','select',{options:__C([['8%','#16a34a'],['10%','#2563eb'],
   ['Không chịu thuế','#a3a3a3']]),radio_display:false}],
 ['Tiền thuế GTGT (VNĐ)','tien_thue','currency'],['Tổng thanh toán (VNĐ)','tong_tien','currency'],
 ['Điều khoản thanh toán','dieu_khoan_tt','select',{options:__C([['Trả ngay khi nhận hàng','#dc2626'],
   ['Công nợ 15 ngày','#f59e0b'],['Công nợ 30 ngày','#2563eb'],['Công nợ 45 ngày','#16a34a'],
   ['Tạm ứng 50% khi đặt','#7c3aed']]),radio_display:false}],
 ['Ngày giao dự kiến','ngay_giao_dk','date'],['Ngày giao thực tế','ngay_giao_tt','date'],
 ['Tiến độ giao hàng (%)','tien_do','progress'],
 ['Trạng thái','trang_thai','select',{options:__C([['Nháp – chờ trình','#a3a3a3'],
   ['Chờ phê duyệt','#f59e0b'],['Đã gửi nhà cung cấp','#0ea5e9'],['Giao một phần','#7c3aed'],
   ['Đã nhận đủ hàng','#16a34a'],['Bị từ chối','#dc2626'],['Đã huỷ','#71717a']]),radio_display:false}],
 ['Đơn hàng khẩn','khan','checkbox'],['Số báo giá tham chiếu','so_bao_gia','text'],
 ['Hồ sơ kèm theo','ho_so','textarea'],['Người phê duyệt','nguoi_duyet','user'],
 ['Ngày phê duyệt','ngay_duyet','date'],['Ý kiến phê duyệt','y_kien','textarea'],
 ['Ghi chú theo dõi','ghi_chu','textarea']]);
await __addlinks('PO',[['Nhà cung cấp','NCC',false,'ncc'],['Vật tư đặt mua','VT',true,'vt']]);

/* ---- 11. ĐƠN HÀNG BÁN ---- */
await __mkds('SO','Đơn hàng bán và hợp đồng','FileText','#15803d',__F['Bán hàng – Khách hàng'],[
 ['Ngày ký đơn hàng','ngay_ky','date'],['Số PO của khách hàng','po_khach','text'],
 ['Nội dung đơn hàng','noi_dung','textarea'],['Người phụ trách','nguoi_pt','user'],
 ['Số lượng đặt','so_luong','int'],['Giá trị trước thuế (VNĐ)','tien_truoc_thue','currency'],
 ['Thuế suất GTGT','vat','select',{options:__C([['8%','#16a34a'],['10%','#2563eb'],
   ['Không chịu thuế (xuất khẩu)','#a3a3a3']]),radio_display:false}],
 ['Tiền thuế GTGT (VNĐ)','tien_thue','currency'],['Tổng giá trị đơn hàng (VNĐ)','tong_tien','currency'],
 ['Điều khoản thanh toán','dieu_khoan_tt','select',{options:__C([['Công nợ 30 ngày','#2563eb'],
   ['Công nợ 45 ngày','#16a34a'],['Công nợ 60 ngày','#7c3aed'],['Tạm ứng 30% khi ký','#f59e0b'],
   ['L/C at sight','#dc2626']]),radio_display:false}],
 ['Ngày giao cam kết','ngay_giao_ck','date'],['Ngày giao thực tế','ngay_giao_tt','date'],
 ['Tiến độ sản xuất (%)','tien_do','progress'],
 ['Trạng thái','trang_thai','select',{options:__C([['Đang báo giá','#a3a3a3'],
   ['Đã chốt – chờ sản xuất','#0ea5e9'],['Đang sản xuất','#7c3aed'],['Đã giao một phần','#f59e0b'],
   ['Đã giao đủ','#16a34a'],['Có hàng bị trả lại','#dc2626'],['Khách huỷ đơn','#71717a']]),radio_display:false}],
 ['Mức độ ưu tiên','uu_tien','rating'],['Đã xuất hoá đơn','xuat_hd','checkbox'],
 ['Yêu cầu đặc biệt của khách','yeu_cau','textarea'],['Hồ sơ kèm theo','ho_so','textarea'],
 ['Ghi chú theo dõi','ghi_chu','textarea']]);
await __addlinks('SO',[['Khách hàng','KH',false,'kh'],['Sản phẩm','SP',true,'sp']]);

/* ---- 12. THẺ KHO ---- */
await __mkds('TK','Thẻ kho – Tồn kho theo vật tư','Layers','#0d9488',__F['Kho – Sản xuất'],[
 ['Kỳ báo cáo','ky','select',{options:__C([['Tháng 6/2026','#a3a3a3'],['Tháng 7/2026','#0ea5e9'],
   ['Tháng 8/2026','#16a34a']]),radio_display:false}],
 ['Đơn vị tính','dvt','text'],['Tồn đầu kỳ','ton_dau','float'],['Nhập trong kỳ','nhap','float'],
 ['Xuất trong kỳ','xuat','float'],['Tồn cuối kỳ','ton_cuoi','float'],
 ['Đơn giá bình quân (VNĐ)','don_gia_bq','currency'],['Giá trị tồn kho (VNĐ)','gia_tri_ton','currency'],
 ['Mức tồn tối thiểu','ton_min','float'],['Dưới mức tồn tối thiểu','duoi_dinh_muc','checkbox'],
 ['Số ngày tồn kho bình quân','ngay_ton','int'],['Ngày kiểm kê','ngay_kiem_ke','date'],
 ['Chênh lệch kiểm kê','chenh_lech','float'],['Người kiểm kê','nguoi_kiem','user'],
 ['Ghi chú','ghi_chu','textarea']]);
await __addlinks('TK',[['Vật tư','VT',false,'vt'],['Kho','KHO',false,'kho']]);

/* ---- 13. BOM ---- */
await __mkds('BOM','Định mức nguyên vật liệu (BOM)','GitBranch','#9333ea',__F['Kho – Sản xuất'],[
 ['Định mức tiêu hao','dinh_muc','float'],['Đơn vị tính','dvt','text'],
 ['Tỷ lệ hao hụt cho phép (%)','hao_hut','float'],['Định mức đã gồm hao hụt','dm_gom_hh','float'],
 ['Công đoạn tiêu hao','cong_doan','select',{options:__C([['Cắt phôi','#a3a3a3'],['Tiện CNC','#2563eb'],
   ['Phay CNC','#7c3aed'],['Khoan – Ta rô','#0ea5e9'],['Hàn','#ef4444'],['Dập – Chấn','#f59e0b'],
   ['Sơn tĩnh điện','#ec4899'],['Lắp ráp','#16a34a'],['Đóng gói','#d97706']]),radio_display:false}],
 ['Cho phép thay thế vật tư','cho_thay_the','checkbox'],['Phiên bản định mức','phien_ban','text'],
 ['Ngày hiệu lực','ngay_hl','date'],['Người lập định mức','nguoi_lap','user'],
 ['Ghi chú','ghi_chu','textarea']]);
await __addlinks('BOM',[['Sản phẩm','SP',false,'sp'],['Vật tư','VT',false,'vt']]);

/* ---- 14. ĐƠN VỊ TÍNH ---- */
await __mkds('DVT','Danh mục đơn vị tính và quy đổi','Ruler','#0284c7',__F['Danh mục nền'],[
 ['Mã đơn vị tính','ma_dvt','text'],['Ký hiệu','ky_hieu','text'],
 ['Nhóm đơn vị','nhom','select',{options:__C([['Khối lượng','#dc2626'],['Số lượng','#2563eb'],
   ['Chiều dài','#7c3aed'],['Diện tích','#0ea5e9'],['Thể tích','#16a34a'],['Thời gian','#f59e0b']]),radio_display:false}],
 ['Đơn vị gốc quy đổi','dvt_goc','text'],['Hệ số quy đổi','he_so','float'],
 ['Là đơn vị chuẩn của nhóm','la_chuan','checkbox'],['Số chữ số thập phân','thap_phan','int'],
 ['Áp dụng cho','ap_dung','select-m',{options:__C([['Vật tư – hàng hoá','#f59e0b'],['Sản phẩm','#7c3aed'],
   ['Dịch vụ','#0ea5e9'],['Nhân công','#16a34a']])}],
 ['Đang sử dụng','dang_dung','checkbox'],['Ghi chú','ghi_chu','textarea']]);

/* ---- 15. KHOẢN MỤC CHI PHÍ ---- */
await __mkds('CP','Danh mục khoản mục chi phí','Wallet','#be123c',__F['Danh mục nền'],[
 ['Mã khoản mục','ma_cp','text'],
 ['Nhóm chi phí','nhom','select',{options:__C([['Nguyên vật liệu trực tiếp','#dc2626'],
   ['Chi phí nhân công trực tiếp','#f59e0b'],['Chi phí sản xuất chung','#7c3aed'],
   ['Chi phí bán hàng','#16a34a'],['Chi phí quản lý doanh nghiệp','#2563eb'],
   ['Chi phí tài chính','#0ea5e9'],['Chi phí khác','#a3a3a3']]),radio_display:false}],
 ['Tài khoản kế toán','tk_ke_toan','text'],
 ['Cách phân bổ','phan_bo','select',{options:__C([['Trực tiếp theo lệnh sản xuất','#16a34a'],
   ['Phân bổ theo giờ máy','#2563eb'],['Phân bổ theo giờ công','#7c3aed'],
   ['Phân bổ theo diện tích','#0ea5e9'],['Phân bổ theo doanh thu','#f59e0b'],
   ['Không phân bổ','#a3a3a3']]),radio_display:false}],
 ['Ngân sách năm 2026 (VNĐ)','ngan_sach','currency'],
 ['Thực chi luỹ kế 8 tháng (VNĐ)','thuc_chi','currency'],
 ['Tỷ lệ thực hiện ngân sách (%)','ty_le','progress'],
 ['Tính vào giá thành sản phẩm','vao_gia_thanh','checkbox'],
 ['Cần chứng từ gốc kèm theo','can_chung_tu','checkbox'],
 ['Người kiểm soát','nguoi_ks','user'],['Đang sử dụng','dang_dung','checkbox'],
 ['Ghi chú','ghi_chu','textarea']]);

/* ---- BƯỚC CUỐI: sort mặc định + kanban ---- */
const SORTS={NCC:['ma_ncc','asc'],VT:['ma_vt','asc'],KH:['ma_kh','asc'],SP:['ma_sp','asc'],
 KHO:['ma_kho','asc'],PB:['ma_pb','asc'],NS:['ma_nv','asc'],TS:['ma_ts','asc'],
 PO:['ngay_dat','desc'],SO:['ngay_ky','desc'],BG:['hl_tu','desc'],DVT:['ma_dvt','asc'],CP:['ma_cp','asc']};
for (const k of Object.keys(SORTS)){
  const b=__B[k]; const v=await __api('/api/view/list',{dataset_id:b.id});
  const view=v.views.find(x=>x.metatype==='grid');
  await __api('/api/view/update',{id:view.id,dataset_id:b.id,
    config:Object.assign({},view.config,{sorts:[{fieldId:b.f[SORTS[k][0]],dir:SORTS[k][1]}]})});
}
/* Kanban theo trạng thái — chỉ bật card field dạng text để tránh render thô */
for (const [k,stack,cards] of [['PO','trang_thai',['noi_dung','so_bao_gia']],
                               ['SO','trang_thai',['noi_dung','po_khach']]]){
  const b=__B[k]; const v=await __api('/api/view/list',{dataset_id:b.id});
  const grid=v.views.find(x=>x.metatype==='grid');
  const kv=(await __api('/api/view/create',{dataset_id:b.id,name:'Theo trạng thái',metatype:'kanban'})).view;
  const vis={}; Object.keys(grid.config.columnVisibility||{}).forEach(id=>vis[id]=false);
  Object.values(b.links).forEach(id=>vis[id]=false);
  cards.forEach(c=>vis[b.f[c]]=true);
  await __api('/api/view/update',{id:kv.id,dataset_id:b.id,name:'Theo trạng thái',
    config:Object.assign({},grid.config,{sorts:[],kanbanStackFieldId:b.f[stack],
      kanbanHideEmpty:false,kanbanCardVisibility:vis})});
}
'DONE — chạy script nghiệm thu ở Phụ lục C'
```

---

# PHỤ LỤC C — verify.js (nghiệm thu)

Chạy sau Phụ lục A. Trả về một dòng tóm tắt; mọi chỉ số phải bằng 0 mới đạt.

```js
/* Base Dataset — nghiệm thu. Chạy sau khi bootstrap. Trả về 1 dòng tóm tắt. */
let dates=0,badDates=0,sels=0,badSel=0,links=0,badLinks=0,total=0;
const counts=[], issues=[], mismatch=[], emptyF=[];
const re=/(demo|test|thử nghiệm|mẫu thử|\babc\b|xxx|aaa|lorem|Nguyễn Văn A|Công ty ABC|Khách hàng 1|Nhà cung cấp 1|ZTEST)/i;
const smell=[];

for (const k of Object.keys(__B)){
  const b=__B[k];
  const info=(await __api('/api/dataset/info',{id:b.id})).dataset;
  const declared=Object.keys(b.f).length+Object.keys(b.links).length;
  if (info.input_model.field_ids.length!==declared)
    mismatch.push(k+' '+info.input_model.field_ids.length+'/'+declared);

  const fr=await __api('/api/dataset/fields',{id:b.id});
  const opt={}; (fr.fields||[]).forEach(f=>{ if(f.data&&f.data.options) opt[f.id]=new Set(f.data.options.map(o=>o.id)); });

  const rr=await __api('/api/record/list',{dataset_id:b.id});
  counts.push(k+'='+rr.records.length); total+=rr.records.length;
  const used=new Set();

  rr.records.forEach(rec=>{
    if (re.test(rec.name)) smell.push(k+':'+rec.name);
    rec.cfields.forEach(c=>{
      if(c.value!==null&&c.value!==undefined&&c.value!=='') used.add(String(c.id));
      if(typeof c.value==='string'&&re.test(c.value)) smell.push(k+':'+rec.name);
      if(c.type==='date'||c.type==='datetime'){dates++; if(typeof c.value!=='number')badDates++;}
      if(opt[c.id]){const vs=Array.isArray(c.value)?c.value:[c.value];
        vs.forEach(v=>{sels++; if(!opt[c.id].has(v)){badSel++; issues.push(k+'/'+rec.name+'/'+v);}});}
      if(String(c.id).startsWith('int_')&&Array.isArray(c.value))
        c.value.forEach(v=>{links++; if(!v.id)badLinks++;});
    });
  });
  const miss=info.input_model.field_ids.filter(f=>!used.has(String(f)));
  if (miss.length) emptyF.push(k+':'+miss.length);
}

'TOTAL='+total
+' | fieldMismatch='+(mismatch.length?mismatch.join(','):'0')
+' | emptyFields='+(emptyF.length?emptyF.join(','):'0')
+' | badDates='+badDates+'/'+dates
+' | badSelects='+badSel+'/'+sels
+' | brokenLinks='+badLinks+'/'+links
+' | demoSmell='+smell.length
+' || '+counts.join(' ')
+(issues.length?' || '+issues.slice(0,5).join(','):'')
```

---

# PHỤ LỤC D — Blueprint dữ liệu, demo cast và mạch chuyện

### Blueprint 15 bảng + demo cast + danh mục dùng chung

Bộ này đã dựng và nghiệm thu thật trên tenant Base Inc (22/08/2026): 398 bản ghi,
0 lỗi ngày, 0 lỗi option, 0 link gãy, 0 từ khoá lộ mùi demo.

---

#### A. Hồ sơ doanh nghiệp giả định

**Công ty Cổ phần Cơ khí Chính xác Nam Tiến Phát**
- Nhà máy: Lô C12-C14, KCN Nhơn Trạch III, H. Nhơn Trạch, Đồng Nai
- Văn phòng: Tầng 8, 27 Nguyễn Văn Linh, P. Tân Phong, Q.7, TP.HCM
- ~340 nhân sự · 4 xưởng: Gia công CNC · Dập–Hàn · Xử lý bề mặt · Lắp ráp
- Sản phẩm: chi tiết gia công CNC, cụm lắp ráp cơ khí, kết cấu thép – khung máy,
  băng tải, đồ gá – dưỡng kiểm, chi tiết dập – uốn
- Khách hàng: nhà máy FDI Nhật/Hàn/Đài/EU tại Đồng Nai – Bình Dương – Long An

Đổi ngành: giữ nguyên cấu trúc 15 bảng, thay danh từ riêng ở mục C và D.

#### B. Demo cast — map user thật trong tenant vào vai

| Vai | Dùng cho field |
|---|---|
| Giám đốc Nhà máy | chủ sở hữu dataset, kiểm soát chi phí CNTT |
| TP Kế hoạch – Vật tư | người mở mã vật tư |
| TP Mua hàng | người phê duyệt đơn mua, người đàm phán bảng giá |
| CV Mua hàng (×2) | người mua trên đơn đặt hàng |
| Kế toán trưởng | kiểm soát khoản mục chi phí, phụ trách NCC bao bì – vận tải |
| GĐ Kinh doanh / CV Kinh doanh (×2) | phụ trách khách hàng, người phụ trách đơn bán |
| Quản đốc xưởng | quản lý tài sản máy móc |
| TP Quản lý chất lượng | phụ trách NCC hoá chất, kiểm định, thiết bị đo |
| TP Kỹ thuật | kỹ sư phụ trách sản phẩm, người lập BOM |
| TP Bảo trì – Cơ điện | quản lý thiết bị điện, khí nén, dầu mỡ |
| Thủ kho tổng / NV kho | thủ kho, người kiểm kê |
| CV Nhân sự | phụ trách bảo hộ lao động |

Lấy danh sách user: `(await (await fetch('/auth/me')).json()).users` → `{id,name}`.
**Không gán dữ liệu nhạy cảm (lương, kỷ luật, đánh giá kém) cho tên người thật.**
Nhân sự trong bảng "Danh mục nhân sự" là **tên hư cấu**, chỉ field "Quản lý trực tiếp"
mới trỏ tới user thật.

#### C. Danh mục dùng chung — 20 nhà cung cấp

Mã NCC-001…NCC-020. Cấu trúc tên pháp lý đúng chuẩn, MST 10 số đúng đầu tỉnh,
địa chỉ tới cấp phường/xã, người liên hệ có chức danh và số điện thoại đúng đầu số.

| Mã | Tên rút gọn | Nhóm hàng | Phân loại |
|---|---|---|---|
| NCC-001 | Thép tấm Đại Hưng Thịnh | Thép & kim loại | Chiến lược |
| NCC-002 | Kim khí Nam Hải Long | Thép & kim loại | Thường xuyên |
| NCC-003 | Vòng bi Tân Đức Phát | Vòng bi & truyền động | Chiến lược |
| NCC-004 | Cơ khí Hoàng Kim Đạt | Gia công thuê ngoài | Thường xuyên |
| NCC-005 | Dụng cụ cắt Việt Tân Phong | Dụng cụ cắt gọt | Chiến lược |
| NCC-006 | Vật tư CN Bình An Khánh | Vật tư tiêu hao | Thường xuyên |
| NCC-007 | Khí nén Trường Hải Đăng | Khí nén – Thuỷ lực | Thường xuyên |
| NCC-008 | Điện CN Phú Nam Sơn | Điện – Tự động hoá | Chiến lược |
| NCC-009 | Dầu nhớt Á Đông Mekong | Hoá chất & sơn | Thường xuyên |
| NCC-010 | Hoá chất Tân Việt Mỹ | Hoá chất & sơn | Thường xuyên |
| NCC-011 | Sơn CN Đại Thành Lộc | Hoá chất & sơn | Thường xuyên |
| NCC-012 | Bao bì gỗ Nhơn Trạch Thành Công | Bao bì & đóng gói | Thường xuyên |
| NCC-013 | Đông Nam Logistics | Vận tải & logistics | Chiến lược |
| NCC-014 | Khí CN Sài Gòn Vạn Phát | Khí công nghiệp | Thường xuyên |
| NCC-015 | Vật liệu hàn Minh Quang Huy | Vật tư hàn | Thường xuyên |
| NCC-016 | Nhựa kỹ thuật Tân Bình Nguyên | Nhựa & cao su kỹ thuật | Dự phòng |
| NCC-017 | Cao su KT Long Thành Đạt | Nhựa & cao su kỹ thuật | Thường xuyên |
| NCC-018 | Chuẩn Đo Việt | Thiết bị đo lường | Chiến lược |
| NCC-019 | Thép Đại Hưng Thịnh – CN Bình Dương | Thép & kim loại | Dự phòng |
| NCC-020 | Gia công nhiệt luyện Tiến Thịnh Phát | Gia công thuê ngoài | Thường xuyên |

#### D. Danh mục dùng chung — 40 vật tư (mã VT-xxxx)

Nhóm và dải mã: NVL chính `VT-10xx` · bán thành phẩm `VT-1044` ·
truyền động `VT-20xx` · dụng cụ cắt `VT-30xx` · điện `VT-40xx` ·
khí nén `VT-50xx` · hoá chất – dầu `VT-60xx` · hàn `VT-70xx` ·
tiêu hao `VT-80xx` · bao bì `VT-90xx`.

Ví dụ chuẩn về mức chi tiết cần đạt:
`VT-1001 · Thép tấm SS400 dày 10mm · Kg · Khổ 1500 × 6000mm, dày 10mm, cán nóng,
bề mặt không sơn · JIS G3101 SS400 · Đại Hưng Thịnh · Việt Nam · 18.450đ ·
tồn tối thiểu 4.500 · điểm đặt hàng 7.000 · tồn tối đa 26.000 · lead time 7 ngày ·
VAT 10% · có KCS đầu vào · vật tư trọng yếu`

Mỗi vật tư phải có: quy cách đầy đủ, tiêu chuẩn vật liệu, hãng, xuất xứ, đơn giá lẻ,
3 mức tồn, lead time khớp với bảng giá, và **ghi chú nghiệp vụ thật**
(vd *"Cắt plasma theo bản vẽ, chừa lượng dư 2mm mỗi cạnh"*).

#### E. 20 khách hàng (KH-001…KH-020)

Trộn FDI Nhật (Sakura Denshi, Nissho Kikai, Yamato Seiki, Fujiwara Kogyo, Kanemitsu),
Hàn (Hansol Precision, Kyung Il), Đài (Chen Yu), EU (Steinbach Automation) và
doanh nghiệp trong nước. Phân khúc A/B/C + 2 khách "Tiềm năng – chưa phát sinh"
(doanh thu 0, chưa ký HĐ khung) + 1 khách "Tạm dừng đơn hàng".

#### F. 15 dataset — field chính

Đầy đủ tên field, code và options nằm trong **Phụ lục B** (chạy được ngay). Tóm tắt:

1. **Danh mục nhà cung cấp** (20 field) — mã, tên pháp lý, MST, nhóm hàng (multi-select),
   phân loại, địa chỉ, người liên hệ + chức danh, phone, email, url, điều khoản TT,
   hạn mức công nợ (currency), lead time, đánh giá (rating), tỷ lệ giao đúng hạn (progress),
   ngày hợp tác, ISO 9001 (checkbox), chuyên viên phụ trách (user), ghi chú.
2. **Danh mục vật tư – hàng hoá** (19 + 2 link) — mã, nhóm, ĐVT, quy cách, vật liệu/tiêu chuẩn,
   hãng, xuất xứ, đơn giá KH, 3 mức tồn (float), lead time, VAT, KCS, trọng yếu, trạng thái,
   ngày mở mã, người mở mã, ghi chú → link NCC chính (1-1) + NCC thay thế (1-n).
3. **Danh mục khách hàng** (22) — như NCC + ngành, phân khúc, loại hình vốn, doanh thu 12T,
   tỷ trọng doanh thu (progress), tín nhiệm (rating), NDA (checkbox).
4. **Danh mục sản phẩm** (19 + 1 link) — mã, dòng SP, ĐVT, số bản vẽ, phiên bản, thông số,
   vật liệu, khối lượng (float), công đoạn (multi-select), thời gian gia công, giá vốn,
   giá bán, lãi gộp (progress), vòng đời, PPAP, ưu tiên (rating), ngày phát hành, kỹ sư →
   link Khách hàng chủ lực.
5. **Danh mục kho và vị trí lưu trữ** (12) — mã, loại kho, khu vực, vị trí, thủ kho (user),
   diện tích, số vị trí, tỷ lệ lấp đầy (progress), kiểm soát nhiệt độ, ngày kiểm kê, trạng thái.
6. **Danh mục phòng ban và trung tâm chi phí** (12) — mã, khối, cost center, trưởng đơn vị,
   địa điểm, số nhân sự, ngân sách năm, tỷ lệ giải ngân (progress), chức năng, ngày thành lập.
7. **Danh mục nhân sự** (17 + 1 link) — mã NV, chức danh, cấp bậc, loại HĐ, ngày vào,
   giới tính, năm sinh, email, phone, địa điểm, trình độ, bậc tay nghề (rating),
   chứng chỉ (multi-select), đang làm việc, quản lý trực tiếp (user), trạng thái → link Phòng ban.
8. **Danh mục tài sản và thiết bị** (20 + 2 link) — mã TS, nhóm, model, serial, hãng, xuất xứ,
   năm SX, ngày sử dụng, nguyên giá, GTCL, khấu hao (progress), thời gian KH, người quản lý,
   tình trạng, chu kỳ bảo trì, BT gần nhất, BT kế tiếp, kiểm định bắt buộc, trọng yếu (rating)
   → link Phòng ban + Kho.
9. **Bảng giá mua theo nhà cung cấp** (13 + 2 link) — đơn giá, ĐVT, MOQ, lead time,
   điều kiện giao, chiết khấu (progress), hiệu lực từ/đến, số báo giá, đang áp dụng,
   trạng thái, người đàm phán → link Vật tư + NCC.
10. **Đơn đặt hàng mua** (19 + 2 link) — ngày đặt, nội dung, người mua, trước thuế, VAT,
    tiền thuế, tổng, điều khoản TT, ngày giao DK/TT, tiến độ (progress), trạng thái,
    đơn khẩn, số báo giá, hồ sơ kèm theo, người duyệt, ngày duyệt, ý kiến duyệt, ghi chú
    → link NCC + Vật tư (n).
11. **Đơn hàng bán và hợp đồng** (19 + 2 link) — tương tự PO, thêm số PO của khách,
    ưu tiên (rating), đã xuất hoá đơn, yêu cầu đặc biệt → link KH + Sản phẩm (n).
12. **Thẻ kho – Tồn kho theo vật tư** (15 + 2 link) — kỳ, ĐVT, tồn đầu, nhập, xuất, tồn cuối,
    đơn giá BQ, giá trị tồn, tồn tối thiểu, dưới định mức, số ngày tồn, ngày kiểm kê,
    chênh lệch kiểm kê, người kiểm → link Vật tư + Kho.
    Đặt tên bản ghi `[T8] <tên vật tư> – <tên kho>`.
13. **Định mức nguyên vật liệu (BOM)** (10 + 2 link) — định mức, ĐVT, hao hụt %,
    định mức gồm hao hụt, công đoạn, cho phép thay thế, phiên bản, ngày hiệu lực, người lập
    → link Sản phẩm + Vật tư. Đặt tên `<tên SP> · <tên VT>`.
14. **Danh mục đơn vị tính và quy đổi** (10) — mã, ký hiệu, nhóm, ĐVT gốc, hệ số quy đổi,
    là chuẩn của nhóm, số chữ số thập phân, áp dụng cho (multi-select), đang dùng.
15. **Danh mục khoản mục chi phí** (12) — mã, nhóm chi phí, tài khoản kế toán, cách phân bổ,
    ngân sách năm, thực chi luỹ kế, tỷ lệ thực hiện (progress), tính vào giá thành,
    cần chứng từ gốc, người kiểm soát, đang sử dụng.

#### G. Mạch chuyện demo (bắt buộc dựng)

```
ĐH-2026-0394  Sakura Denshi đặt 560 trục truyền động, giao 25/09  (đang SX 58%)
   └─ BOM SP-1012: 11,2 kg phôi S45C + 0,026 hộp insert / trục
        └─ Thẻ kho VT-1005 còn 1.460 kg, điểm đặt hàng lại 2.600 kg
             └─ PO-2026-0163  mua phôi S45C + SCM440, đơn khẩn, giao trễ 1 ngày
             └─ PO-2026-0226  nhiệt luyện thuê ngoài 320 chi tiết, HRC 46–49 đạt
```
Nhánh phụ bắt buộc có:
- **Đơn mua bị từ chối rồi trình lại**: PO-2026-0217 bị từ chối vì *"đơn trên 50 triệu phải
  có báo giá đối chứng của NCC thứ hai theo quy định mua hàng"* → PO-2026-0224 trình lại
  kèm báo giá đối chứng, giá giảm 4,7%, nhưng giao trễ 3 ngày và bị ghi vào đánh giá NCC quý.
- **Hàng bị khách trả**: ĐH-2026-0361 khách trả 1 đồ gá do lỗ định vị lệch 0,09mm so với
  dung sai 0,05mm → báo cáo 8D → gia công lại và giao bù.
- **Thiếu vật tư chặn sản xuất**: PO-2026-0221 mới giao 12/20 xy lanh SMC →
  ĐH-2026-0398 dừng ở 45%, còn 8 cái hẹn 28/08.
- **Đơn bị huỷ**: PO-2026-0176 huỷ vì kiểm lại kho còn đủ tồn;
  ĐH-2026-0357 khách Kanemitsu huỷ do điều chỉnh kế hoạch sản xuất.
- **Sự cố chất lượng NCC**: lô hoá chất tẩy dầu tháng 5 lệch nồng độ → NCC-010 bị hạ đánh giá
  còn 3 sao, vật tư VT-6013 chuyển trạng thái "Hạn chế sử dụng", bảng giá chuyển
  "Đang đàm phán lại".

#### H. Phân bổ trạng thái đã dùng (30 đơn mua)

Đã nhận đủ hàng 20 · Đã gửi NCC 4 · Chờ phê duyệt 2 · Giao một phần 1 ·
Bị từ chối 1 · Đã huỷ 1 · Nháp 1.
Ngày trải đều 04/03 → 21/08/2026, mật độ cao hơn ở cuối tháng.
Số đơn bắt đầu từ **PO-2026-0147**, không bao giờ từ 0001.
