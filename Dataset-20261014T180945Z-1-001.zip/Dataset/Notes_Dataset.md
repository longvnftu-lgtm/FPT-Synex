# Base Dataset (dataset.base.com.vn) — capture notes · 22/08/2026

## 1. ANATOMY

### Điều hướng trái
Home · Apps · Datasets · Databases · FOLDERS · DATABASES (connections) · Templates · Settings

### Trang dataset (grid)
Toolbar: Add record | Fields | Filter | Group | Sort | Colour | Height
View tabs: Grid view / Gallery view / Kanban view / (+ Add view)
URL mở dataset: `/dataset/<dataset_id>`  (`/service/<id>` redirect về Home — KHÔNG dùng)

### Dataset settings (modal)
Panes: General info · Accesses & visibility · Manage fields · Manage views · AI grounding

### 3 SCOPE của field (nút New Field có dropdown)
- Global Field   — dùng chung toàn tenant
- Service Field  — scope "servicemodel" (mặc định khi tạo qua /api/field/create)
- Internal Field — chỉ sống trên dataset này; **bắt buộc** cho field Two-way link

### 28 loại field
Two-way link dataset record | Text | Long Text | Integer | Decimal | Date | Date & Time |
Time | Checkbox | Dropdown | Multi-Select | File | Files | Rich Text | Formula | Lines |
Rating | User | Table | Email | URL | Phone | Currency | Message | Progress | Users |
Two-way link rollup | Two-way link lookup

Mã type nội bộ: text, textarea(Long Text), editor(Rich Text), int, float, date, datetime,
checkbox, select(Dropdown), select-m(Multi-Select), files, file, lines, rating, user, table,
email, url, phone, currency, message, progress, advance-table, input-dataset,
internal-link-record(Two-way link)

## 2. API — đường nhanh thay cho click chuột

Auth: `GET /auth/me` → `csrfToken`, `users`, `datasets`, `customFieldsCatalog`.
Mọi call: `POST /api/...` + header `X-CSRF-Token` + JSON body.
**Token XOAY VÒNG trong phiên** → phải bắt `{"code":"csrf_mismatch"}` và lấy token mới rồi gọi lại.

| Endpoint | Body | Ghi chú |
|---|---|---|
| /api/dataset/list | {} | |
| /api/dataset/create | {name,icon,color,folder_id} | icon = tên lucide (Table2, Truck, Package…) |
| /api/dataset/info | {id} | có input_model{field_ids,field_config,internal_fields} |
| /api/dataset/fields | {id} | field đã gắn, kèm `_name` (primary) |
| /api/dataset/attach-field | {id, field_id} | |
| /api/dataset/remove | {id} | **lỗi nếu còn record** |
| /api/dataset/sync-internal-link-reverses | {id} | tạo back-link ở dataset đích |
| /api/field/create | {dataset_id,name,code,type} | `data` bị BỎ QUA ở bước này |
| /api/field/update | {id,dataset_id,name,type,data} | dùng để set options/format |
| /api/service/update-input-model | {id, input_model} | **cách duy nhất** tạo internal-link |
| /api/record/create | {dataset_id,name,cfields:[{id,value,type}]} | |
| /api/record/list | {dataset_id} | |
| /api/record/batch-remove | {dataset_id, ids:[…]} | |
| /api/record/update | — | **HỎNG: luôn trả 500** → phải xoá và tạo lại |
| /api/folder/create /remove | {name} / {id} | |
| /api/view/list /create /update /remove | | config đầy đủ ở §5 |

### Định dạng giá trị cfields[].value
- text/textarea/editor/email/url/phone : string
- int/float/currency/progress/rating   : number
- checkbox : true/false
- **date / datetime : UNIX EPOCH GIÂY** (`Date.UTC(y,m-1,d)/1000`)
- select : id của option · select-m : mảng id
- user : user_id (number)
- internal-link-record : [{id, name, dataset_id}]

## 3. QUIRKS đã gặp (đều đã kiểm chứng bằng thực nghiệm)

1. **Date phải là epoch giây.** API vẫn NHẬN chuỗi `"2026-03-04"` và trả về nguyên vẹn,
   nhưng grid hiển thị **Jan 1, 1970**. Đây là lỗi im lặng nguy hiểm nhất của app này.
2. **Option id bị cắt còn 32 ký tự.** Nếu đặt `id = name` mà name dài hơn 32 ký tự,
   id bị truncate → giá trị bản ghi không khớp option. Giữ nhãn option ≤ 32 ký tự.
3. **Kanban hiển thị `id` của option làm tiêu đề cột**, không phải `name`.
   → Luôn đặt `option.id = option.name` (tiếng Việt có dấu) ngay từ đầu.
4. **Card kanban render thô**: date ra số epoch, user ra user_id, link ra `[object Object]`.
   → Chỉ bật `kanbanCardVisibility` cho field text/textarea.
5. `data.options` KHÔNG được nhận ở /api/field/create → phải gọi thêm /api/field/update.
6. Two-way link KHÔNG tạo được bằng /api/field/create (mọi biến thể scope đều lỗi
   "must be created as internal fields") → dùng /api/service/update-input-model,
   id field phải là `int_1`, `int_2`, … Cấu trúc item xem §4.
7. Field tạo qua API KHÔNG tự gắn vào grid → phải attach-field hoặc set field_ids.
   **Nếu một call trong chuỗi tạo dataset lỗi, field_ids có thể rỗng mà không báo gì.**
   Luôn nghiệm thu `input_model.field_ids.length === số field khai báo`.
8. /api/record/update trả `Internal server error` với mọi biến thể payload.
   Muốn sửa bản ghi: đọc cfields → batch-remove → record/create lại.
9. Điều hướng trang làm mất mọi biến `window.__*` → phải bootstrap lại sau mỗi navigate/F5.
10. javascript_tool báo "Tool failed in the extension" khi biểu thức ném lỗi
    (thường do `__api` undefined sau reload, hoặc response là `{code:'csrf_mismatch'}`).
    Không phải lỗi extension — kiểm tra `typeof __api` trước.
11. Dataset vừa tạo qua API chưa click được từ danh sách (client cache `/auth/me` cũ)
    → F5 hoặc mở thẳng `/dataset/<id>`.
12. Không xoá được dataset còn record → batch-remove trước.
13. Tool javascript_tool chặn output chứa dữ liệu giống cookie/query-string; trả về
    kết quả tóm tắt (đếm, mã lỗi) thay vì dump JSON lớn.

## 4. LUỒNG DỰNG CHUẨN (đã kiểm chứng)

```
folder/create  (nhóm dataset theo phân hệ)
  → dataset/create
  → field/create  (từng field, ĐẶT CODE BẰNG TAY)
  → field/update  (chỉ với field có options / format)
  → service/update-input-model  (field_ids + field_config: quyết định thứ tự cột)
  → service/update-input-model  (thêm internal_fields = link 2 chiều)
  → dataset/sync-internal-link-reverses
  → record/create  (đọc map tên→id của dataset đích trước để tạo link)
  → view/update    (sorts) + view/create metatype:'kanban'
  → NGHIỆM THU
```

internal_fields item:
```js
{id:'int_1',code:'int_1',fls:0,name:'Nhà cung cấp',type:'internal-link-record',
 vtype:'string',config:{},attrs:{forms:1,views:1,required:0,important:0},
 data:{auto:false,multiple:false,dataset_id:<TARGET>,linked_field_id:'int_1',
       source_dataset_id:<SELF>,view_condition:'',validation_condition:'',
       view_condition_enabled:false,validation_condition_enabled:false}}
```
Nhớ push `'int_1'` vào `input_model.field_ids` và `field_config`.

## 5. VIEW CONFIG

Keys: sorts, groups, filters, rowHeight, decorators, columnOrder, frozenCount, wrapHeaders,
columnSizing, kanbanCardWrap, columnSummarize, kanbanCardOrder, kanbanHideEmpty,
columnVisibility, galleryCardOrder, kanbanImageFieldId, kanbanStackFieldId,
kanbanCardVisibility, galleryCardVisibility

- Sort: `config.sorts = [{fieldId:<id>, dir:'asc'|'desc'}]`
- Kanban: `view/create {dataset_id,name,metatype:'kanban'}` rồi
  `view/update {id,dataset_id,config:{...gridConfig, kanbanStackFieldId:<selectFieldId>,
   kanbanHideEmpty:false, kanbanCardVisibility:{<id>:true|false}}}`

## 6. KẾT QUẢ ĐÃ DỰNG (tenant Base Inc)

Hồ sơ: **Công ty CP Cơ khí Chính xác Nam Tiến Phát** — nhà máy KCN Nhơn Trạch III (Đồng Nai),
văn phòng Q.7 TP.HCM, ~340 nhân sự, 4 xưởng (Gia công CNC · Dập–Hàn · Xử lý bề mặt · Lắp ráp).
Khách hàng chủ yếu là nhà máy FDI Nhật/Hàn/Đài/EU ở Đồng Nai – Bình Dương – Long An.

5 folder · 15 dataset · 398 bản ghi · 553 giá trị ngày · 1.390 giá trị select · 1.172 liên kết.

| Folder | Dataset | Bản ghi |
|---|---|---|
| Danh mục nền | Danh mục phòng ban và trung tâm chi phí | 16 |
| Danh mục nền | Danh mục đơn vị tính và quy đổi | 20 |
| Danh mục nền | Danh mục khoản mục chi phí | 20 |
| Mua hàng – Vật tư | Danh mục nhà cung cấp | 20 |
| Mua hàng – Vật tư | Danh mục vật tư – hàng hoá | 40 |
| Mua hàng – Vật tư | Bảng giá mua theo nhà cung cấp | 40 |
| Mua hàng – Vật tư | Đơn đặt hàng mua | 30 |
| Bán hàng – Khách hàng | Danh mục khách hàng | 20 |
| Bán hàng – Khách hàng | Danh mục sản phẩm | 20 |
| Bán hàng – Khách hàng | Đơn hàng bán và hợp đồng | 20 |
| Kho – Sản xuất | Danh mục kho và vị trí lưu trữ | 10 |
| Kho – Sản xuất | Thẻ kho – Tồn kho theo vật tư | 40 |
| Kho – Sản xuất | Định mức nguyên vật liệu (BOM) | 40 |
| Nhân sự – Tài sản | Danh mục nhân sự | 38 |
| Nhân sự – Tài sản | Danh mục tài sản và thiết bị | 24 |

Phủ 21/28 loại field: text, textarea, editor-free, int, float, currency, progress, rating,
date, checkbox, select, select-m, user, email, url, phone, internal-link-record (1-1 và 1-n).

Mạch chuyện xuyên suốt:
`ĐH-2026-0394 (Sakura, 560 trục)` → `BOM SP-1012` → `Thẻ kho VT-1005 dưới điểm đặt hàng`
→ `PO-2026-0163 mua phôi S45C` → `PO-2026-0226 nhiệt luyện thuê ngoài` → giao hàng.
Nhánh phụ: `PO-2026-0217 bị từ chối vì thiếu báo giá đối chứng > 50 triệu` →
`PO-2026-0224 trình lại, giá giảm 4,7%`.
`ĐH-2026-0361 bị khách trả 1 đồ gá do lỗ định vị lệch 0,09mm` → báo cáo 8D → giao bù.
`PO-2026-0221 giao một phần 12/20 xy lanh SMC` → chặn `ĐH-2026-0398` ở 45%.
