# Base Dataset — Knowledge Base

> Tài liệu này được dựng từ **thao tác thực tế trên màn hình** ứng dụng Base Dataset
> (`dataset.base.com.vn`) tại tenant demo **Base Inc**, ngày 23/08/2026.
> Mọi nội dung đều là những gì hiển thị trên giao diện. Không tra cứu tài liệu ngoài.
> Chỗ nào chưa quan sát được sẽ ghi rõ *chưa xác định*.

---

## 1. Tổng quan sản phẩm

**Base Dataset là gì.** Một kho dữ liệu dạng bảng (spreadsheet-database) đặt trong hệ sinh
thái Base.vn. Nó nằm giữa hai thái cực mà doanh nghiệp Việt Nam thường mắc kẹt: **Excel**
(dễ dùng nhưng phân mảnh, không có quyền, không liên kết được) và **ERP/CSDL riêng**
(chặt chẽ nhưng đắt, chậm, phải nhờ IT mỗi khi đổi một trường).

Khẩu hiệu ngay trên trang chủ app nói đúng định vị đó:
*"One place for all your team's data — Clean data, clear thinking."*

**Bốn lớp giá trị**, đi từ dưới lên:

| Lớp | Thành phần | Người dùng chính |
|---|---|---|
| 1. Dữ liệu | Dataset · Field · Record · Folder | Nhân viên nghiệp vụ |
| 2. Cách nhìn | View (Grid / Gallery / Kanban) · Filter · Sort · Group · Colour | Trưởng nhóm |
| 3. Ứng dụng | App (page + block: metric, chart, grid, form) · Template | Quản lý, khách hàng cuối |
| 4. Trí tuệ | Rework AI · AI grounding · AI field | Toàn tổ chức |

Và một lớp ngang: **kết nối** — Databases cho phép trỏ thẳng vào PostgreSQL / Supabase
sẵn có của doanh nghiệp thay vì bắt nhập lại dữ liệu.

**Số liệu tenant demo tại thời điểm ghi hình** (thẻ thống kê trang Home): 15 dataset ·
0 starred · 5 folder · **311 custom field** dùng chung giữa các dataset · 7 app.

---

## 2. Bản đồ tính năng

```
Base Dataset
├── Home (Data Hub) ......... tổng quan số liệu + Most active + Activity log
├── Apps .................... 7 app; mỗi app = nhiều page, mỗi page = nhiều block
├── Datasets ................ 15 dataset; mở ra Grid view + toàn bộ công cụ view
│   ├── Thanh công cụ ....... Add record · Fields · Filter · Group · Sort · Colour · Height
│   ├── Loại view ........... Grid view · Gallery view · Kanban view
│   ├── Record detail ....... Custom fields · Comments · Record information · Activity logs
│   └── Menu dataset ........ Manage fields · Service settings · Move to folder
│                             Import records · Export records · Visualize schema · Delete
├── Databases ............... kết nối PostgreSQL / Supabase (MySQL "Coming soon")
├── Templates ............... 4 template: Applicant Tracker, Content Calendar,
│                             Simple CRM, Task Tracker (5 nhóm danh mục)
├── Settings
│   ├── AI .................. BYO-key LLM, chọn provider/model, hạn mức token
│   ├── Connections ......... connection hạ tầng do quản trị viên tạo
│   └── Folders ............. quản lý 5 thư mục nội dung
└── Rework AI ............... trợ lý AI: hỏi đáp, dựng chart, tạo dataset/field/view/app
```

---

## 3. Chi tiết từng tính năng

### 3.1 Home — Data Hub

Trang mở đầu, đóng vai trò *bảng điều khiển kho dữ liệu*.

- **4 thẻ thống kê**: DATASETS (15, "in this account") · STARRED (0, "saved for quick
  access") · FOLDERS (5, "organizing your data") · CUSTOM FIELDS (311, "shared across
  datasets").
- **4 lối tắt**: Browse datasets · Browse templates · Rework AI · **+ New dataset**.
- **Most active** — 5 dataset chạm gần nhất, kèm thư mục, số dòng, thời điểm và người
  sửa. Ví dụ thực tế: *Định mức nguyên vật liệu (BOM)* — Kho – Sản xuất — 40 rows — 5 min ago.
- **Activity** — nhật ký toàn tài khoản ở mức bản ghi: "Nghĩa Trần created record Lãi vay
  ngân hàng · 21 hrs ago", "…deleted record Dây curoa thang B-1500".

> **Giá trị**: người quản lý mở app là biết ngay hôm nay đội đang đụng vào dữ liệu nào,
> ai đụng, đụng lúc nào — không cần hỏi.

### 3.2 Datasets — danh sách kho dữ liệu

Bảng liệt kê toàn bộ dataset với các cột **Name · Owners · Created · Last updated · Folder**,
ô tìm kiếm, ba bộ lọc (All datasets ▾ / All folders ▾ / sắp xếp Last updated ▾) và nút
**+ New dataset**.

15 dataset của tenant demo được tổ chức theo 5 thư mục nghiệp vụ:

| Thư mục | Dataset |
|---|---|
| **Danh mục nền** (3) | Danh mục khoản mục chi phí · Danh mục đơn vị tính và quy đổi · Danh mục phòng ban và trung tâm chi phí |
| **Mua hàng – Vật tư** (4) | Danh mục vật tư – hàng hoá · Danh mục nhà cung cấp · Bảng giá mua theo nhà cung cấp · Đơn đặt hàng mua |
| **Kho – Sản xuất** (3) | Định mức nguyên vật liệu (BOM) · Thẻ kho – Tồn kho theo vật tư · Danh mục kho và vị trí lưu trữ |
| **Bán hàng – Khách hàng** (3) | Danh mục khách hàng · Danh mục sản phẩm · Đơn hàng bán và hợp đồng |
| **Nhân sự – Tài sản** (2) | Danh mục nhân sự · Danh mục tài sản và thiết bị |

### 3.3 Grid view — bảng dữ liệu

Mở một dataset là vào **Grid view**. Ví dụ *Danh mục vật tư – hàng hoá* có **41 dòng ×
22 trường**:

Name · Mã vật tư · Đơn vị tính · Quy cách – Thông số kỹ thuật · Vật liệu / Tiêu chuẩn ·
Hãng sản xuất · Xuất xứ · Đơn giá kế hoạch (VNĐ) · Tồn tối thiểu · Nhóm vật tư · Thuế
suất GTGT · Điểm đặt hàng lại · Tồn tối đa · Lead time (ngày) · Kiểm soát chất lượng đầu
vào · Vật tư trọng yếu · Người mở mã · Ghi chú · Ngày mở mã · Trạng thái · Nhà cung cấp
chính · Nhà cung cấp thay thế.

Điều đáng chú ý là **mỗi kiểu dữ liệu hiển thị đúng bản chất của nó**, không phải chuỗi
văn bản chung chung: select có màu (Kg, Cây, Cái, Bộ, Hộp, Mét, Thùng), currency có định
dạng nghìn và hai số lẻ (18,450.00), checkbox thành YES/NO, user có avatar, date thành
"Apr 2, 2021", và **link** trỏ thẳng sang bản ghi ở dataset khác.

Mỗi dòng có số thứ tự, checkbox chọn hàng loạt, tay cầm kéo thả và nút mở rộng. Chân mỗi
cột có nút **Summarize** để tính nhanh tổng / trung bình / đếm.

### 3.4 Bảy công cụ của một view

| Công cụ | Nội dung quan sát được |
|---|---|
| **Add record** | Thêm bản ghi mới ngay trên bảng |
| **Fields** | Ô "Find a field" + công tắc bật/tắt từng trường; nút Hide all / Show all. Trường Name luôn hiển thị |
| **Filter** | "No filter conditions are applied" → **+ Add condition** và **+ Add condition group** (điều kiện lồng nhau) |
| **Group** | "Pick a field to group by" — gợi ý nhanh các trường select, kèm "See all fields" |
| **Sort** | Nhiều cấp: trường + hướng (A → Z) + nút xoá; badge số điều kiện hiện trên nút |
| **Colour** | Hai kiểu tô dòng: **Left border** hoặc **Background color** |
| **Height** | Short / Medium / Tall / Extra Tall + tuỳ chọn **Wrap headers** |

Mọi popup đều theo cùng một mẫu: cấu hình → **Cancel / Save**. Cấu hình lưu vào view,
nên mỗi người có thể có cách nhìn riêng trên cùng một bộ dữ liệu.

**Ba loại view**: Grid view · Gallery view · Kanban view — tạo bằng nút "+" cạnh tab view.

### 3.5 Record detail — chi tiết bản ghi

Bấm nút mở rộng ở đầu dòng, một panel lớn hiện ra với ba khu:

- **Custom fields** — toàn bộ trường và giá trị, mỗi trường kèm icon thể hiện kiểu dữ liệu.
- **Comments** — trao đổi ngay trên bản ghi: đính kèm, emoji, sticker, định dạng chữ,
  tuỳ chọn "Press enter to send".
- **Record information** — Dataset, Updated at, Created at, và ba vai trò người dùng:
  **Owners · Followers · Collaborators**.
- **Activity logs** — dòng thời gian có nhãn kỹ thuật (`record:created`) và ô tìm kiếm.

Chân panel: "Edited 21 hours ago by You" + nút **Edit record**. Menu "..." cho Edit / Remove.

> **Giá trị**: mọi tranh luận về một mã vật tư nằm ngay cạnh mã vật tư đó, không lạc trong
> email hay group chat. Và luôn trả lời được câu "ai đổi cái này, lúc nào".

### 3.6 Trường (Field) — 3 phạm vi, 28 kiểu

Vào **menu dataset → Manage fields**. Trường được nhóm theo **phạm vi**, mỗi trường hiển
thị số thứ tự, tên, badge phạm vi, kiểu dữ liệu, mã code (`int_1`) và badge
**ON FORMS** / **IN VIEWS**.

**Ba phạm vi trường** (nguyên văn trong app):

| Phạm vi | Mô tả |
|---|---|
| **Global Field** | *"Available to every service in the tenant. Use for cross-cutting fields like Department or Notes."* |
| **Service Field** | *"Scoped to services of model 'dataset.dataset'. Other services with the same model can attach it."* |
| **Internal Field** | *"Lives only on this service. No shared-pool row. Best for one-off, service-specific data."* |

Đây chính là lý do con số **311 custom field dùng chung** ở trang Home có ý nghĩa: khai
báo "Phòng ban" một lần ở cấp Global, mọi app trong tenant dùng chung một danh mục, không
còn cảnh mỗi bảng một cách viết tên phòng ban.

**28 kiểu trường** (dropdown TYPE, có ô tìm kiếm):

Two-way link dataset record · Text · Long Text · Integer · Decimal · Date · Date & Time ·
Time · Checkbox · Dropdown · Multi-Select · File · Files · Rich Text · Formula · Lines ·
Rating · User · Table · Email · URL · Phone · Currency · Message · Progress · Users ·
Two-way link rollup · Two-way link lookup.

Form tạo trường gồm: **LABEL** (bắt buộc) · **CODE** (tự sinh từ label, tiền tố
`custom_...`) · **TYPE** · **PLACEHOLDER**.

### 3.7 Visualize schema — sơ đồ quan hệ

**Menu dataset → Visualize schema** mở sơ đồ ERD kéo/thu phóng được. Mỗi dataset là một
thẻ liệt kê từng trường kèm **nhãn kiểu dữ liệu** ở mép phải (primary, link, text,
textarea, select, select-m, currency, float, int, checkbox, user, date, email, phone,
url, rating, progress). Đường nối giữa các thẻ có nhãn quan hệ **N : 1**, **N : N**.

Chú giải phân biệt ba loại liên kết:

- **Two-way link** (nét liền) — liên kết hai chiều giữa hai dataset
- **Lookup / Rollup** (nét đứt) — lấy giá trị / tổng hợp từ dataset liên kết
- **App embed** (nét chấm) — nhúng vào app

> **Giá trị**: khi mô hình dữ liệu đã có 15 bảng và 311 trường, đây là màn hình duy nhất
> trả lời được câu "sửa trường này thì hỏng cái gì" trước khi sửa.

### 3.8 Cài đặt dataset — 5 nhóm

| Nhóm | Nội dung |
|---|---|
| **General info** | Tên · Icon · Color (hex) · Folder · công tắc *Custom naming for your records* và *Custom leading field name* · 3 checkbox: cho phép select ở chế độ public, cho phép dùng trong Advance table field ở app khác, bật phân trang cho dataset lớn |
| **Accesses & visibility** | **Dataset owners** · **Dataset followers** · **Record visibility** hai mức: *"Anyone who can access the dataset can view all record details"* hoặc *"Only record owners/followers/collaborators can view record details"* |
| **Manage fields** | Xem mục 3.6 |
| **Manage views** | Kéo thả đổi thứ tự, công tắc ẩn/hiện, Rename / Delete từng view, nút **+ Create view** |
| **AI grounding** | Xem mục 3.10 |

### 3.9 Import / Export

**Import records** — *"from Excel (.xlsx) or CSV. Download the template, fill it in, upload."*

- **What to do**: *Create new records* hoặc *Update existing records*
- Checkbox *"Skip rows that repeat an id already in the file"* (bật sẵn) — chống trùng
- Checkbox *"Run in the background"* — *"Large files always run in the background… you can
  close this dialog and the import keeps going."*
- Nút **Download template** — tải file mẫu đúng cấu trúc trước khi điền
- Bảng **Columns (23)** ánh xạ rõ từng cột: tên hiển thị ↔ kiểu ↔ mã trường
  (`Đơn giá kế hoạch (VNĐ) → currency · don_gia_kh`), với `id` = *"leave blank to create;
  required to update"*

**Export records** — *"Download … as a spreadsheet you can edit and re-import"*, chọn
**Excel (.xlsx)** (*"keeps the columns typed"*) hoặc **CSV** (*"opens anywhere"*), có tuỳ
chọn chuẩn bị nền cho file lớn.

> **Giá trị**: vòng khép kín **Export → sửa trên Excel → Import lại**. Đội nghiệp vụ vẫn
> được làm việc bằng công cụ họ quen, dữ liệu vẫn về một mối.

### 3.10 Rework AI — trợ lý AI trên dữ liệu

Mở từ nút **Rework AI** trên trang Home; hiện thành panel bên phải, có thể mở rộng toàn
màn hình, xem lại lịch sử hội thoại, mở hội thoại mới.

Màn hình chào đưa gợi ý **bám theo dữ liệu thật của tenant**, không phải gợi ý mẫu:
*"Summarize Danh mục vật tư – hàng h… (41 records)"* · *"Create a dashboard"* ·
*"Build me a CRM"* · *"How do I share a dataset?"*

**Cú pháp nhập**: `@` nhắc tới bảng / view / bản ghi · `/` gọi lệnh · `Shift + Enter`
xuống dòng.

**Menu lệnh `/` — 6 nhóm, 21 lệnh:**

| Nhóm | Lệnh |
|---|---|
| Dataset | Create dataset · Summarize records · Generate sample records · Delete dataset |
| Record | Add records · Update records · Fill empty cells · Filter records · Delete records |
| Field | Add field · **Add AI field** · Link / Lookup / Rollup |
| View | Create view · Filter view · Sort view · Group view |
| Folder | Create folder |
| App & Chart | **Build an app** · Add a chart |

**Chọn model**: Auto (mặc định) · Sonnet 5 · Opus 5 · Gemini 3.6 Flash · GPT-5.6 Luna ·
GPT-5.6 Sol · Grok 3 — các model ngoài Auto chỉ bật khi đã khai khoá nhà cung cấp tương ứng.

**Thử nghiệm thực tế đã ghi hình.** Câu hỏi (gõ không dấu):
*"Trong dataset Danh muc vat tu – hang hoa, nhom vat tu nao co tong don gia ke hoach cao nhat?"*

AI hiển thị các bước suy luận trước khi trả lời:
1. *"Tôi cần xem cấu trúc của dataset Danh mục vật tư – hàng hoá để xác định chính xác tên
   các cột Nhóm vật tư và Đơn giá kế hoạch."*
2. *"Tôi sẽ dùng biểu đồ thanh để tính tổng đơn giá kế hoạch theo từng Nhóm vật tư nhằm
   tìm ra nhóm có tổng cao nhất."*

Kết quả: câu trả lời **bằng tiếng Việt có dấu** — *"Xác định nhóm vật tư có tổng đơn giá
kế hoạch cao nhất là Vật tư điện – tự động hoá"* — kèm **biểu đồ cột**, hai nút
**Snapshot** / **Add to app**, và hai gợi ý đào sâu (Follow up).

> **Giá trị**: AI ở đây không dừng ở hỏi–đáp. Nó **thao tác được trên cấu trúc** (tạo
> dataset, thêm trường, dựng view, dựng app) và **kết quả phân tích đi thẳng vào dashboard**
> bằng một nút bấm.

**AI grounding** (trong cài đặt từng dataset) là nơi "dạy" AI hiểu ngữ nghĩa dữ liệu của
riêng doanh nghiệp:
- *Dataset instructions*: *"Natural-language guidance the AI copilot uses when answering
  about or editing this dataset (e.g. active means status = 1, revenue is in USD)."*
- *Field descriptions*: mô tả từng trường — *"Describe what each field means so the AI
  resolves the right one."*

### 3.11 Apps — biến dataset thành ứng dụng

7 app trong tenant demo: Asset Tracking · Quản lý suất ăn · Inventory Management ·
Simple CRM · Applicant Tracker · Sale · Sale Kit.

Cấu trúc: **App → nhiều page (tab) → nhiều block**. Các loại block quan sát được:

- **Metric** — một con số lớn kèm phép tính: Deals = 8 (*count*), Total amount = 340,000 (*sum*)
- **Chart** — biểu đồ cột theo nhóm: Deals by stage, Value by stage
- **Grid** — bảng dữ liệu nhúng: All deals
- **Form** — biểu mẫu nhập liệu cho người dùng cuối: New contact

Block chưa cấu hình hiển thị *"Not configured — Choose a source, group-by field and function."*

**Quyền không bị vượt mặt.** Khi người xem không có quyền vào dataset nguồn, block hiện
biểu tượng khoá và dòng *"No access to this data — Ask the owner of the underlying dataset
or database for access."* App là lớp trình bày, **quyền vẫn nằm ở tầng dữ liệu**.

### 3.12 Templates

*"Start a new app from a prebuilt template."* — 5 nhóm danh mục (Recommended, Project &
Tasks, Sales & CRM, HR & Ops, Growth & Marketing), 4 template trong Recommended:

| Template | Mô tả nguyên văn |
|---|---|
| **Applicant Tracker** | Candidates, open positions and interviews linked together, with per-position candidate counts and per-candidate interview roll-ups. |
| **Content Calendar** | Plan content across channels and authors, with per-channel and per-author content roll-ups. |
| **Simple CRM** | Companies, contacts and a deal pipeline linked together, with per-company revenue roll-ups. |
| **Task Tracker** | Projects, tasks and team members linked together, with per-project task roll-ups and an assignment board. |

Xem trước template Simple CRM cho thấy đây **không phải bảng rỗng**: "3 tables · 7 blocks",
gồm cả cấu trúc bảng (Companies / Contacts / Deals), quan hệ liên kết, roll-up (Deal count,
Pipeline value) và một dashboard hoàn chỉnh với dữ liệu mẫu.

### 3.13 Databases — kết nối CSDL sẵn có

*"Connect a Postgres or Supabase database to browse and edit it here."*

Kiến trúc tách hai tầng, phân vai rõ:

1. **Connection** (Settings → Connections) — quản trị viên hạ tầng tạo, **credentials nằm
   ở đây**: Provider (**PostgreSQL** / **Supabase** / MySQL *"Coming soon"*), connection
   string hoặc Host / Port / Database / User / Password, công tắc **Use SSL**, nút
   **Test connection**.
2. **Database service** (Databases → New database) — người dùng nghiệp vụ chỉ **chọn** một
   connection có sẵn: *"Point this database at an admin-managed connection — credentials
   live on the connection, not here."* Có thể seed sẵn bằng template.

> **Giá trị**: không bắt doanh nghiệp nhập lại dữ liệu đã có trong hệ thống cũ. Và mật
> khẩu CSDL không rơi vào tay người dùng nghiệp vụ.

### 3.14 Settings — AI · Connections · Folders

**AI settings** — *"Bring-your-own LLM key for Rework AI, AI views and AI fields."*

- **Default provider** / **Default model** (tenant demo: Google Gemini / gemini-3.5-flash)
- **Provider keys**: Anthropic · OpenAI · OpenRouter · Google Gemini — mỗi dòng hiện trạng
  thái *Not set* / *Configured*
- **AI mode**: Balanced (recommended) — *"Haiku for quick tasks · Sonnet for chat · Opus
  for planning."*
- **Thinking**: *"Show the AI's reasoning while it works"*
- **Monthly token limit** và **Daily request limit** (0 = unlimited)
- Thống kê sử dụng thực: *"This month: 66,104 tokens · 9 requests / Today: 0 requests"*

**Folders** — 5 thư mục nội dung + Uncategorized (Default folder), mỗi thẻ hiện số dataset.

---

## 4. Thuật ngữ

| Thuật ngữ | Nhãn trong app | Nghĩa |
|---|---|---|
| Dataset | Dataset | Một bảng dữ liệu, tương đương một sheet có kiểu dữ liệu và quyền |
| Record | Record | Một dòng dữ liệu |
| Field | Field | Một cột, có kiểu dữ liệu xác định (28 kiểu) |
| View | View | Một cách nhìn vào dataset (Grid / Gallery / Kanban) kèm filter, sort, group riêng |
| Folder | Folder | Nhóm dataset theo mảng nghiệp vụ |
| App | App | Lớp giao diện dựng trên dataset, gồm page và block |
| Block | Block | Một ô nội dung trong app: metric, chart, grid hoặc form |
| Template | Template | Bộ khởi tạo sẵn cả bảng, quan hệ, roll-up và dashboard |
| Global / Service / Internal Field | badge trên trường | Ba phạm vi dùng chung của trường |
| Two-way link | link | Liên kết hai chiều giữa hai dataset |
| Lookup / Rollup | lookup / rollup | Lấy giá trị / tổng hợp số liệu từ dataset liên kết |
| Rework AI | Rework AI | Trợ lý AI đọc và thao tác được trên dữ liệu |
| AI grounding | AI grounding | Phần "dạy" AI hiểu ngữ nghĩa dữ liệu của doanh nghiệp |
| Connection | Connection | Kết nối hạ tầng tới CSDL ngoài, do quản trị viên giữ credentials |
| Database service | Database | Dịch vụ dữ liệu trỏ vào một connection |
| Snapshot | Snapshot | Chụp giữ kết quả phân tích của AI |
| Summarize | Summarize | Dòng tổng hợp ở chân mỗi cột trong Grid view |

---

## 5. FAQ

**Base Dataset khác Excel ở chỗ nào?**
Ba chỗ nhìn thấy ngay trên màn hình: (1) mỗi cột có **kiểu dữ liệu thật** — currency,
date, user, link — nên không còn "01/02" là ngày hay là chuỗi; (2) các bảng **liên kết
hai chiều** với nhau và sơ đồ quan hệ vẽ ra được; (3) **quyền theo dataset và theo bản
ghi**, cùng nhật ký ai sửa gì lúc nào.

**Dữ liệu đang ở Excel thì đưa vào thế nào?**
Tải template đúng cấu trúc từ hộp thoại Import, điền, upload. File lớn chạy nền. Muốn cập
nhật thay vì tạo mới thì chọn *Update existing records* và điền cột `id`.

**Có phải nhập lại dữ liệu đang nằm trong hệ thống cũ không?**
Không, nếu hệ thống đó là PostgreSQL hoặc Supabase — tạo một Connection rồi trỏ vào, duyệt
và sửa ngay trong Base. MySQL đang ghi *Coming soon*.

**Ai được xem dữ liệu?**
Hai tầng. Tầng dataset: Owners và Followers. Tầng bản ghi: hoặc "ai vào được dataset thì
xem được toàn bộ chi tiết", hoặc "chỉ owner / follower / collaborator của bản ghi mới xem
được chi tiết". App **kế thừa** quyền này, không vượt qua được.

**AI có tự ý sửa dữ liệu không?**
AI chạy theo lệnh người dùng đưa vào. Bộ lệnh `/` có cả nhóm ghi (Add / Update / Delete
records) lẫn nhóm chỉ đọc (Summarize records). Trong lần thử nghiệm ghi hình, câu hỏi chỉ
yêu cầu trả lời và AI chỉ đọc, không sửa.

**Chi phí AI kiểm soát ra sao?**
Doanh nghiệp **tự mang khoá LLM của mình** (Anthropic / OpenAI / OpenRouter / Google
Gemini), tự chọn model, và đặt được **Monthly token limit** cùng **Daily request limit**.
Màn hình Settings hiển thị mức tiêu thụ thực tế trong tháng.

**Triển khai mất bao lâu?**
Có 4 template dựng sẵn cả bảng, quan hệ, roll-up và dashboard — bấm "Use this template"
là có ngay bộ khung. Ngoài ra Rework AI có lệnh *Build an app* và *Create dataset* để dựng
từ mô tả bằng lời.

**Xuất dữ liệu ra được không?**
Được, Excel (.xlsx) giữ nguyên kiểu cột hoặc CSV mở được ở mọi nơi. File xuất ra sửa xong
import ngược lại được.

**Có bao nhiêu kiểu dữ liệu?**
28 kiểu, từ Text/Integer/Date cơ bản tới Formula, Rating, Progress, Currency, User/Users,
File/Files và ba kiểu liên kết (Two-way link record / rollup / lookup).

---

## 6. Ghi chú về phạm vi tài liệu

- Ảnh minh hoạ trong bộ tài liệu này là **ảnh dựng lại** từ nội dung đọc được trên màn hình
  (Claude in Chrome không lưu được ảnh chụp gốc ra file). Bố cục, nhãn và số liệu bám sát
  màn hình thật; chi tiết nhỏ về pixel có thể lệch.
- Tenant khảo sát là môi trường **DEMO** với dữ liệu mẫu ngành cơ khí chế tạo.
- Phiên khảo sát ở chế độ **chỉ đọc** — không tạo, sửa hay xoá bản ghi nào.
- **Chưa xác định**: giao diện Gallery view và Kanban view (chưa tạo view mới nên chưa
  thấy); trình dựng app (app builder) ở chế độ chỉnh sửa; cơ chế Automation / Webhook /
  API công khai (không thấy mục riêng trong điều hướng); hành vi tìm kiếm toàn cục — các
  từ khoá đã thử đều trả về "No results found".
