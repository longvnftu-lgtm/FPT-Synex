# Base AgentHub — Tổng hợp tính năng

> Nguồn: ghi hình trực tiếp màn hình ứng dụng tại `agenthub.base.com.vn` (workspace Base Inc), ngày 23/08/2026.
> Toàn bộ nội dung dưới đây chỉ mô tả những gì hiển thị trên giao diện. Chỗ nào giao diện không thể hiện, tài liệu ghi *chưa xác định*.

---

## 1. Tổng quan sản phẩm

AgentHub là ứng dụng trong bộ Base.vn, dùng để **tạo và vận hành trợ lý AI nội bộ** cho từng phòng ban. Một trợ lý (agent) trong AgentHub gồm bốn phần ghép lại:

| Thành phần | Vai trò |
|---|---|
| **Instruction + Model** | Định nghĩa vai trò, giọng văn, giới hạn và mô hình ngôn ngữ dùng để trả lời |
| **Knowledge** | Kho tài liệu nội bộ agent được phép tra cứu và trích dẫn |
| **Skills** | Bí quyết làm việc tái sử dụng (soạn .docx, .xlsx, .pptx, PDF, so sánh tài liệu… và skill do công ty tự viết) |
| **Tools** | Việc agent tự làm được trong lượt trả lời: tính toán, gọi API, đọc dữ liệu từ app Base khác, hoặc gọi một agent khác |

Người dùng cuối chỉ thấy một khung chat. Người quản trị thấy đầy đủ cấu hình, nhật ký từng lượt hỏi và số liệu vận hành.

**Chỗ đứng trong hệ sinh thái Base**: bấm tên workspace ở đáy thanh trái mở bảng ứng dụng Base.vn (workspace đang khảo sát có 85 ứng dụng, 110 người dùng). AgentHub nằm ở nhóm *AI & Agent Ops* cùng Agent, Studio, Atlas, Architecture, Knowledge.

---

## 2. Bản đồ tính năng

```
AgentHub
├── New chat ................. khung chat chung, chọn agent bất kỳ để hỏi
├── Agents ................... danh sách trợ lý
│   └── Agent detail
│       ├── Orchestrate ...... cấu hình (Build) hoặc sơ đồ khối (Map) + Chat preview
│       ├── Monitoring ....... số liệu vận hành 7/30/90 ngày
│       ├── Logs ............. nhật ký từng lượt hỏi + dấu vết các bước
│       └── Access ........... ai sở hữu, ai được chat
├── Knowledge ................ danh sách kho tri thức
│   └── Knowledge base detail
│       ├── Files ............ tài liệu đã nạp
│       ├── Retrieval testing  thử truy hồi trước khi giao cho agent
│       ├── Logs ............. nhật ký nạp và xử lý tài liệu
│       ├── Settings ......... retrieval, chunking, OCR, index, embedding
│       └── Access ........... chủ sở hữu, người đọc, phạm vi agent được trả lời
├── Folders .................. nhóm agent theo khối/phòng ban
├── Agent library ............ 20 mẫu agent dựng sẵn
├── My integrations .......... tài khoản cá nhân đã kết nối
└── Settings
    ├── Preferences .......... thiết lập cá nhân (font câu trả lời)
    ├── Folders .............. quản lý thư mục
    ├── Providers ............ nhà cung cấp mô hình (LLM / Embedding / Image / TTS)
    ├── Skills ............... 7 skill dựng sẵn + skill tự tạo
    ├── Tools ................ Tool plugin · MCP · Custom (OpenAPI) · Rework apps · Tool groups
    └── Advanced ............. Utility model dùng chung cho tác vụ nền
```

---

## 3. Chi tiết từng tính năng

### 3.1 New chat — khung hỏi đáp chung

- Lời chào cá nhân hoá theo tên người đăng nhập.
- Chip **chọn agent** ngay trên ô nhập: menu "CHOOSE AN AGENT" liệt kê mọi trợ lý kèm mô tả ngắn.
- **Attach files**: đính kèm tệp vào câu hỏi.
- **Insert an action** (hoặc gõ `/`): 9 hành động — Deep research · Compare documents · Create slides · Create document · Create PDF · Create spreadsheet · Create web page · Create chart · Create diagram.
- **Mức suy luận** chọn theo từng câu hỏi:

| Mức | Mô tả nguyên văn trên giao diện |
|---|---|
| Instant | *The default – fastest answers, few tool rounds, no deep deliberation* |
| Medium | *Balanced – full tool use, standard budgets* |
| High | *Maximum capacity – may escalate a research question into a multi-minute investigated report* |

### 3.2 Agents — danh sách trợ lý

Lưới thẻ 4 cột, mỗi thẻ có icon màu, tên, mô tả, mốc cập nhật và hai nút **Customize** / **Chat →**. Có ô tìm kiếm, sắp xếp (*Last updated*), lọc theo thư mục và bộ đếm tổng số agent.

Menu `⋯` trên mỗi thẻ: **Pin to sidebar · Edit · Move to folder · Duplicate · Delete**.

### 3.3 Agent · Orchestrate (chế độ Build)

Cột trái là cấu hình, cột phải là **Chat preview** chạy thật ngay trong màn hình cấu hình.

| Khối | Nội dung cấu hình |
|---|---|
| **AI Settings** | Model (dropdown gom theo nhà cung cấp); Instruction (ô soạn thảo dài); công tắc Image generation; công tắc Audio generation |
| **Skills** | Đính kèm skill dựng sẵn và skill tự tạo. App tự cảnh báo chất lượng, ví dụ *"2 of 3 attached skills may not trigger when they should"* |
| **Computer** | Công tắc bật/tắt |
| **Tools** | Mở modal "Add tools" (mục 3.4) |
| **Attachments** | Tài liệu agent tham chiếu; *"A .docx using {tag} placeholders also becomes a fillable template"* |
| **Knowledge** | Chọn nhiều knowledge base, có cấu hình tìm kiếm riêng cho agent |
| **Conversation opening** | Greeting · Tagline · Conversation starters (chip) |
| **Deep document read** | *Off — first pages only* / *Ask the user first* / *Always read in full* |
| **Memory** | Công tắc bật/tắt; ô "What to remember"; công tắc "Notes the agent keeps" (agent tự ghi chú vào thư mục riêng và đọc lại ở hội thoại sau); "End users (API)": *Off* hoặc *Auto-learn — remember and apply immediately* |

Giao diện luôn hiển thị **chi phí token cố định** của cấu hình, ví dụ: *"Instructions and tools cost about 3,464 tokens on every message. That is about 3% of this model's context window."*

Thanh trên có nút **Build / Map**, badge trạng thái **Saved**, biểu tượng **lịch sử phiên bản** và nút **Save** với hai lựa chọn **Save only** / **Save and publish**.

### 3.4 Modal "Add tools" — nơi agent được cấp quyền hành động

Sáu tab:

| Tab | Nội dung |
|---|---|
| **Tool plugin** | 20 plugin dựng sẵn, chia nhóm Web search · Email · Calendar & meetings · Documents & notes · Spreadsheets & tables · Projects & tasks · Forms & surveys · Knowledge · Files · Data · Utility |
| **MCP** | Connector MCP của workspace (Featured connectors + Custom connectors) |
| **Custom** | API riêng khai bằng OpenAPI |
| **Rework apps** | Toàn bộ ứng dụng Base khác, chọn tới từng operation |
| **Tool groups** | Nhóm công cụ do workspace định nghĩa |
| **Agents** | Dùng agent khác làm công cụ (*agent-as-tool*) |

Chân modal luôn hiển thị ba con số giúp kiểm soát chất lượng: **số tool đã chọn / tổng**, **≈N tokens of tool definitions, every turn**, và cảnh báo **"N definitions the model may struggle to choose between"**. Kèm ô thử *"Ask something the way a user would — see which tool it picks"*.

Danh sách 20 tool plugin:

| Nhóm | Plugin |
|---|---|
| Utility | Time · Calculator · Fetch URL · HTTP request |
| Data | JSON · Regex |
| Knowledge | Knowledge catalog (*"the inventory question retrieval cannot answer"*) |
| Files | Spreadsheets |
| Web search | Serper · Brave · Exa · Tavily · Firecrawl |
| Google | Calendar · Tasks · Forms · Drive · Gmail · Sheets · Docs |

Nhóm **Rework apps** trải khắp bộ Base, gom theo: AI & Agent Ops · Sales & Commerce Operations · GTM Operations · Work Operations · People Operations · Customer Operations · Finance Operations · Official Communications. Mỗi ứng dụng ghi rõ số operation và trạng thái kết nối; một số operation gắn nhãn **"Asks first"** (hỏi người dùng trước khi chạy).

### 3.5 Agent · Orchestrate (chế độ Map)

Sơ đồ khối đọc từ trái sang phải:

```
Chat input → [Knowledge base · Agent as a tool · Memory · Skills] → Agent (CORE) → Reply
```

Khối **Agent (CORE)** tóm tắt: trích đoạn Instruction, Model + nhà cung cấp, Knowledge (*"1 sources · hybrid"*), Toolsets (*"3 attached"*), Input, Response và *"Has an opening message · 3 starters"*.

### 3.6 Version history

Bảng **Versions** liệt kê **Current draft** cùng toàn bộ phiên bản v1…vN, mỗi dòng ghi thời điểm và người sửa. Phiên bản đang chạy gắn nhãn **LATEST** và **PUBLISHED** — nên bản nháp và bản đang phục vụ người dùng tách bạch.

### 3.7 Agent · Monitoring

- Khoảng thời gian **7d / 30d / 90d** (đếm theo UTC).
- Bốn chỉ số lớn: **MESSAGES · CONVERSATIONS · ACTIVE USERS · TOKENS**.
- Dải chỉ số chất lượng: Turns per conversation · Avg response time · Slowest 5% · Tokens/second · Helpful (trên số lượt được chấm) · **Tool success** · **Prompt cache hits** · Errors.
- Bảng **Tools**: TOOL · CALLS · ERRORS · FAILURE · RESULT P50 · P95 · LARGEST · **SHARE OF CONTEXT** · TIME P50.
- Bốn biểu đồ: Messages per day (tách **Console** = dùng trong studio và **API** = gọi qua `/v1`) · Tokens per day (gồm OCR, research, memory; tách Input/Output) · Conversations & active users · Avg response time.
- Khối **Feedback**.

### 3.8 Agent · Logs — nhật ký và dấu vết

Hai chế độ xem **Messages / Conversations**; lọc theo model, theo đánh giá, hoặc chỉ lỗi (*Errors only*).

Bảng: ID · QUERY (kèm trích đoạn câu trả lời) · MODEL · TOKENS (vào/ra) · LATENCY · **SOURCE** (CONSOLE hay API) · FEEDBACK · TIME.

Bấm một dòng mở bảng chi tiết:

- **STEPS** — dấu vết đánh số từng bước kèm thời gian: `Request → Retrieval & prompt → Model call → knowledge_search (kèm đúng truy vấn agent tự đặt) → … → Response`, tổng kết *"3 model calls · 3 tool calls"*.
- **ANSWER** đầy đủ.
- **RE-RUN THIS TURN** — chạy lại đúng câu hỏi đó trên cấu hình hiện tại, có thể đổi model: *"Nothing is saved to the conversation; the tokens are billed to this app."*
- **MESSAGE** — Model, Tokens, Latency, Feedback.

### 3.9 Agent · Access

- **Owners** — toàn quyền Orchestrate, Monitoring, Logs, Access và mọi hội thoại; luôn giữ ít nhất một owner; admin app của workspace luôn quản trị được.
- **Who can chat**: *Only the people listed below* hoặc *Everyone in the workspace*.
- **Chat members**: *"They can chat with the agent and see only their own conversations — not Orchestrate, Monitoring or Logs."*
- Nguyên tắc nền: *"Chatting never includes seeing how the agent is built."*

### 3.10 Knowledge base

**Danh sách**: thẻ kèm emoji, mô tả và dòng chân *"N documents · text-embedding-3-small"*. Tạo mới từ đầu hoặc **Create from template** — 11 preset theo loại nội dung, mỗi preset ghi rõ cách cắt chunk và định dạng hỗ trợ:

| Preset | Cách cắt | Định dạng |
|---|---|---|
| General | Cắt theo đoạn rồi gộp tới hạn token | MD · DOCX · XLSX · PPTX · PDF · TXT · HTML · CSV |
| Q&A | Mỗi cặp hỏi–đáp là một chunk | XLSX · CSV · TXT |
| Resume | Bóc CV thành trường có cấu trúc | DOCX · PDF · TXT |
| Manual | Cắt theo tiêu đề mục thấp nhất, giữ hình và bảng cùng mục | PDF |
| Table | Mỗi dòng là một chunk, dòng đầu là tiêu đề cột | XLSX · CSV · TXT |
| Paper | Cắt theo mục (abstract, 1.1, 1.2…) | PDF |
| Book | Cắt theo chương, bỏ phần đầu sách | DOCX · PDF · TXT |
| Laws | Cắt theo điều, giữ tiêu đề cấp trên trong mỗi chunk | DOCX · PDF · TXT |
| Presentation | Mỗi trang chiếu là một chunk | PDF · PPTX |
| One | Cả tài liệu là một chunk | DOCX · XLSX · PDF · TXT |
| Tag | Cặp mô tả–thẻ dùng để gắn nhãn chunk ở kho khác | XLSX · CSV · TXT |

**Files**: nạp bằng *Upload file · Add text · Add Q&A · Import from website · Metadata*. Bảng tài liệu có cột NAME · MODE · CHARS · HITS · UPLOADED · EMBEDDED · STATUS · ENABLED (bật/tắt từng tài liệu). Menu từng tài liệu: Preview file · Rename · Edit text · Download · Metadata · View chunks · Re-index · Archive · Delete.

**Retrieval testing**: gõ câu hỏi thật, xem đúng những chunk nào được lấy ra và điểm số bao nhiêu, trước khi giao kho cho agent. Tham số thử: Search mode (Vector / Keyword / Hybrid), Top K, Score threshold, cân bằng semantic ↔ keyword, lọc theo tên tài liệu, và **Reorder results (lost-in-the-middle)**.

**Settings** (6 khối):

| Khối | Nội dung |
|---|---|
| General | Icon, Name, Description |
| Retrieval | Search mode · Semantic↔keyword balance · Top K (1–20) · Score threshold · Rerank results. *Có hiệu lực ngay ở lần tìm kế tiếp, không cần index lại* |
| Chunking | General hoặc Parent-Child · Delimiter · Maximum chunk length · Chunk overlap · tiền xử lý văn bản · cắt theo cấu trúc (tiêu đề markdown, Q&A) · **Structured document mode** (tài liệu pháp lý: cắt theo Điều/Chương) · **Summary index** · **Table sentences**. *Đổi cấu hình là chunk lại và embed lại TOÀN BỘ tài liệu* |
| OCR | Vision OCR cho PDF scan |
| Index method / Embedding | Đặt lúc tạo, không đổi được về sau |
| Danger zone | Xoá vĩnh viễn kho cùng tài liệu và chunk |

**Access**: Owners · Readers (chỉ đọc, chạy được Retrieval testing, không thấy Logs) · và câu hỏi riêng **"Who can agents answer from this knowledge base?"** — cho phép mọi người chat với agent được trích kho này, hoặc chỉ những người có tên; trường hợp sau agent sẽ *"answer everyone else without this knowledge base, and say that a source was left out"*.

### 3.11 Skills

- **7 skill dựng sẵn**: Skill Creator · Word documents · Spreadsheets · Slide decks · PDF files · Document comparison · Frontend design direction. Mô tả mỗi skill nêu rõ *dùng khi nào* và *không dùng cho việc gì*.
- **Skill tự tạo**: viết trực tiếp hoặc **Upload from file / Upload skill bundle (.zip)**. Mở một skill thấy DESCRIPTION và CONTENT (xem bản render hoặc mã nguồn), có nút Edit và Delete.

### 3.12 Tools (Settings)

- **Tool plugin** — 20 plugin nêu ở mục 3.4. Plugin chưa khai khoá API có dấu cảnh báo; plugin chưa được đăng ký trên máy chủ ghi rõ *"Not set up on this server yet — an operator registers it in the server config."*
- **MCP** — Featured connectors (chọn sẵn) và Custom connectors do workspace khai, mỗi connector ghi số tool và có cần đăng nhập hay không.
- **Custom** — khai API riêng bằng **OpenAPI (JSON hoặc YAML)**: dán spec hoặc điền form, hệ thống tự phân tích ra danh sách operation (method + operationId + đường dẫn) và cho chọn kiểu Authentication.
- **Tool groups** — gom nhiều tool thành một nhóm có tên và mô tả nghiệp vụ, để gắn một lần cho nhiều agent thay vì chọn lẻ từng tool.

### 3.13 Providers

Khai nhà cung cấp mô hình theo từng năng lực: **LLM · Embedding · Image · TTS**. Mỗi provider gồm Name, API key, nút **Load models** và các ô Chat models / Embedding models / Vision models / Image models / Text-to-speech models. Có nút kiểm tra kết nối cho từng provider.

### 3.14 Folders

Nhóm agent theo khối hoặc phòng ban — *"Group agents so the workspace stays navigable as it grows"*. Mỗi thư mục có icon, mô tả, số agent; trang thư mục có nút **Create agent** và menu **Manage** (Edit folder / Delete folder). Thư mục hiện luôn trên thanh trái.

### 3.15 Agent library

20 mẫu agent dựng sẵn, lọc theo nghiệp vụ (Sales, Leads, Meetings, Hiring, Expenses, Projects, Contracts, Workflows, Requests, Docs). Trang chi tiết một mẫu gồm **Overview · Capabilities · Agent flow** (các bước đánh số) **· Sample output** (một bản kết quả mẫu đầy đủ), cùng cột phải **Best for · Service models · Core engines · Related agents**. Nút **Use template**; giao diện ghi *"Templates will pre-configure the agent — coming soon."*

### 3.16 Chat với agent

- Cột giữa: **New chat · Chats · Library** và danh sách **RECENTS**.
- Khi trả lời, giao diện hiện **tiến trình theo thời gian thực**: nhãn gộp (ví dụ *"Ran 4 calculations"*) kèm từng bước agent tự thuật bằng tiếng Việt và đồng hồ đếm giây cho bước đang chạy.
- Dưới mỗi câu trả lời: sao chép, đánh giá tốt/chưa tốt, tạo lại, rẽ nhánh, lưu.
- **Chats**: bảng hội thoại, lọc All / Today / Last 7 days / Older, chọn nhiều để xử lý hàng loạt.
- **Library**: mọi tệp agent đã tạo — Slides · Docs · PDF · Sheets · Images · Audio · Web — xem **Mine** hoặc **All users**.

### 3.17 Tìm kiếm toàn cục

Ô "Search anything…" (⌘K) tìm gộp trên **Agents · Folders · Knowledge · Documents · Chats · Library**, kết quả gom nhóm, điều hướng bằng bàn phím.

---

## 4. Thuật ngữ

| Thuật ngữ | Nghĩa trong AgentHub |
|---|---|
| **Agent** | Một trợ lý AI đã được cấu hình cho một việc cụ thể |
| **Orchestrate** | Màn hình cấu hình agent; có hai cách xem là **Build** (biểu mẫu) và **Map** (sơ đồ khối) |
| **Knowledge base** | Kho tài liệu đã được cắt chunk và embed để agent tra cứu |
| **Chunk** | Mẩu tài liệu sau khi cắt — đơn vị được truy hồi và trả về cho mô hình |
| **Embedding** | Mô hình biến văn bản thành vector để tìm theo ngữ nghĩa |
| **Hybrid search** | Kết hợp tìm theo vector (ngữ nghĩa) và tìm toàn văn (từ khoá) |
| **Top K** | Số chunk lấy ra cho mỗi truy vấn |
| **Rerank** | Chấm điểm lại các ứng viên hàng đầu để tăng độ chính xác, đổi lại thêm một lần gọi mô hình |
| **Parent-Child chunking** | Truy hồi bằng chunk con nhỏ, nhưng trả về cả khối cha làm ngữ cảnh |
| **Summary index** | Index thêm bản tóm tắt do LLM viết cho mỗi chunk |
| **Table sentences** | LLM viết lại mỗi dòng bảng thành câu để câu hỏi hội thoại khớp được với dòng |
| **Structured document mode** | Chế độ cắt dành cho văn bản pháp quy: bỏ header chạy và mục lục, cắt theo Điều / Chương |
| **Deep document read** | Mức độ agent được đọc sâu tài liệu dài: chỉ trang đầu / hỏi người dùng / đọc toàn bộ |
| **Memory** | Việc agent nhớ thông tin xuyên hội thoại; kèm tuỳ chọn để agent tự ghi chú riêng |
| **Skill** | Bí quyết làm việc tái sử dụng, đính kèm cho nhiều agent |
| **Tool** | Một hành động agent tự gọi được trong lượt trả lời |
| **Tool group** | Nhóm tool đặt tên theo nghiệp vụ để gắn một lần cho nhiều agent |
| **Agent-as-tool** | Dùng một agent khác như một công cụ của agent hiện tại |
| **MCP** | Chuẩn kết nối để cắm hệ thống ngoài vào làm tool |
| **Rework apps** | Các ứng dụng khác trong bộ Base mà agent gọi được tới từng operation |
| **Source: CONSOLE / API** | Lượt hỏi phát sinh trong giao diện studio, hay qua API `/v1` |
| **Utility model** | Mô hình rẻ dùng cho tác vụ nền (rút trích ký ức, tóm tắt) thay cho model chính |

---

## 5. Câu hỏi thường gặp

**Agent lấy câu trả lời từ đâu?**
Từ Instruction, các knowledge base được gắn, tệp đính kèm của agent, và kết quả các tool nó gọi trong lượt đó. Trang **Logs** cho xem đúng chuỗi bước đã chạy của từng câu hỏi.

**Người dùng thường có xem được cách agent được dựng không?**
Không. Giao diện ghi rõ *"Chatting never includes seeing how the agent is built"*; người được gắn quyền chat chỉ thấy hội thoại của chính mình, không thấy Orchestrate, Monitoring hay Logs.

**Sửa cấu hình xong có ảnh hưởng ngay tới người dùng không?**
Không, trừ khi chọn **Save and publish**. **Save only** giữ bản nháp; bảng Versions cho biết phiên bản nào đang là LATEST/PUBLISHED và cho xem lại các phiên bản trước.

**Đổi cấu hình tìm kiếm của kho tri thức có phải nạp lại tài liệu không?**
Không. Nhóm **Retrieval** có hiệu lực ngay ở lần tìm kế tiếp. Nhưng đổi nhóm **Chunking** thì hệ thống sẽ chunk lại và embed lại **toàn bộ** tài liệu trong kho, và sẽ hỏi xác nhận trước khi chạy.

**Có kiểm tra được chất lượng tra cứu trước khi mở cho người dùng không?**
Có. Tab **Retrieval testing** cho gõ câu hỏi thật và xem đúng những chunk nào được lấy ra kèm điểm số; lịch sử thử được lưu lại.

**Gắn nhiều tool cho một agent có hại gì không?**
Có hai cái giá, và giao diện hiển thị cả hai: định nghĩa tool tốn token ở **mọi** lượt trả lời (*"≈583 tokens of tool definitions, every turn"*), và tool mô tả giống nhau khiến mô hình chọn nhầm (*"N definitions the model may struggle to choose between"*). Ô thử trong modal cho phép gõ một câu hỏi và xem mô hình chọn tool nào.

**Một agent có gọi được agent khác không?**
Có — tab **Agents** trong modal Add tools cho phép gắn agent khác làm công cụ, để agent chuyên môn hẹp phục vụ agent đầu mối.

**Đo hiệu quả của agent bằng gì?**
Trang **Monitoring**: số lượt hỏi, số hội thoại, số người dùng thực tế, token tiêu thụ, thời gian trả lời (trung bình và nhóm chậm nhất 5%), tỉ lệ gọi tool thành công, tỉ lệ trúng prompt cache, tỉ lệ lỗi, và tỉ lệ được người dùng chấm là hữu ích.

**Kết nối được với dữ liệu đang nằm trong các app Base khác không?**
Được, qua tab **Rework apps** trong modal Add tools — chọn tới từng operation của từng ứng dụng, một số operation gắn nhãn *"Asks first"*.

**Nếu công ty có API riêng thì sao?**
Khai ở **Settings → Tools → Custom** bằng đặc tả **OpenAPI (JSON/YAML)**; hệ thống tự phân tích ra các operation và cho chọn kiểu xác thực.

**Dữ liệu nhạy cảm trong kho tri thức kiểm soát thế nào?**
Ở tab **Access** của từng kho: danh sách Owners, danh sách Readers, và lựa chọn riêng cho phạm vi agent được trả lời từ kho đó. Khi giới hạn, agent trả lời người ngoài danh sách mà không dùng kho và nói rõ đã bỏ qua một nguồn.

---

## 6. Hạn chế ghi nhận tại thời điểm khảo sát

Ghi theo đúng những gì giao diện hiển thị trong buổi chụp màn hình 23/08/2026 trên workspace Base Inc:

1. **Nạp tài liệu vào knowledge base đang lỗi.** Mọi lần nạp đều dừng ở tác vụ *Parse* với trạng thái *Failed* và `CHARS = 0`; cả 8 kho tri thức của workspace đang có 0 tài liệu. Vì vậy các màn hình Files, Retrieval testing và phần trích dẫn nguồn trong câu trả lời chưa có dữ liệu để minh hoạ.
2. **Các plugin Google** (Calendar, Tasks, Forms, Drive, Gmail, Sheets, Docs) hiển thị *"Not set up on this server yet"*; các plugin web search (Serper, Brave, Exa, Tavily, Firecrawl) có dấu cảnh báo vì chưa khai khoá API.
3. **My integrations** chưa có gì để kết nối: *"No integrations are set up on this server."*
4. **Mẫu dựng sẵn chưa tự cấu hình được** — cả "Knowledge base templates" lẫn "Agent library" đều ghi *"coming soon"*.
