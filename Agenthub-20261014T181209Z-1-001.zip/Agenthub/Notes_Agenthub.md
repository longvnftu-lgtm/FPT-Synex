# AgentHub (agenthub.base.com.vn) — capture notes

Ngày làm: 2026-08-23. Tenant: Base Inc. User: Nghĩa Trần.
Nhiệm vụ: xoá dữ liệu TRiBAT cũ, dựng lại toàn bộ demo cho một doanh nghiệp mới, phủ tối đa tính năng.

## 1. ANATOMY

### 1.1 Điều hướng tầng app (sidebar trái)
- New chat — khung chat chung, chọn agent ở dropdown trên ô nhập
- Agents — danh sách agent (card: icon, tên, mô tả, Updated X ago, nút Customize / Chat)
- Knowledge — danh sách knowledge base
- FOLDERS — cây thư mục gom agent (mặc định có "Uncategorized"); nút + để tạo folder
- (đáy) Agent library — thư viện template agent
- (đáy) My integrations
- (đáy) Settings
- (đáy) Workspace switcher

### 1.2 Settings (tầng app)
PERSONAL
- Preferences
WORKSPACE
- Folders
CAPABILITIES
- Providers — "Configure and manage AI models from different providers".
  Filter: All / For LLMs / For Embedding / For Image Generation / Text to Speech.
  Hiện có 2 provider: "AgentHub Harvey" (LLM), "Harvey AI Assistant" (LLM, Embedding, Image, TTS).
  Mỗi provider có 3 icon: kiểm tra (tia sét) / sửa (bút) / xoá (thùng rác).
  Nút "+ Add provider".
- Skills — "Turn know-how into skills, reuse them anytime". 2 tab: Built-in | Custom.
  Built-in (7): Skill Creator (Authoring), Word documents (Documents), Spreadsheets (Data),
  Slide decks (Documents), PDF files (Documents), Document comparison (Documents),
  Frontend design direction (Design).
  Nút "+ Create skill" (có caret phụ).
- Tools — "Give agents abilities - built in, from Rework, or your own API".
  5 tab: Tool plugin | MCP | Custom | Rework apps | Tool groups.
  * Tool plugin (20): Time, Calculator, JSON, Regex, Fetch URL, HTTP request,
    Knowledge catalog, Spreadsheets, Serper, Brave, Exa, Tavily, Firecrawl,
    Google Calendar*, Google Tasks*, Google Forms*, Google Drive*, Gmail*,
    Google Sheets*, Google Docs*  (* = chưa cấu hình trên server, cần operator đăng ký).
    Nhóm: Web search 5, Email 1, Calendar & meetings 1, Documents & notes 2,
    Spreadsheets & tables 1, Projects & tasks 1, Forms & surveys 1, Knowledge 1,
    Files 1, Data 2, Utility 4.
  * Rework apps — toàn bộ hệ Base: chỉ "Projects" đang bật (5 tools), còn lại "Coming soon".
    Nhóm: AI & Agent Ops, Sales & Commerce Operations, GTM Operations, Work Operations,
    People Operations, Customer Operations...
  * Tool groups — gom tool thành nhóm để agent nạp cả nhóm. Hiện trống. Nút "+ New group".
SYSTEM
- Advanced

### 1.3 Đối tượng AGENT — các pane
Vào Agents > Customize. Sidebar trong agent: Orchestrate | Monitoring | Logs | Access.
Thanh trên phải: "Build" | "Map" | trạng thái Saved | icon lịch sử version | nút "Save" (có caret).

**Orchestrate** (cột trái là cấu hình, cột phải là Chat preview trực tiếp):
1. Header: icon agent, Tên, Mô tả + 3 icon (bong bóng chat / bánh răng / ...)
2. AI Settings
   - Model * (dropdown "Select a provider")  ← BẮT BUỘC, agent cũ đang để trống
   - Instruction (textarea lớn — system prompt)
   - Image generation (toggle)
   - Audio generation (toggle)
3. Skills (+) — "add one to give this app reusable expertise"
4. Computer (toggle)
5. Tools (+) — hiển thị "Instructions and tools cost about N tokens on every message"
6. Attachments (+) — upload file agent tham chiếu; .docx dùng {tag} placeholder thành fillable template
7. Knowledge — multiselect knowledge base + icon cấu hình retrieval
8. Conversation opening — Greeting, Tagline, Conversation starters (+, danh sách chip)
9. Deep document read — dropdown, mặc định "Off — first pages only"
10. Memory — toggle

**Monitoring**: khoảng thời gian 7d/30d/90d. Thẻ: MESSAGES, CONVERSATIONS, ACTIVE USERS, TOKENS.
Dòng chỉ số: Turns per conversation, Avg response time, Slowest 5%, Tokens/second,
Helpful, Tool success, Prompt cache hits, Errors.
Biểu đồ: Messages per day (Console vs API), Tokens per day (Input/Output),
Conversations & active users, Avg response time, Feedback.

**Logs**: lịch sử hội thoại.

**Access**:
- "Who owns this agent" — Owners (multi-person). Full control.
- "Who can chat with this agent" — radio: "Only the people listed below" | "Everyone in the workspace"
- Chat members (multi-person)

### 1.4 Đối tượng KNOWLEDGE BASE — các pane
Sidebar: Files | Retrieval testing | Logs | Settings | Access. Chân trang: N DOCUMENTS, N LINKED AGENTS.

**Files**: bảng NAME / MODE / CHARS / HITS / UPLOADED / EMBEDDED / STATUS / ENABLED(toggle) / ...
Thanh lọc: All, Status, Type, Size, Date Created, Last Updated, Newest first. View list/grid.
Nút "+ Add" (dropdown: Upload file | Add text | Add Q&A | Import from website | Metadata),
"Upload data", "Refresh".
→ **Add text**: modal Name + Text. "Stored as Markdown. Up to 500,000 characters." ← đường bơm nội dung nhanh nhất.

**Settings**:
- GENERAL: icon, Name*, Description
- RETRIEVAL: Search mode (Keyword / Vector / Hybrid), Top K (1–20), Score threshold (toggle),
  Rerank results (toggle). Có nút "Save changes" riêng.
- CHUNKING: chế độ General | Parent-Child; Delimiter (mặc định \n\n); Maximum chunk length (1024);
  Chunk overlap (50); Text pre-processing rules (Replace consecutive spaces…, Delete all URLs…);
  Structure-aware splitting (Merge short pieces…, Split by markdown headings…);
  Structured document mode (toggle — cho tài liệu pháp lý, tách theo Điều/Chương).
- OCR: Vision OCR for scanned PDFs (toggle)
- INDEX METHOD: Economy | High Quality — **KHOÁ sau tài liệu đầu tiên**. Economy = keyword-only,
  không có embedding → không dùng được Vector/Hybrid.
- EMBEDDING: Model — khoá sau tài liệu đầu tiên.
- DANGER ZONE: Delete this knowledge base.

## 2. QUIRK / CẠM BẪY ĐÃ GẶP
- **Index method khoá sau tài liệu đầu tiên** → phải chọn High Quality NGAY LÚC TẠO nếu muốn Hybrid search.
- Không tìm thấy REST API công khai: patch window.fetch/XHR không bắt được request nào khi điều hướng
  (app dùng RSC/server actions). `/api/v1/agents` trả 404 JSON. → Phải tự động hoá bằng UI.
- performance.getEntriesByType chỉ trả static asset.
- Agent cũ để trống trường Model — agent vẫn lưu được nhưng chat sẽ lỗi.

## 2b. LỖI CHẶN NGHIÊM TRỌNG — nạp tài liệu vào Knowledge base (23/08/2026)
Mọi đường nạp tài liệu đều FAIL với cùng một lỗi hạ tầng phía server:

```
[ERROR] ENOENT: no such file or directory,
open '/app/var/uploads/kb/1/a35566b37d59389255ff3681b63ea896.md'
```

Đã thử và đều hỏng:
- Add > Add text (dán markdown)
- Add > Upload file (bơm File qua DataTransfer vào input[type=file])
- Upload data (wizard 3 bước) với .md và .txt
- Re-index lại tài liệu đã lỗi

Bằng chứng lỗi nằm ở khâu LƯU FILE, không phải parse/embedding:
- Nút "Preview chunks" ở bước 2 của wizard CHẠY ĐÚNG (server tách được chunk, đếm token)
  → server nhận được file và parse được nội dung.
- Nhưng "Preview file" của tài liệu đã tạo báo "Could not load preview"
  → blob không tồn tại trong storage.
- Logs của knowledge base: TASK = "Parse", STATUS = "Failed", CHARS = 0, EMBEDDED = —.

Kết luận: worker parse không đọc được file mà tầng upload đã ghi
(nhiều khả năng upload và worker chạy trên node khác nhau, không chung volume
`/app/var/uploads`). Đây là lỗi vận hành của deployment, KHÔNG phải lỗi thao tác.
Cần đội hạ tầng Base xử lý; sau khi sửa chỉ cần "Re-index" hoặc nạp lại là xong.

### Kỹ thuật bơm file qua Claude-in-Chrome (đã kiểm chứng là chạy được phía client)
Không mở được hộp thoại chọn file của OS, nhưng bơm được File object bằng JS:
```js
const inp = document.querySelector('input[type=file]');
const f = new File([noiDung], 'ten-file.md', {type:'text/markdown'});
const dt = new DataTransfer(); dt.items.add(f); inp.files = dt.files;
inp.dispatchEvent(new Event('change', {bubbles:true}));
```
Lưu ý: sau khi dispatch, `inp.files.length` quay về 0 vì React reset input — đó là
hành vi BÌNH THƯỜNG, không phải thất bại. Ở wizard "Upload data" input có multiple=true
nên nạp được nhiều file một lượt.

## 3. LUỒNG DỰNG MỘT AGENT — đã kiểm chứng (toạ độ ở khung 1456x840)

### 3.1 Tạo agent
Agents → "+ Create agent" (1399,49) → modal:
- Name (727,127) — gõ trực tiếp được vì ô rỗng
- Icon (649,175): mở dropdown → ô "Search icons" chỉ ghi đè được bằng `form_input`,
  gõ phím vào ô này bị NỐI CHUỖI và BackSpace không xoá được (quirk).
  Đặt `form_input` = "" để hiện lại toàn bộ lưới 32 icon.
  Toạ độ lưới icon (4 hàng × 8 cột), x = 575/599/623/647/671/695/719/743:
  - hàng 1 y=233: bot, sparkles, message, messages, brain, cpu, calculator, zap
  - hàng 2 y=257: wand, lightbulb, rocket, compass, target, pen, palette, link
  - hàng 3 y=281: book, cloud, code, terminal, file, search, globe, flask
  - hàng 4 y=305: headphones, user-circle, briefcase, cart, stethoscope, users, shield, bug
- Gradient (824,175)
- Description (727,245)
- Create (874,314)

### 3.2 Cấu hình (Customize → Orchestrate)
- **Model** (479,191). Provider có sẵn trong tenant Base Inc:
  - AgentHub Harvey → `gpt-5.5`
  - Harvey AI Assistant → `gpt-5.6-sol`, `gpt-5.6-terra`
  Agent mới mặc định `gpt-5.5`.
- **Instruction**: KHÔNG phải textarea mà là TipTap/ProseMirror (`div.tiptap.pe-input`).
  `form_input` BÁO LỖI. Cách chạy được (nhanh, giữ nguyên xuống dòng):
  ```js
  window.__setPE = function(text, sel2){
    const el = document.querySelector(sel2 || '.tiptap.pe-input');
    el.focus();
    const sel = window.getSelection(); const r = document.createRange();
    r.selectNodeContents(el); sel.removeAllRanges(); sel.addRange(r);
    document.execCommand('insertText', false, text);
    return el.innerText.length;
  };
  ```
  selectNodeContents + insertText = GHI ĐÈ sạch, không nối chuỗi.
- **Skills**: "Add skills" → modal, click từng thẻ để chọn, "Done" (902,482).
  Có cảnh báo "N of M attached skills may not trigger when they should".
- **Tools**: "Add tools" → 6 tab: Tool plugin | MCP | Custom | Rework apps | Tool groups | Agents.
  Tab "Agents" cho phép agent gọi agent khác.
- **Knowledge**: multiselect, tick checkbox rồi "Close".
- **Conversation opening**: Greeting, Tagline (gõ trực tiếp được).
  Conversation starters: 3 chip tiếng Anh mặc định — xoá bằng dấu × TỪ PHẢI SANG TRÁI
  (xoá trái trước làm trôi toạ độ). Thêm mới bằng "+" → popup có Icon / Label / Message.
- **Deep document read**: dropdown, mặc định "Off — first pages only".
- **Memory**: toggle.
- Lưu: nút **Save** chỉ lưu nháp, agent vẫn "Not published".
  Phải bấm caret cạnh Save (1429,49) → **"Save and publish"** thì badge "Not published" mới mất.

### 3.3 Gán folder
Agents (danh sách) → hover thẻ → "..." → "Move to folder" → chọn folder → Move.

## 4. QUIRK BỔ SUNG
- **Ký tự `&` bị escape thành `&amp;` và LƯU LUÔN vào DB** ở mọi ô text (tên KB, mô tả folder…).
  → TUYỆT ĐỐI không dùng `&` trong bất kỳ ô nhập nào. Viết "và".
- Emoji picker của Knowledge base rỗng (không có emoji nào) → bỏ qua, dùng icon mặc định.
- Icon picker của Folder và của Agent thì chạy tốt (lucide icons).
- Chỉ 9 tool plugin dùng được: Time, Calculator, JSON, Regex, Fetch URL, HTTP request,
  Knowledge catalog, Spreadsheets (+ Choose). Các engine tìm kiếm web (Serper, Brave, Exa,
  Tavily, Firecrawl) và bộ Google KHÔNG chọn được vì chưa đăng ký trên server.
- Rework apps: chỉ "Projects" bật (5 tools), toàn bộ còn lại "Coming soon".

## 5. LỖI MODEL PROVIDER (23/08/2026)
Tenant Base Inc có 2 provider LLM:
- **AgentHub Harvey** → `gpt-5.5` — CHẠY TỐT trong chat agent (có tool calling, knowledge search).
- **Harvey AI Assistant** → `gpt-5.6-sol`, `gpt-5.6-terra` — chat agent LUÔN báo
  "The model provider returned an error. Try again, or check the provider under Settings > Model providers."

Điểm đánh lừa: nút "Test connection" (biểu tượng tia sét ở Settings > Providers) của
Harvey AI Assistant CHẠY BÌNH THƯỜNG — gửi "ping" trả về "pong", 7 token in / 4 token out.
Nghĩa là API key và endpoint đều đúng; chỉ payload đầy đủ của agent runtime (system prompt dài,
skills, tool definitions, knowledge retrieval) là bị từ chối.

→ Kết luận: dùng `gpt-5.5` cho toàn bộ agent cho tới khi đội vận hành sửa provider
"Harvey AI Assistant". Đã đổi 5 agent từ gpt-5.6-* về gpt-5.5.

## 6. HIỆN TRẠNG BÀN GIAO (23/08/2026)

### 6.1 Tenant đã dựng
- **5 folder**: Kinh doanh và Thị trường · Kỹ thuật và Chất lượng · Nhân sự và An toàn ·
  Sản xuất và Chuỗi cung ứng · Tài chính, Pháp chế và CNTT. Mỗi folder có đúng 2 agent, icon riêng.
- **10 agent** — tất cả đã "Save and publish", model gpt-5.5, có instruction đầy đủ
  (1.700–2.000 ký tự), greeting + tagline tiếng Việt, 2–3 conversation starter là câu hỏi
  nghiệp vụ thật, và đã có ít nhất một hội thoại thật trong Logs:
  1. Trợ lý Báo giá và Chính sách bán hàng — 3 skill, tool group Tính toán, agent-as-tool
     (gọi Trợ lý Thiết kế điện), KB Catalog, Memory BẬT
  2. Trợ lý Hồ sơ thầu và Năng lực — 4 skill, tool group Tra cứu, 2 KB, Deep document read
     "Always read in full"
  3. Trợ lý Thiết kế điện — tool group Tính toán, KB Tiêu chuẩn Kỹ thuật
  4. Trợ lý QA/QC và Khiếu nại chất lượng — skill Document comparison, KB Quy trình Sản xuất
  5. Trợ lý Kế hoạch Vật tư — tool group Tra cứu, skill Spreadsheets, KB Chuỗi cung ứng
  6. Trợ lý Mua hàng và Nhà cung cấp — 2 KB
  7. Trợ lý Nhân sự và Chính sách — Memory BẬT, KB Nội quy Nhân sự
  8. Trợ lý An toàn Lao động — KB An toàn Sức khoẻ Môi trường
  9. Trợ lý Hợp đồng và Pháp chế — 4 skill, KB Hợp đồng Pháp chế, Deep document read
     "Always read in full"
  10. Trợ lý Hỗ trợ Công nghệ thông tin — tool Knowledge catalog + Time, KB Sổ tay CNTT
- **8 knowledge base** — index High Quality, embedding text-embedding-3-small,
  mô tả đầy đủ, đã gắn vào agent tương ứng (nhưng 0 tài liệu do lỗi hạ tầng ở §2b).
- **2 custom skill**: "Soạn báo giá VAMEC", "Văn phong trả lời nội bộ VAMEC".
- **2 tool group**: "Tính toán kỹ thuật và báo giá" (Calculator, JSON, Time),
  "Tra cứu tài liệu và dữ liệu nội bộ" (Knowledge catalog, Spreadsheets, Fetch URL).
- **1 custom tool (OpenAPI)**: "Tra cứu tồn kho và lệnh sản xuất" — 3 operation
  (traTonKhoVatTu, traTrangThaiLenhSanXuat, danhSachLenhSanXuatTheoHopDong).
  CỐ Ý KHÔNG gắn vào agent nào vì endpoint erp-api.vinhan.vn không tồn tại thật —
  gắn vào sẽ sinh lỗi tool khi demo. Nó nằm ở Settings > Tools > Custom để trình diễn
  khả năng khai báo API riêng.

### 6.2 Ma trận phủ tính năng
| Tính năng | Đã phủ ở |
|---|---|
| Folder + icon | 5 folder |
| Model provider | gpt-5.5 (AgentHub Harvey) trên 10 agent |
| Instruction dài, có ranh giới | 10 agent |
| Built-in skill | Spreadsheets, Word documents, PDF files, Document comparison |
| Custom skill | 2 skill, gắn trên 10 agent |
| Tool plugin đơn lẻ | Knowledge catalog, Time (Trợ lý CNTT) |
| Tool group | 2 group, gắn trên 4 agent |
| Custom tool OpenAPI | 1 tool (không gắn — xem lý do trên) |
| Agent gọi Agent | Báo giá gọi Thiết kế điện |
| Knowledge base | 8 KB, High Quality index |
| Deep document read | "Always read in full" trên 2 agent |
| Memory | BẬT trên 2 agent |
| Conversation starters | 2–3 chip/agent, tiếng Việt, câu hỏi nghiệp vụ thật |
| Greeting + Tagline | 10 agent |
| Logs / Monitoring | 10 agent đều có hội thoại thật (source CONSOLE) |
| Feedback rating | đã chấm trên một số câu trả lời |
| Access | mặc định owner Nghĩa Trần |

### 6.3 Rà mùi demo
- Global search "demo", "mẫu", "test" → **không có kết quả nào**.
- Không còn nhãn "Dữ liệu mẫu" (đã xoá toàn bộ 9 agent + 5 KB cũ của kịch bản TRiBAT).
- Mọi tên đối tượng, mô tả, greeting, starter đều là tiếng Việt nghiệp vụ thật.
- Đã xoá sạch file thử nghiệm trong knowledge base.

### 6.4 Việc còn treo (không do thao tác)
1. **Nạp tài liệu vào knowledge base** — chặn bởi lỗi storage `/app/var/uploads/kb/...` (§2b).
   45 tài liệu đã soạn sẵn (238.000 ký tự) nằm ở `/root/agenthub-capture/docs/`.
2. **Provider "Harvey AI Assistant"** (gpt-5.6-sol, gpt-5.6-terra) — chat agent luôn lỗi (§5).
3. Các engine tìm kiếm web và bộ Google chưa được đăng ký trên server nên không chọn được.
4. Rework apps: chỉ Projects khả dụng, còn lại "Coming soon".
