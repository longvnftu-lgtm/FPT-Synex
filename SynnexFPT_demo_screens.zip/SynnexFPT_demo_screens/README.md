# Synnex FPT – Bộ màn hình demo Base Sales + AgentHub

Ảnh chụp từ tenant demo ngày 15/10/2026. Dùng làm nguồn để dựng slide HTML pitching có animation tương tác (mô phỏng thao tác như demo thật).
Toàn bộ tên đại lý, người, số điện thoại là hư cấu; tên Hãng (Dell, HP, Cisco…) là thật.

## Bối cảnh khách hàng
- Synnex FPT: nhà phân phối ICT, ~300 Sales. 70% doanh thu từ kênh Đại lý (~1.000 account), 30% từ Dự án B2G/Enterprise.
- 3 câu chuyện demo:
  1. **Account Care và Bán chéo đại lý** (Base Sales): AI phát hiện ngành hàng chưa khai thác → cơ hội bán chéo.
  2. **Pipeline Dự án B2G và HĐ 3 bên** (Base Sales): kiểm soát deal lớn, cảnh báo trễ SLA giá đặc biệt.
  3. **AI Chatbot chăm sóc đại lý SME** (AgentHub): trả lời 24/7, chấm điểm tín hiệu mua, lập Phiếu chuyển Sales trong 4 giờ.

## Gợi ý dòng chảy slide
1. Vấn đề → 2. Toàn cảnh pipeline (02, 03, 12) → 3. Account 360 (04–06) → 4. Deal bán chéo + Copilot (07–10) → 5. Deal dự án chủ lực (11) → 6. Chatbot đại lý (15–21) → 7. Trợ lý điều phối cho Trưởng kênh (22–25) → 8. Cấu hình và quản trị AI (26–30) → 9. Dashboard + Phân tích AI (13).

## Danh sách màn hình

### A. Base Sales (sales.base.com.vn)
| File | Nội dung | Gợi ý animation |
|---|---|---|
| 01_sales_trang_chu_thuong_vu | Trang chủ: 31 thương vụ sở hữu, danh sách deal, 2 pipeline [FPT Synnex] | Đếm số 31 chạy lên; danh sách trượt vào |
| 02_sales_pipeline_du_an_B2G | Kanban "Dự án B2G và Enterprise": 18 deal, tổng 193,9 tỷ, 5 giai đoạn (Lead dự án → Đàm phán HĐ 3 bên) | Card bay vào từng cột; tổng giá trị đếm lên |
| 03_sales_pipeline_ban_cheo_dai_ly | Kanban "Phát triển Đại lý và Bán chéo": 12 deal, tổng 70,8 tỷ, 4 giai đoạn | Hover card highlight |
| 04_sales_danh_sach_dai_ly_khach_hang | Danh bạ 25 đại lý/khách hàng, phân hạng Key Account/Gold/Silver/SME, giai đoạn Đang chăm sóc/Tiềm năng | Lọc theo hạng đại lý |
| 05_sales_account_saoviet_tong_quan | Account Chuỗi Điện máy Sao Việt: nhãn Chiến lược + Bán chéo, nhật ký thị sát, công nợ 18,78/27 tỷ | Click vào account từ 04 |
| 06_sales_account_saoviet_truong_du_lieu | Trường dữ liệu: ngành đang mua / chưa khai thác, hạn mức, doanh số 12 tháng 276,4 tỷ, tăng 13,8% | Nhấn mạnh "Ngành hàng chưa khai thác" |
| 07_sales_deal_saoviet_chi_tiet | Deal "Sao Việt – Mở ngành Thiết bị mạng Cisco" 10,8 tỷ: note "AI phát hiện…", task, báo giá SFO-0001 | Timeline note xuất hiện lần lượt |
| 08_sales_deal_saoviet_copilot_dang_nghi | Copilot đang tra cứu deal, công ty, liên hệ, hoạt động (các bước tick xanh) | Tick từng dòng như đang chạy |
| 09_sales_deal_saoviet_copilot_tom_tat | Copilot trả lời: tóm tắt deal | Typing effect |
| 10_sales_deal_saoviet_copilot_3_viec | Copilot: 3 việc cần làm + 3 câu hỏi gợi ý tiếp | Typing effect, chip gợi ý hiện cuối |
| 11_sales_deal_IOC_chu_luc_qua_han | Deal chủ lực IOC tỉnh Đông Hải 42 tỷ: task "Gửi tờ trình giá đặc biệt cho Dell" quá hạn, Thảo luận @Trưởng kênh | Badge "quá hạn" nhấp nháy đỏ |
| 12_sales_dashboard_tong_quan | Dashboard: 18 deal / 193,9 tỷ, phễu dự án, bán chéo theo nhân viên và nguồn | Chart vẽ dần |
| 13_sales_dashboard_phan_tich_AI | Panel "Phân tích AI" tự đọc dashboard và rút insight | Panel trượt từ phải |

### B. Base AgentHub (agenthub.base.com.vn)
| File | Nội dung | Gợi ý animation |
|---|---|---|
| 14_agenthub_folder_kenh_dai_ly | Folder "Kinh doanh Kênh Đại lý" với 2 agent | |
| 15_agenthub_agent1_man_hinh_chao | Màn hình chào của Trợ lý Chăm sóc Đại lý SME + 3 câu gợi ý | Click chip → chuyển 16 |
| 16_agenthub_agent1_hoi1_thuong_mo_nganh | Hỏi: đơn đầu 60 triệu thiết bị mạng được thưởng gì → bảng 2,4tr + 0,6tr = 3tr, quà Wifi Cisco (SFD-CS-01, 06) | Bảng hiện từng dòng |
| 17_agenthub_agent1_hoi2_han_muc_cong_no | Hạn mức 1 tỷ, nợ 700tr, cần nhập 450tr → vượt 150tr, tăng tạm 30%, lập Phiếu chuyển Sales (B2) | "Ran 2 calculations" rồi trả lời |
| 18_agenthub_agent1_hoi3_bao_gia_50_vostro | Báo giá 50 Dell Vostro: 50 × 13,6tr = 680tr, Dell Back to School, cảnh báo hạn mức | |
| 19_agenthub_agent1_hoi3_phieu_chuyen_sales | PHIẾU CHUYỂN SALES điểm A1, hạn 4 giờ, việc Sales cần làm | Phiếu "đóng dấu" A1 |
| 20_agenthub_agent1_hoi4_bao_hanh_xiaomi | Xiaomi lỗi màn hình 10 ngày → còn hạn đổi mới 15 ngày, hướng dẫn RMA | |
| 21_agenthub_agent1_hoi5_tu_choi_chiet_khau | Xin thêm 2% → từ chối lịch sự, lập phiếu xin giá đặc biệt | Có thanh điều hướng câu hỏi bên phải |
| 22–25_agenthub_agent2_kichban_* | Trợ lý Điều phối Chăm sóc SME: kịch bản 30 ngày (D0 → D30) Zalo/Email/Gọi, combo 30tr / 51,2tr, nội dung tin nhắn | Timeline mốc ngày |
| 26_agenthub_agent1_cau_hinh | Cấu hình agent: model, instruction, skill, tool group | |
| 27_agenthub_agent1_map_luong | Sơ đồ luồng: Chat input → Memory + Skill → Agent → Reply | Đường nối chạy dần |
| 28_agenthub_skill_cham_diem_tin_hieu_mua | Skill chấm điểm A1–D4 và quy tắc lập phiếu | |
| 29_agenthub_agent1_monitoring | Monitoring: 5 tin nhắn, 100% Helpful, 100% tool success, 17s phản hồi TB | Số đếm lên |
| 30_agenthub_agent1_logs | Logs 5 câu hỏi, đều có 👍 | |

## Số liệu chốt để đưa lên slide
- Pipeline Dự án B2G: 18 deal · 193,9 tỷ · dự kiến 91,5 tỷ.
- Pipeline Bán chéo đại lý: 12 deal · 70,8 tỷ · dự kiến 36,1 tỷ.
- Chatbot: 5/5 câu trả lời đúng chính sách, có mã tài liệu, 100% được đánh giá Helpful.
- Phiếu chuyển Sales: chấm điểm A1–D4; A1/A2/B1/B2 → xử lý trong 4 giờ.

## Lưu ý khi dựng
- Ảnh chụp ở độ zoom trình duyệt 68–85% để vừa khung; kích thước 1247×912 (Sales) và 1426×840 (AgentHub).
- Pie "Cơ hội bán chéo theo nguồn" trên dashboard đang không vẽ lát, chỉ có chú thích; nên vẽ lại bằng dữ liệu: AI gợi ý từ PO 5 · Chương trình Hãng 3 · Sales phát hiện khi thăm 3 · Zalo OA 1.
- Panel "Phân tích AI" (ảnh 13) đang trả lời tiếng Anh; nên Việt hoá khi dựng lại.
- Chưa có màn hình Phần 13 (4 deal nhãn "Từ Chatbot" trên Base Sales) vì phần này chưa dựng.
