# base-sales-demo-builder

Bộ tài liệu + skill hướng dẫn **dựng hệ thống demo trên app Base Sales** (Standard CRM, `sales.base.com.vn`).

Toàn bộ nội dung được ghi từ màn hình thật của ứng dụng, bản **09/2026**.

## Nội dung

```
base-sales-demo-builder/
├── SKILL.md                                  ← file gốc của skill
├── README.md                                 ← file này
└── references/
    ├── 01-dieu-huong.md                      Bản đồ điều hướng, URL từng màn
    ├── 02-mo-hinh-du-lieu.md                 Model, service, thuật ngữ
    ├── 03-settings-pipeline.md               13 mục cấu hình pipeline
    ├── 04-settings-account-contact.md        Cấu hình danh bạ
    ├── 05-settings-forecast-operation.md     Forecast, quota, Teams/Webhooks
    ├── 06-man-hinh-nghiep-vu.md              Kanban, bảng deal, trang chi tiết
    ├── 07-import-export.md                   Đặc tả 27 cột import, duplications
    ├── 08-reports-forecast.md                Dashboard và trình tạo chart
    ├── 09-playbook-dung-demo.md              ★ Quy trình 10 bước + checklist
    ├── 10-gioi-han.md                        Tính năng "coming soon" đã kiểm chứng
    └── 11-faq.md                             Câu hỏi khách hay gặp
```

## Dùng như tài liệu đọc

Không cần cài gì. Mở `references/09-playbook-dung-demo.md` trước — đó là quy trình làm việc. Các file còn lại để tra cứu khi cần đúng tuỳ chọn trong app.

## Dùng như skill của Claude

Skill giúp Claude tự động áp dụng bộ kiến thức này khi bạn hỏi về Base Sales, mà không cần dán tài liệu vào từng cuộc trò chuyện.

**Cách 1 — Claude (web/desktop):**
Vào *Settings → Capabilities → Skills*, tạo skill mới và dán nội dung `SKILL.md`, kèm các file trong `references/`.

**Cách 2 — Claude Code / Cowork:**
Chép nguyên cả thư mục `base-sales-demo-builder/` vào thư mục skills:
- Cá nhân: `~/.claude/skills/`
- Theo dự án: `<thư mục dự án>/.claude/skills/`

Cấu trúc thư mục phải giữ nguyên — `SKILL.md` nằm ở gốc, các file tham chiếu nằm trong `references/`.

**Cách 3 — nhanh nhất:**
Đưa cả thư mục này cho Claude và nói *"tạo skill từ thư mục này"*.

## Kiểm tra skill đã chạy

Hỏi Claude một câu bất kỳ, ví dụ:
- *"Dựng cho tôi demo Base Sales cho khách ngành logistics"*
- *"File import deal của Base Sales có những cột nào?"*
- *"Base Sales phân quyền chi tiết tới đâu?"*

Nếu Claude trả lời đúng tên menu tiếng Anh trong app và trích được mã quyền dạng `edit.lifecycle`, `data.commerce` thì skill đã hoạt động.

## Lưu ý

- Nội dung đúng với bản app **09/2026**. Base cập nhật thường xuyên — nhất là các mục đang "coming soon" trong `10-gioi-han.md`, nên kiểm tra lại trước mỗi buổi demo quan trọng.
- Tên menu giữ nguyên tiếng Anh để tra cứu không lệch với giao diện thật.
