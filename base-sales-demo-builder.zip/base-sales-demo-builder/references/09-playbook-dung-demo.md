# 09 — Playbook dựng hệ thống demo

**Đọc file này trước tiên.** Các file khác là tra cứu chi tiết.

---

## Bước 0 — Chốt kịch bản trước khi đụng vào app

Trả lời 6 câu hỏi này ra giấy trước:

1. **Khách làm ngành gì?** (quyết định tên công ty, tên deal, tên custom field)
2. **Bao nhiêu pipeline?** (tối đa 3, thường 1 là đủ)
3. **Quy trình bán của họ có mấy bước?** (thành bộ stage)
4. **Câu chuyện muốn kể là gì?** ví dụ: "phễu đang phình ở Demo scheduled", "2 deal lớn sắp chốt", "thua nhiều vì chưa duyệt ngân sách"
5. **Ai đóng vai sale trong demo?** (2–3 người, để phần "hiệu suất theo nhân viên" có số)
6. **Demo bao lâu?** dưới 20 phút thì bỏ Forecast

> Sai lầm phổ biến nhất: mở app ra rồi mới nghĩ. Kết quả là data không có câu chuyện, khách xem xong không nhớ gì.

---

## Bước 1 — Tạo Account directory và Contact directory

`Settings → Accounts → + Create service`
`Settings → Contacts → + Create service`

- Đặt tên theo ngôn ngữ khách: `Khách hàng B2B CRM`, `Người liên hệ B2B CRM`
- Điền `Description` — nó hiện trên thẻ service, trông chuyên nghiệp hơn "No description"
- Nếu kịch bản có nhắc vòng đời khách hàng: vào `Setting → Operation stages`, tạo tối thiểu 1 stage ở bucket `ACTIVE / OPERATIONAL`

---

## Bước 2 — Tạo Pipeline

`Settings → Pipelines → + Create pipeline`

Màn hình tạo cho phép đặt tên pipeline **và sửa luôn bộ stage** ngay tại đó. Đặt `Probability` và `Rotting in (days)` ngay, đừng để sửa sau.

**Bộ stage mẫu đã chạy tốt:**

| Stage | Probability | Rotting |
|---|---|---|
| Qualifications | 10% | 2 ngày |
| Contact made | 25% | 3 ngày |
| Demo scheduled | 50% | 5 ngày |
| Proposal | 75% | 5 ngày |
| Final negotiation | 90% | 3 ngày |

Sau khi tạo, vào `Setting → General info`:
- Điền `Description` (2–3 câu mô tả quy trình bán — khách đọc và thấy mình trong đó)
- Đặt `Pipeline owners`
- **`Set pipeline default currency` = VND** và bật `Enforce same currency`
- Bật `Enable forecast service` **nếu** kịch bản có forecast

---

## Bước 3 — Data fields

`Setting → Data fields`

- Tạo `Internal Field` cho thông tin đặc thù ngành
- Đặt `code` có tiền tố thống nhất, ví dụ `custom_logistics_...`
- Bật `ON FORMS` + `IN VIEWS` cho field muốn khoe
- Số lượng hợp lý: **6–8 field**. Ít hơn thì nhạt, nhiều hơn thì form dài, demo bị chậm

**Bộ field mẫu cho B2B phần mềm** (tham khảo để chế cho ngành khác):

| Label | Kiểu | Vai trò trong demo |
|---|---|---|
| Loại cơ hội | Dropdown: Khách mới / Mở rộng / Tái ký | Group by trong báo cáo |
| Số người dùng dự kiến | Integer | Quy mô đơn |
| Ngày dự kiến chốt | Date | Kế hoạch |
| Bước tiếp theo | Text | Khoe tính kỷ luật bán hàng |
| Hạn bước tiếp theo | Date | Ghép với cảnh báo |
| Tiêu chí thành công POC | Long Text | Chiều sâu nghiệp vụ |
| Người quyết định và quy trình mua | Long Text | Chiều sâu nghiệp vụ |
| Ngân sách dự kiến VND | Decimal | Số liệu |

**System fields:** đặt `Primary Account` → `REQUIRED AFTER STAGE` = stage đầu tiên. Đây là điểm demo tốt: giải thích "deal muốn rời khỏi Qualifications thì phải có công ty rõ ràng".

---

## Bước 4 — Reference data

`Setting → Won reasons` / `Lost reasons` / `Labels & taggings` / `Segmentations`

- **Lost reasons: 3–4 mục, viết bằng tiếng khách** — vì nó lên thẳng báo cáo. Mẫu: `Chưa được duyệt ngân sách` · `Hoãn dự án hoặc thay đổi ưu tiên` · `Chọn giải pháp cạnh tranh` · `Chưa đáp ứng phạm vi nghiệp vụ`
- **Won reasons: 2 mục** là đủ
- **Segmentation:** 1 chiều phân khúc, 3 option. Mẫu: `Phân khúc doanh nghiệp` → SMB / Mid-market / Enterprise
- **Labels:** 2–3 nhãn, có màu khác nhau

---

## Bước 5 — Quyền và bố cục

`Setting → Accesses & visibilities`
- Demo nội bộ: để `Everyone can access it` cho cả 3 câu hỏi đầu
- Demo có nhiều tài khoản đóng vai: cấu hình đúng theo kịch bản, và **thử đăng nhập bằng tài khoản không phải admin** để kiểm tra

`Setting → Permissions`
- Tick đủ để tài khoản demo không bị chặn giữa buổi

`Setting → Customized layouts`
- Chọn `Standard` (ba cột) — an toàn nhất
- Chỉ vào `Edit layout` khi khách hỏi "có tuỳ biến được giao diện không" — lúc đó mở ra cho xem là đủ, đừng sửa

---

## Bước 6 — Nạp dữ liệu

**Thứ tự bắt buộc: Accounts → Contacts → Deals**

Cách nhanh nhất:
1. Vào bảng `Accounts` → `Import` → `Download template` → điền → upload
2. Tương tự với `Contacts`
3. Vào `Pipeline → Deals` → `Import` → `Download template` → điền → upload

**Nguyên tắc rải deal để phễu đẹp:**

| Stage | Số deal gợi ý | Ghi chú |
|---|---|---|
| Qualifications | 3 | deal nhỏ |
| Contact made | 5 | |
| Demo scheduled | 5 | **để 1 deal rất lớn ở đây** — tạo cảm giác "sắp ăn to" |
| Proposal | 3 | |
| Final negotiation | 2 | 1 deal lớn |

Tổng ~18 deal. Ít hơn 12 thì phễu trông nghèo, nhiều hơn 30 thì kanban phải cuộn, khó demo.

**Về giá trị deal:** cho lệch nhau rõ, từ vài chục triệu tới vài tỷ. Tổng nên ra con số "nói được", ví dụ ~8,7 tỷ.

**Về tên deal:** mẫu `<Tên công ty> – <giải pháp> <quy mô>`, ví dụ:
- `Công ty CP Logistics Đông Dương – Base Work + CRM 150 user`
- `Bệnh viện Đa khoa Tâm An – Base E-Office cho 8 khoa phòng`
- `Tập đoàn Bất động sản Phú Thịnh – Agentic OS toàn tập đoàn`

Chi tiết cột file import xem `07-import-export.md`.

---

## Bước 7 — Forecast *(bỏ qua nếu demo ngắn)*

1. Pipeline `Setting → General info` → bật `Enable forecast service`
2. `Settings → Forecasts → + Create service`, đặt tên theo kỳ (ví dụ `Commit H2`)
3. `Setting → General info` → bật `Fix a single currency for this forecast`, chọn **VND**
4. `Setting → Quotas → Set quota` cho từng rep, đặt số thật (vài tỷ), không để `$3`
5. Vào `Pipeline → Forecast → + Enroll deals`, đưa 5–8 deal vào
6. Bấm `Submit forecast` một lần để `Submission history` có dữ liệu

> Màn forecast trống trơn là phản tác dụng. Nếu không kịp làm đủ 6 bước này thì **đừng mở tab Forecast trong buổi demo**.

---

## Bước 8 — Reports

`Reports → + New dashboard` → đặt tên tiếng Việt + mô tả.

Tối thiểu 2 chart:
1. **Summary** "Tổng quan pipeline" — Deals + Deal value + Avg deal value, group by None
2. **Funnel** "Phễu chuyển đổi theo giai đoạn" — Deals, group by Stage

Thêm nếu có thời gian: Bar "Giá trị theo nhân viên" (group by Owner), Pie "Lý do thua" (group by Lost reason).

Chi tiết xem `08-reports-forecast.md`.

---

## Bước 9 — Thêm chiều sâu cho 2–3 deal chủ lực

Đây là bước phân biệt demo nghiệp dư và demo chuyên nghiệp. Chọn 2–3 deal sẽ mở ra trong buổi demo và làm đầy:

- **Tasks:** 1 việc hôm nay, 1 việc quá hạn, 1 việc không hạn — để `Home → Tasks` có màu
- **Work stream:** 2–3 note ghi lại nội dung cuộc gặp thật sự (không phải "test note")
- **Primary contact + Primary account** đầy đủ, contact có số điện thoại
- **Custom fields** điền hết, nhất là `Tiêu chí thành công POC` và `Người quyết định và quy trình mua` — đây là chỗ khách gật đầu
- **Discussion:** 1 comment
- **AI Copilot rule** cho pipeline — xem mẫu trong `03-settings-pipeline.md` mục 10

---

## Bước 10 — Nghiệm thu

### Checklist

- [ ] Kanban hiển thị đủ stage, mỗi stage có deal, tổng giá trị và % phễu hợp lý
- [ ] Không stage nào trống (phễu sẽ gãy)
- [ ] Mở 1 deal bất kỳ: có Primary account, Primary contact, custom field có dữ liệu, Work stream có ít nhất 1 hoạt động
- [ ] `Home → Tasks` có việc hôm nay và 1 việc quá hạn
- [ ] `Pipeline → SLAs` hiển thị ngưỡng rotting từng stage
- [ ] Nút **Won** mở được hộp thoại và có sẵn lý do thắng; **Lost** có sẵn lý do thua
- [ ] Dashboard có chart chạy đúng số
- [ ] Tiền tệ hiển thị nhất quán VND, không lẫn `$`
- [ ] Forecast có quota và deal được enroll — **hoặc** đã quyết định không mở tab này
- [ ] `Duplications` không báo trùng ngoài ý muốn
- [ ] Đăng nhập bằng tài khoản demo (không phải admin) — vẫn xem và sửa được đúng phần cần khoe
- [ ] Thời gian cập nhật của các deal **không phải tất cả đều `just now`**

### Xử lý mốc thời gian

Sau khi import một lượt, mọi deal đều `just now` hoặc `2m ago` — khách tinh ý nhận ra ngay là data giả.

Cách xử lý: import trước buổi demo **ít nhất 1–2 ngày**, rồi sát giờ vào sửa tay 2–3 deal (kéo stage, thêm note) để có vài deal `just now` xen với `2d ago`. Kết quả nhìn như hệ thống đang chạy thật.

---

## Phụ lục — Thời gian ước tính

| Bước | Thời gian |
|---|---|
| 0. Chốt kịch bản | 20 phút |
| 1–2. Directory + Pipeline | 15 phút |
| 3. Data fields | 20 phút |
| 4. Reference data | 10 phút |
| 5. Quyền + layout | 10 phút |
| 6. Nạp dữ liệu | 45 phút (gồm soạn file) |
| 7. Forecast | 20 phút |
| 8. Reports | 15 phút |
| 9. Chiều sâu deal | 30 phút |
| 10. Nghiệm thu | 15 phút |
| **Tổng** | **~3,5 giờ** (bỏ Forecast: ~3 giờ) |
