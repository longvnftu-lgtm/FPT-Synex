# 03 — Settings của một Pipeline (13 mục)

Mở bằng: `Settings → Pipelines →` nút **Setting** trên thẻ pipeline. Hoặc từ trong pipeline: menu trái → `Settings`.

Modal chia 2 nhóm: **PIPELINE** (10 mục) và **PIPELINE REFERENCE DATA** (3 mục).

---

## 1. General info

**Thống kê đầu trang:** `TOTAL DEALS` · `ACTIVE IN PIPELINE` · `WON DEALS` · `LOST DEALS` — mỗi thẻ kèm tổng giá trị.

**Edit basic info**
- `Pipeline name` *(bắt buộc)*
- `Description`
- `Pipeline owners` — chọn nhiều người
- `Pipeline followers`

**Pipeline rules** — "Rules and permissions regarding to this pipeline"

| Tuỳ chọn | Ý nghĩa |
|---|---|
| `Limit deal creation to the first stage` | Bắt buộc deal phải được tạo ở stage đầu tiên |
| `Prevent deals from moving backward` | Không cho kéo deal lùi lại, chọn được stage nào áp dụng |
| `Prevent deals from skipping stages` | Không cho nhảy cóc stage, chọn được stage nào áp dụng |
| `Prevent deleting deals` | Chặn xoá deal. App admin và system owner vẫn xoá được; nếu tắt vẫn có thể bật riêng cho từng người |

**Additional settings**

| Tuỳ chọn | Ý nghĩa |
|---|---|
| `Set pipeline default currency` | Mặc định lấy tiền tệ của công ty. Chọn được ví dụ `VND — Vietnamese Dong`. Danh mục tiền tệ cấu hình ở **app Settings** (ngoài Sales) |
| `Enforce same currency` | Mọi deal buộc dùng đúng tiền tệ của pipeline |
| `Default deal value` | Cách tính và hiển thị giá trị deal — mặc định `Manual entry` |
| `Enable forecast service` | Cho phép deal trong pipeline này được đưa vào forecast. **Không bật thì không enroll được** |

**Pipeline info** (chỉ đọc): Created date, Last update, Created by, Status, Service model (`sales.pipeline`), Relative path.

---

## 2. Data fields

### 2.1 Custom fields

Mỗi field hiển thị: số thứ tự · Label · badge phạm vi (`INTERNAL` / `SERVICE` / `GLOBAL`) · kiểu dữ liệu · `code` · 2 cờ `ON FORMS` và `IN VIEWS` · menu `⋮`.

Ví dụ bộ field thật của pipeline `Bán hàng B2B`:

| # | Label | Kiểu | Code |
|---|---|---|---|
| 01 | Loại cơ hội | Dropdown (Khách mới / Mở rộng / Tái ký) | `custom_b2b_motion` |
| 02 | Số người dùng dự kiến | Integer | `custom_b2b_seats` |
| 03 | Ngày dự kiến chốt | Date | `custom_b2b_close_date` |
| 04 | Bước tiếp theo | Text | `custom_b2b_next_step` |
| 05 | Hạn bước tiếp theo | Date | `custom_b2b_next_due` |
| 06 | Tiêu chí thành công POC | Long Text | `custom_b2b_poc_criteria` |
| 07 | Người quyết định và quy trình mua | Long Text | `custom_b2b_buying_process` |
| 08 | Ngân sách dự kiến VND | Decimal | `custom_b2b_budget_vnd` |

### 2.2 Các nút thao tác

`+ New Field ▾` · `Pick existing field…` · `Export ▾` · `Import`

**3 phạm vi khi tạo field mới:**

| Phạm vi | Mô tả trong app | Khi nào dùng |
|---|---|---|
| `Global Field` | "Available to every service in the tenant. Use for cross-cutting fields like Department or Notes." | Trường dùng chung toàn bộ tenant |
| `Service Field` | "Scoped to services of model `sales.pipeline`. Other services with the same model can attach it." | Trường dùng chung nhiều pipeline |
| `Internal Field` | "Lives only on this service. No shared-pool row. Best for one-off, service-specific data." | **Mặc định nên dùng khi dựng demo** |

### 2.3 Form tạo field

- `LABEL` *(bắt buộc)* — ví dụ placeholder: "e.g. Department"
- `CODE` — tự sinh từ label nếu để trống, dạng `custom_...`
- `TYPE`
- `PLACEHOLDER` — help text

### 2.4 Danh sách đầy đủ 26 kiểu field

```
Text              Long Text         Integer           Decimal
Date              Date & Time       Time              Checkbox
Dropdown          Multi-Select      File              Files
Rich Text         Formula           Conditional Formula
Lines             Rating            User              Table
Email             URL               Phone             Currency
Message           Progress          Users
```

Ghi chú chọn kiểu khi demo:
- `Dropdown` / `Multi-Select` cho mọi thứ khách sẽ lọc hoặc group trong báo cáo
- `Decimal` cho tiền, `Integer` cho số lượng user/ghế
- `Long Text` cho tiêu chí POC, quy trình mua — đây là chỗ khoe chiều sâu nghiệp vụ
- `Formula` / `Conditional Formula` chỉ dùng khi khách hỏi sâu, dễ vỡ khi demo nhanh

### 2.5 System fields

"Built-in deal fields — choose which ones this pipeline asks for."

| FIELD | SHOW ON FORM | REQUIRED | REQUIRED AFTER STAGE |
|---|---|---|---|
| `Primary Account` | ✓ | Locked | Qualifications |
| `Primary Contact` | ✓ | ☐ | Never |
| `Deal value` | ✓ | ☐ | Never |
| `Labels` | ✓ | ☐ | Never |

> **Quy tắc `REQUIRED AFTER STAGE` (nguyên văn app):** "A field is only checked once the record has LEFT the chosen stage — sitting in that stage is still the chance to fill it in. A record created straight into a later stage owes the same fields as one walked there."
>
> Nghĩa là: chọn `Qualifications` thì deal vẫn nằm ở Qualifications được mà chưa cần điền; chỉ khi kéo sang stage sau mới bị chặn. Và deal tạo thẳng vào stage cuối vẫn bị đòi đủ field.

### 2.6 Field requirements before closing a deal

"Both levels put the pipeline's fields on the won/lost dialog. Only **Strict** refuses the close while any of them is still empty."

- `When a deal is won` → `Not required` / (mức lỏng) / `Strict`
- `When a deal is lost` → tương tự

Demo tip: để `Not required` cho cả hai, trừ khi đang khoe tính kỷ luật dữ liệu.

---

## 3. Pipeline stages

Hai công tắc đầu trang:
- `Custom deal probability` — cho phép đặt xác suất riêng cho từng deal thay vì lấy theo stage
- `Enable stage colors` — bật màu stage

Mỗi stage là một cột, chứa:
- `Name`
- `Probability` (%)
- `Rotting in (days)` — công tắc bật/tắt + số ngày
- `Stage color` — 9 màu + 1 ô tuỳ chọn
- `× Remove this stage`

Cuối hàng có `+` để chèn stage, và khối `Add a new stage` với nút `Add stage`. Kéo thả để đổi thứ tự. Nút `Cancel` / `Save` ở đầu trang.

**Bộ stage mặc định khi tạo pipeline mới:** `Qualification`, `Contact made`, `Demo scheduled`, `Proposal`, … (tất cả 100%, không rotting).

**Bộ stage mẫu đã chạy tốt (pipeline `Bán hàng B2B`):**

| Stage | Probability | Rotting |
|---|---|---|
| Qualifications | 10% | 2 ngày |
| Contact made | 25% | 3 ngày |
| Demo scheduled | 50% | 5 ngày |
| Proposal | 75% | 5 ngày |
| Final negotiation | 90% | 3 ngày |

---

## 4. Accesses & visibilities

> "Pipeline owners have full permissions by default."

**Pipeline access and visibility**

| Câu hỏi | Lựa chọn |
|---|---|
| `Who can access the pipeline?` <br>*(thấy pipeline, không đồng nghĩa thấy deal bên trong)* | `Everyone can access it` / `Limit who can access it` |
| `Who can create new deals in the pipeline?` <br>*(cần quyền access ở trên)* | `Everyone who can access it can create new deals` / `Limit who can create new deals` |
| `Who can report on every deal of the pipeline?` <br>*(cấp quyền báo cáo trên cả deal họ không mở được)* | `Only pipeline owners` / `Pipeline owners and specific people` |

**Deal access and visibility** — "Extra ways into the deals themselves, on top of owning or following them."

| Câu hỏi | Lựa chọn |
|---|---|
| `Who can access every deal of the pipeline?` <br>*(mặc định chỉ thấy deal mình own / collaborate / follow)* | `Not granted to anyone` / `Only pipeline owners` / `Pipeline owners and specific people` |
| `Who can access deals with no owner?` <br>*(thường là người đi nhặt deal chưa ai nhận)* | `Only pipeline owners` / `Pipeline owners and specific people` |

---

## 5. Permissions

> "Pipeline owners and deal owners always have every permission — this table does not apply to them."

**Cột (nhóm được cấp quyền):** `Pipeline followers` · `Deal followers` · `Managers of deal owner` · `Peers of deal owner` · *(các team, ví dụ `Sales Enablement`)*

**Hàng (quyền):**

| Mã | Tên | Nội dung |
|---|---|---|
| `edit.general` | General edits | Sửa mọi thông tin deal, trừ controlling và lifecycle |
| `edit.primary` | Edit controlling fields | Sửa owner, collaborators, primary contact, primary account |
| `edit.lifecycle` | Update deal lifecycle | Đánh dấu won/lost, mở lại deal đã đóng |
| `ops.general` | Basic operations | Tasks, todos, logged activities |
| `ops.mail` | Mail operation | Gửi và đọc mail từ deal |
| `ops.meeting` | Meeting operation | Đặt và xem lại cuộc họp trên deal |
| `data.basic` | Basic associated data | Feed posts, comments |
| `data.commerce` | Deal commerce | Quotes, orders, subscriptions |
| `data.contract` | Deal contracts | Hợp đồng gắn với deal |

Nút `Save changes` ở cuối bảng.

---

## 6. Custom views

Danh sách view, mỗi dòng có: tay cầm kéo thả · công tắc bật/tắt · tên view · badge `Private`/`Public` · menu `…`

Nút `+ Create view` → nhập `View name` + chọn phạm vi:
- `Private — only you`
- `Public — everyone on this pipeline`

---

## 7. Customized layouts

> "Choose how the deal page looks for every user of this pipeline. Switching is instant — each template keeps its own arrangement."

| Template | Mô tả |
|---|---|
| `Default layout` | Trang deal chuẩn của app, không tuỳ biến |
| `Standard` | Ba cột: dữ liệu bên trái, công việc ở giữa, người và file bên phải |
| `Two columns` | Dữ liệu trái, công việc phải. Không sidebar — hợp màn hình hẹp |
| `Activity first` | Work stream rộng ở giữa, hai rãnh hẹp hai bên |
| `Data first` | Hai cột dữ liệu dày, stream đẩy sang cột thứ ba hẹp |

Nút **`Edit layout`** mở trình dựng kéo thả với 4 vùng: `Header` · `Main Left` · `Main Right` · `Sidebar`, và panel phải có 2 tab `Components` / `Setting`.

**Thư viện component:** Deal cover, Deal overview, Deal information, Custom fields, Deal segments, Primary contact, Primary account, Deal forecasts, Deal flows, Deal insights, Action plan, Work stream, Owner & team, Deal files, Discussion, Commerce.

Nút `Reset to default` và `Save` ở đầu trình dựng.

---

## 8. Segmentations

Bảng `Deal segments` với cột NAME / SEGMENTATION OPTIONS / ACTION, nút `+ Add segmentation`.

Ví dụ thật: `Phân khúc doanh nghiệp` → `SMB dưới 100 người dùng` · `Mid-market 100–499 người dùng` · `Enterprise từ 500 người dùng`.

Khác Dropdown custom field ở chỗ: segmentation là một chiều phân loại riêng, xuất hiện như component `Deal segments` trên layout và có cột riêng trong file import.

---

## 9. Work stream

> "Records from other apps that appear in this pipeline's work stream."

- ☑ `Commerce quotes` — "Raise Commerce quotes from a deal and follow them here. Needs the Deal commerce permission."
- ☑ `Commerce orders` — "Raise Commerce orders from a deal and follow them here. Needs the Deal commerce permission."

Bật hai mục này thì trên Work stream của deal sẽ có thêm nút `Quote` và `Order` cạnh Note / Email / Call / Meeting.

---

## 10. AI Copilot

> "Guidance the AI copilot follows for every deal in this pipeline, alongside its default role."

Danh sách rule, mỗi rule gồm tiêu đề + nội dung văn bản tự do. Nút `+ Add rule`.

**Ví dụ rule thật (pipeline `Bán hàng B2B`)** — dùng làm mẫu để viết rule cho ngành khác:

> Tiêu đề: *Qualification, POC và kế hoạch chốt B2B*
>
> Dựa trên dữ liệu deal, đánh giá nhu cầu kinh doanh, ngân sách, người quyết định, thời hạn mua, số user và phạm vi triển khai. Phân biệt khách mới, mở rộng và tái ký. Khi chuẩn bị demo/POC cần mục tiêu và tiêu chí thành công; khi đề xuất cần phạm vi, giá trị và kế hoạch triển khai. Nêu rõ thông tin đã có và còn thiếu, không tự bịa cam kết khách hàng hay xác suất thắng. Đề xuất tối đa 3 hành động cụ thể kèm người phụ trách và hạn đề xuất. Cảnh báo deal thiếu bước tiếp theo, thiếu người quyết định hoặc ngày chốt không có bằng chứng. Không tự hứa chiết khấu hay thay đổi điều khoản thương mại.

Cấu trúc rule tốt gồm 5 phần: **(1)** dữ liệu cần nhìn → **(2)** phân loại nghiệp vụ → **(3)** yêu cầu theo từng giai đoạn → **(4)** giới hạn (không bịa, không hứa) → **(5)** đầu ra mong muốn (số hành động, kèm người + hạn).

---

## 11. Labels & taggings

`Deal labels` — thêm nhãn bằng tên + mã màu hex (mặc định `#3b82f6`), nút `Add`. Khi chưa có: "No labels yet."

---

## 12. Won reasons

Bảng `# / REASON`, nút `Add reason`.

Ví dụ thật: `Giải pháp đáp ứng tiêu chí POC` · `Kế hoạch triển khai phù hợp`.

---

## 13. Lost reasons

Bảng `# / REASON`, nút `Add reason`.

Ví dụ thật: `Chưa được duyệt ngân sách` · `Hoãn dự án hoặc thay đổi ưu tiên` · `Chọn giải pháp cạnh tranh` · `Chưa đáp ứng phạm vi nghiệp vụ`.

Lost reason lên thẳng báo cáo (group by `Lost reason`) nên phải viết bằng ngôn ngữ khách dùng, không viết chung chung.
