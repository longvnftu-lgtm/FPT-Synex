# 11 — FAQ: câu hỏi khách hay gặp

Mỗi mục gồm: câu hỏi → màn hình để mở → cách trả lời.

---

## Về pipeline và quy trình

**"Quy trình bán của chúng tôi khác, có sửa được không?"**
→ `Pipeline → Setting → Pipeline stages`
Sửa được hoàn toàn: thêm/bớt/đổi tên/đổi thứ tự stage, mỗi stage đặt riêng xác suất thắng và số ngày cảnh báo. Có thể tạo nhiều pipeline song song cho nhiều nghiệp vụ khác nhau.

**"Chúng tôi có 3 mảng kinh doanh khác nhau."**
→ `Settings → Pipelines`
Mỗi mảng một pipeline riêng, stage riêng, field riêng, quyền riêng — nhưng vẫn báo cáo gộp được ở Reports (group by `Pipeline`).

**"Làm sao chặn nhân viên nhảy cóc giai đoạn?"**
→ `Pipeline → Setting → General info → Pipeline rules`
Có 4 luật: bắt tạo ở stage đầu, cấm lùi stage, cấm nhảy cóc stage, cấm xoá deal. Luật cấm lùi và cấm nhảy cóc còn chọn được áp dụng cho stage nào.

**"Deal để lâu không ai đụng thì sao?"**
→ `Pipeline → SLAs`
Mỗi stage có ngưỡng `Rotting in (days)`. Deal nằm im quá hạn bị tô cảnh báo trên kanban, và màn SLAs thống kê số deal đang vi phạm cùng số ngày không hoạt động trung bình.

---

## Về dữ liệu và trường thông tin

**"Chúng tôi cần thêm trường riêng của ngành."**
→ `Pipeline → Setting → Data fields → New Field`
26 kiểu dữ liệu: text, số, ngày giờ, dropdown, multi-select, file, rich text, công thức, bảng, rating, người dùng, tiền tệ, tiến độ... Mỗi field chọn được hiện trên form và/hoặc hiện trong danh sách.

**"Có bắt buộc điền được không?"**
→ `Data fields → System fields` (cột `REQUIRED AFTER STAGE`)
Bắt buộc theo giai đoạn: chọn stage nào thì deal **rời khỏi** stage đó mới bị kiểm. Ngồi trong stage vẫn được để trống — hợp với thực tế thu thập thông tin dần.

Ngoài ra có `Field requirements before closing a deal` — mức `Strict` sẽ từ chối đóng deal khi field bắt buộc còn trống.

**"Dữ liệu cũ của chúng tôi đang ở Excel."**
→ `Deals → Import`
Import từ `.xlsx` hoặc `.csv`. Tải template có sẵn đúng cột, điền rồi upload. Có 2 chế độ: tạo mới hoặc cập nhật bản ghi đã có. File lớn chạy nền.
Thứ tự nạp: công ty → người liên hệ → cơ hội.

**"Có xuất được ra Excel không?"**
→ Nút `Export` ở mọi màn bảng. File giữ trên hệ thống 7 ngày, lịch sử các lần chạy lưu ở `Import & export history`.

**"Dữ liệu bị trùng thì sao?"**
→ `Pipeline → Duplications`
Hệ thống tự phát hiện deal trùng theo quy tắc: cùng tên + cùng người liên hệ, hoặc cùng tên + cùng công ty. Ngoài ra gộp thủ công được 2 bản ghi bất kỳ.

---

## Về phân quyền

**"Nhân viên có nhìn thấy deal của nhau không?"**
→ `Pipeline → Setting → Accesses & visibilities`
Mặc định mỗi người chỉ thấy deal mình sở hữu, cộng tác hoặc theo dõi. Muốn mở rộng thì cấp thêm ở phần `Deal access and visibility` — cấp cho tất cả, chỉ pipeline owner, hoặc một số người cụ thể.

**"Quản lý có xem được deal của cấp dưới không?"**
→ `Pipeline → Setting → Permissions`
Bảng quyền có sẵn nhóm `Managers of deal owner` và `Peers of deal owner` — tick quyền nào thì quản lý có quyền đó trên deal của nhân viên.

**"Phân quyền chi tiết tới mức nào?"**
→ 9 loại quyền: sửa thông tin chung, sửa trường điều khiển (owner/contact/account), đổi trạng thái thắng-thua, thao tác cơ bản, email, họp, dữ liệu liên quan, thương mại (báo giá/đơn hàng), hợp đồng.
Nhân với 5 nhóm quan hệ → 45 ô tick cho một pipeline.

**"Ai được xem báo cáo toàn bộ?"**
→ `Accesses & visibilities → Who can report on every deal of the pipeline?`
Tách riêng khỏi quyền mở deal: một người có thể báo cáo trên toàn bộ deal mà vẫn không mở được từng deal cụ thể.

---

## Về báo cáo

**"Báo cáo có sẵn hay phải tự dựng?"**
→ `Reports → New dashboard → Add chart`
Tự dựng, nhưng nhanh: chọn nguồn dữ liệu (Deals / Accounts / Contacts / Activity), lọc, chọn kiểu biểu đồ trong 9 loại, chọn chỉ số và chiều nhóm. Hoặc gõ mô tả bằng câu chữ rồi bấm `Build`.

**"Xem được phễu chuyển đổi không?"**
→ Chart type `Funnel`, group by `Stage`. Hiện số deal và % từng giai đoạn.

**"Xem được ai bán tốt nhất không?"**
→ Chart `Bar`, measure `Deal value`, group by `Owner`.

**"Biết được vì sao thua không?"**
→ Chart `Pie`, group by `Lost reason`. Danh mục lý do thua do công ty tự định nghĩa ở `Setting → Lost reasons`.

**"Có hỏi báo cáo bằng ngôn ngữ tự nhiên được không?"**
→ Có, nút `Ask` và `Explain` trên dashboard, cộng ô `Describe the chart` trong trình tạo chart.

---

## Về dự báo doanh số

**"Có quản lý chỉ tiêu từng nhân viên không?"**
→ `Settings → Forecasts → Setting → Quotas`
Đặt hạn mức từng rep kèm ngày hiệu lực, hoặc import hàng loạt.

**"Nhân viên cam kết số rồi quản lý theo dõi thế nào?"**
→ `Pipeline → Forecast`
Rep chọn deal đưa vào dự báo, phân loại thành Commit / Best case / Open / Omitted, rồi bấm `Submit forecast` để chốt một snapshot gửi quản lý. Lịch sử lưu ở tab `Submission history`.

---

## Về AI

**"AI làm được gì trong này?"**
→ Ba chỗ:
1. **AI Copilot** trên từng deal/account/report — hỏi đáp theo ngữ cảnh bản ghi
2. **AI Copilot rules** cấp pipeline — công ty tự viết hướng dẫn cho copilot, ví dụ tiêu chí qualification, cảnh báo deal thiếu thông tin, giới hạn không được tự hứa chiết khấu
3. **Ask / Explain** trên dashboard và ô mô tả chart bằng câu chữ

**"AI có tự bịa không?"**
→ Rule cấp pipeline viết được ràng buộc cụ thể. Ví dụ rule thật đang chạy có câu: *"Nêu rõ thông tin đã có và còn thiếu, không tự bịa cam kết khách hàng hay xác suất thắng"* và *"Không tự hứa chiết khấu hay thay đổi điều khoản thương mại"*.

---

## Về tích hợp

**"Nối được với email không?"**
→ Có, qua app Mail (Gmail / Outlook / SMTP). Sau khi nối, email hiện ở `Inboxes` và gửi được trực tiếp từ deal.

**"Có webhook / API không?"**
→ Webhook outbound **chưa có** (app ghi "lands in the next iteration"). Hiện tại: export Excel định kỳ, hoặc dùng liên thông sẵn có giữa các app trong hệ Base.

**"Nối với báo giá, đơn hàng, hợp đồng thế nào?"**
→ Tab `Commerce` trên trang deal có 4 khối: Quotes, Orders, Contracts, Subscriptions. Bật ở `Setting → Work stream` để báo giá và đơn hàng từ **Base Commerce** hiện luôn trong dòng hoạt động của deal.

**"Chữ ký số?"**
→ Thuộc **Base eSign**, app riêng trong hệ Base.

**"Quản lý lead trước khi thành cơ hội?"**
→ Thuộc **Base Lead** — chấm điểm, khử trùng, chia lead tự động, rồi chuyển sang CRM.

---

## Về giao diện

**"Giao diện có tuỳ biến được không?"**
→ `Pipeline → Setting → Customized layouts`
5 bố cục dựng sẵn, và trình kéo thả cho phép sắp xếp 16 khối nội dung vào 4 vùng của trang deal. Đổi bố cục có hiệu lực ngay cho mọi người trong pipeline.

**"Mỗi người xem một kiểu danh sách khác nhau được không?"**
→ `Setting → Custom views` — tạo view riêng tư hoặc view dùng chung cho cả pipeline. Ngoài ra mỗi màn bảng có `Columns`, `Sort`, `Filters`, `Advanced filters` riêng.

**"Có tiếng Việt không?"**
→ Dữ liệu tiếng Việt đầy đủ (tên deal, field, stage, lý do thắng-thua đều do công ty tự đặt). Giao diện hệ thống hiện là tiếng Anh.
