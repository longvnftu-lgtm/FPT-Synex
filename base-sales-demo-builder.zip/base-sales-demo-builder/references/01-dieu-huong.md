# 01 — Bản đồ điều hướng Base Sales

Tên app hiển thị trên tab trình duyệt: **Sales — Standard CRM**. Domain mẫu: `sales.base.com.vn`.

## 1. Thanh header trên cùng

Từ trái sang phải:

| Phần tử | Chức năng |
|---|---|
| Logo `Base.vn` | Về trang chủ tenant |
| `Search anything...` (`Ctrl+K`) | Tìm kiếm toàn app |
| Icon tia sáng | **AI Copilot** — chỉ hoạt động khi đang mở một deal, account hoặc report. Khi không có ngữ cảnh sẽ hiện dòng "Open a deal, account or report to ask Copilot" |
| Icon `?` | Help |
| Icon chuông | Notifications (có badge số) |
| Icon mặt trăng | Dark mode |
| Icon play | Start work session |
| Avatar | Menu tài khoản, chuyển tenant (`Công ty Cổ phần Base Enterprise`) |

## 2. Thanh module (rail trái ngoài cùng)

| Module | URL | Mô tả |
|---|---|---|
| **Home** | `/home` | Trang cá nhân của người dùng |
| **Pipelines** | `/pipeline/<id>` | Kanban + bảng deal |
| **Accounts** | `/account/service/<id>` | Danh bạ công ty |
| **Contacts** | `/contact/service/<id>` | Danh bạ người liên hệ |
| **Inboxes** | `/inbox` | Hộp thư |
| **Forecast** | `/forecast/<id>` | Dự báo doanh số |
| **Reports** | `/reports` | Dashboard và chart |
| **Settings** (bánh răng, góc dưới) | `/settings` | Toàn bộ cấu hình |

## 3. Home — menu con

Đường dẫn dạng `/home/<mục>`.

**Nhóm chính**
- `Deals` → `/home` — danh sách deal của tôi
- `Accounts` → `/home/accounts`
- `Contacts` → `/home/contacts`
- `Forecasts` → `/home/forecasts`

**ACTIVITIES**
- `Meetings` → `/home/meetings`
- `Calls` → `/home/calls`
- `Tasks` → `/home/tasks`
- `Stories` → `/home/stories` *(coming soon)*
- `Feedbacks` → `/home/feedbacks` *(coming soon)*

**PERSONAL UTILITIES**
- `Todos` → `/home/todos` *(coming soon)*
- `Bookmarks` → `/home/bookmarks` *(coming soon)*
- `Calendar` → `/home/calendar` *(coming soon)*

### Nội dung trang Home > Deals
- 3 tab lọc: `My deals` · `Followed deals` · `All related`
- Dải `Bookmarked deals` ở trên cùng
- 5 thẻ số: `Owned deals` · `Following` · `Contributed` · `Won` · `Lost`
- Bảng: DEAL / ACCOUNT / VALUE / UPDATED
- Ô `Search for deals` góc phải

## 4. Bên trong một Pipeline

Menu trái gồm 2 khối.

**Khối trên — các view:**

| Mục | URL | Nội dung |
|---|---|---|
| `Pipeline` | `/pipeline/<id>` | Kanban theo stage |
| `Deals` | `/pipeline/<id>/deals` | Bảng danh sách deal |
| `Forecast` | `/pipeline/<id>/forecast` | Forecast của riêng pipeline này |
| `Activity logs` | (cùng trang) | Nhật ký thay đổi |

**Khối dưới — công cụ:**

| Mục | URL | Nội dung |
|---|---|---|
| `SLAs` | — | Ngưỡng rotting theo từng stage + số deal đang vi phạm |
| `Duplications` | `/duplications?pipeline=<id>` | Phát hiện và gộp deal trùng |
| `Import & export history` | `/io-history?pipeline=<id>` | Lịch sử các lần nạp/xuất |
| `Edit pipeline` | — | Sửa nhanh bộ stage (inline, không vào Settings) |
| `Settings` | — | Mở modal 13 mục cấu hình pipeline |

Góc trên bên trái có **dropdown chuyển pipeline**.

## 5. Bên trong một Deal

URL: `/deal/<id>`. Menu trái:

**Nhóm chính:** `Deal` · `Commerce` · `Notes` · `Emails` · `Meetings` · `Calls` · `Chats` · `Tasks`

**COLLABORATIONS:** `Todos` · `Feedbacks` · `Stories` · `Orgchart`

**SMART OPS:** `Automations` · `Sequences` · `SLAs` · `Agent flows` — *cả 4 mục này hiện đều "coming soon"*

**Cuối menu:** `Edit deal` · `Activity logs`

**Header trang deal:**
- Breadcrumb: tên pipeline › tên deal
- Nút **Won** (xanh) và **Lost** (đỏ)
- Menu `...`: `View in new tab`, `Edit basic`, `Edit labels`, `Edit owner`, `Edit followers`, `Manage collaborators`, `Edit attachments`, `More edit options ›`, `Move to another stage`, `Move to another pipeline`, `Enroll into a forecast`, `Enroll to automations`, `Delete`

## 6. Bên trong một Account

URL: `/account/<id>`. Menu trái:

**Nhóm chính:** `Account` · `Notes` · `Emails` · `Meetings` · `Calls` · `Orgchart` · `Tasks` · `Automations`

**COLLABORATIONS:** `Todos` · `Feedbacks` · `Stories` · `Chats`

**Cuối menu:** `Edit account` · `Activity logs`

Trong tab `Account` có 5 tab con: `Overview` · `Deals` · `Contacts` · `Discussion`.

## 7. Settings — `/settings`

**Nhóm service:**
- `Pipelines` → `/settings`
- `Accounts` → `/settings/accounts`
- `Contacts` → `/settings/contacts`
- `Forecasts` → `/settings/forecasts`

**OPERATION:**
- `Teams` → `/settings/teams`
- `Permissions` → `/settings/permissions` *(coming soon)*
- `Activities` → `/settings/activities` *(coming soon)*
- `Webhooks` → `/settings/webhooks` *(coming soon)*

Mỗi service hiện dưới dạng thẻ với: tên, model (`sales.pipeline`…), trạng thái `Active`, người tạo + thời điểm, mô tả, và 2 nút `Setting` / `Go to <service>`. Góc phải trên có ô `Filter services…` và nút `+ Create pipeline` / `+ Create service`.

## 8. Inboxes — `/inbox`

Menu trái: `Compose` · `Inbox` · `Sent` · `Templates` · `Settings`.

Khi chưa nối mailbox, app hiện: *"No mail account connected — Connect your mailbox (Gmail, Outlook, or SMTP) in the Mail app."* Tức là việc kết nối hộp thư nằm ở **app Mail**, không nằm trong Sales.
