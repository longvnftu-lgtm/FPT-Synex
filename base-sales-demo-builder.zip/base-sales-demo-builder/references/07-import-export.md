# 07 — Import, Export và Duplications

## 1. Luồng import

Có ở mọi màn bảng: `Deals`, `Accounts`, `Contacts` (và `Quotas` của forecast).

Hộp thoại **Import deals**: *"From Excel (.xlsx) or CSV — download the template, fill it in, upload."*

### 1.1 Import mode

| Chế độ | Ý nghĩa |
|---|---|
| `Create new` | Tạo bản ghi mới. App ghi rõ: *"New deals are created in this pipeline. A deal never moves between pipelines."* |
| `Update existing` | Cập nhật bản ghi đã có |

### 1.2 Tuỳ chọn

- ☐ `Run in the background` — *"Large files always run in the background. Tick that to do it anyway — you can close this dialog and the import keeps going."*
- Cảnh báo: *"A sheet cannot win or lose a deal — closing one asks for a reason and its own required fields."*

### 1.3 Import file

- Nút `Download template` — **luôn dùng nút này**, template đã có sẵn đúng cột của pipeline đang mở
- Nút `Choose file…`
- Ghi chú: *"Each row needs a name. A row that leaves the stage blank lands on the first one."*
- Khối `Columns (n)` bấm để xem đặc tả từng cột

Nút `Cancel` / `Import`.

---

## 2. Đặc tả cột file import Deal

Pipeline mẫu `Bán hàng B2B` có **27 cột** = 17 cột hệ thống + 1 cột segmentation + 8 custom field + 1 cột segment. Số cột thay đổi theo từng pipeline — luôn mở `Columns (n)` để xem danh sách đúng.

### 2.1 Cột hệ thống

| Cột | Mô tả (nguyên văn app) | Ghi chú thực dụng |
|---|---|---|
| `name` | Deal name — required when creating | Bắt buộc |
| `stage` | Stage name in this pipeline | Phải khớp tên stage; để trống → rơi vào stage đầu |
| `value` | Amount, digits only | Không dấu phẩy, không ký hiệu tiền |
| `currency` | Currency code, e.g. USD or VND | |
| `account` | Company by name — **must already exist** | Tạo account trước |
| `account_id` | Company by exact id; wins over `account` when both are given | |
| `contact` | Person by email or name — **must already exist** | Tạo contact trước |
| `contact_id` | Person by exact id; wins over `contact` when both are given | |
| `owner` | Owner by username, email or name — exported as the username | |
| `labels` | Label names, separated by `;` | Label phải tồn tại |
| `followers` | Followers by username, email or name, separated by `;` — exported as usernames | |
| `probability` | Win probability as a whole percent, 0–100 | Chỉ dùng khi bật `Custom deal probability` |
| `expected_close` | Expected close date, `DD/MM/YYYY` | |
| `overview` | Short summary | |
| `status` | `active`, `won` or `lost` — closing runs the pipeline's close-time required fields | |
| `closed_at` | Close date, `DD/MM/YYYY`; only read when this row closes the deal | |
| `failed_reason` | Why it closed — a won or lost reason of this pipeline, by name | Phải khớp đúng tên trong Won/Lost reasons |
| `failed_comment` | Free-text note kept with the close | |

### 2.2 Cột segmentation

Tên cột = tên segmentation. Giá trị = tên option.

Ví dụ: cột `Phân khúc doanh nghiệp` → giá trị `Mid-market 100–499 người dùng`.

### 2.3 Cột custom field

Mỗi custom field là một cột, **tên cột là Label** (không phải code), map theo `code` phía sau.

Ví dụ của pipeline `Bán hàng B2B`:

| Tên cột | Code |
|---|---|
| Loại cơ hội | `custom_b2b_motion` |
| Số người dùng dự kiến | `custom_b2b_seats` |
| Ngày dự kiến chốt | `custom_b2b_close_date` |
| Bước tiếp theo | `custom_b2b_next_step` |
| Hạn bước tiếp theo | `custom_b2b_next_due` |
| Tiêu chí thành công POC | `custom_b2b_poc_criteria` |
| Người quyết định và quy trình mua | `custom_b2b_buying_process` |
| Ngân sách dự kiến VND | `custom_b2b_budget_vnd` |

---

## 3. Thứ tự nạp dữ liệu bắt buộc

```
1. Accounts   ─┐
2. Contacts   ─┼→ 3. Deals
```

Vì `account` và `contact` trong file deal là **tham chiếu tới bản ghi đã tồn tại**, không phải lệnh tạo mới. Nạp sai thứ tự → toàn bộ cột này bỏ trống và phải sửa tay từng deal.

---

## 4. Những việc import KHÔNG làm được

| Việc | Lý do | Cách thay thế |
|---|---|---|
| Chuyển deal sang pipeline khác | "A deal never moves between pipelines" | Dùng `Move to another pipeline` trên từng deal |
| Đóng deal (won/lost) hoàn chỉnh | Đóng cần reason + required fields riêng | Import với `status: active`, rồi đóng tay các deal cần thiết |
| Tạo account/contact mới từ file deal | Chỉ tham chiếu | Import account/contact trước |
| Tạo label, won/lost reason mới | Chỉ tham chiếu theo tên | Tạo trong Settings trước |

---

## 5. Export

Nút `Export ▾` ở mọi màn bảng. File sinh ra có tên dạng:
`deals-<pipeline_id>-YYYY-MM-DD.xlsx`

Mục `Data fields → Export` (trong Settings của pipeline) xuất **định nghĩa field**, không phải dữ liệu — dùng để nhân bản cấu hình sang pipeline khác qua `Data fields → Import`.

---

## 6. Import & export history

URL: `/io-history?pipeline=<id>`

Bộ lọc: loại đối tượng (`Deals`), `All types`, `Anyone`, `Last 30 days`, `Newest first`, nút `Refresh`.

Bảng: `JOB` / `RESULT` / `RUN BY` — mỗi dòng hiện loại job (Import/Export), tên file, số dòng, dung lượng, người chạy, thời điểm.

> Ghi chú của app: *"Exported files are kept for 7 days, then only the record of the run remains."*

---

## 7. Duplications

URL: `/duplications?pipeline=<id>`

- **`Merge any 2 records`** — chọn thủ công 2 bản ghi để gộp
- **`System-detected duplicates`** — *"Deals sharing the same name and primary contact — or the same name and account — show up here."*

Quy tắc phát hiện trùng của hệ thống:
- Cùng `name` + cùng `primary contact`, **hoặc**
- Cùng `name` + cùng `account`

> Khi sinh dữ liệu demo hàng loạt, đặt tên deal theo mẫu `<Tên công ty> – <giải pháp> <quy mô>` sẽ tự nhiên tránh trùng. Nếu dùng tên lặp kiểu "Deal 1", "Deal 2" thì không trùng nhưng trông giả — nên đặt tên thật.

Trước buổi demo, mở màn này một lần để chắc chắn không có cảnh báo trùng ngoài ý muốn.

---

## 8. Mẫu file import deal (gợi ý cột tối thiểu)

Với một demo gọn, chỉ cần 9 cột:

```
name | stage | value | currency | account | contact | owner | expected_close | overview
```

Thêm 2–3 custom field quan trọng nhất của ngành là đủ để câu chuyện có chiều sâu. Đừng điền hết 27 cột — vừa tốn công vừa không ai nhìn.
