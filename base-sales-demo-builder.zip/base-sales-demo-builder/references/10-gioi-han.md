# 10 — Giới hạn đã kiểm chứng

Danh sách này lấy **nguyên văn từ màn hình app** (bản 09/2026). Không suy đoán, không phỏng đoán lộ trình.

Mục đích: đừng hứa với khách những gì chưa có, và có sẵn câu trả lời thay thế khi bị hỏi.

---

## 1. Trong trang Deal — nhóm SMART OPS

| Mục | Thông báo của app |
|---|---|
| `Automations` | "Automations for this deal is coming soon." |
| `Sequences` | "Sequences for this deal is coming soon." |
| `SLAs` | "SLAs for this deal is coming soon." |
| `Agent flows` | "Agent flows for this deal is coming soon." |

**Cách trả lời khách:**
- Hỏi về SLA → "SLA hiện đang ở cấp pipeline: mỗi stage có ngưỡng rotting, deal nằm im quá hạn sẽ bị cảnh báo" → mở `Pipeline → SLAs` cho xem. Đây là câu trả lời thật và đủ mạnh.
- Hỏi về tự động hoá → hướng sang **Base BPM** (quy trình phê duyệt) hoặc **Base AgentHub** (agent AI), là các app khác trong hệ Base.
- Hỏi về sequence chăm sóc đa kênh → hướng sang **Base Lead**.

---

## 2. Trong Home — các mục chưa có

| Mục | Thông báo |
|---|---|
| `Stories` | "Stories coming soon — Your stories will live here." |
| `Feedbacks` | "Feedbacks coming soon — Your feedbacks will live here." |
| `Todos` | "Todos coming soon — Your todos will live here." |
| `Bookmarks` | "Bookmarks coming soon — Your bookmarks will live here." |
| `Calendar` | "Calendar coming soon — Your calendar will live here." |

**Lưu ý quan trọng:** `Todos` ở **Home** chưa có, nhưng `Todos` **trong trang deal và trang account thì đã chạy** (khối `Action plan`). Đừng nhầm hai chỗ này khi demo.

Tương tự, `Bookmarked deals` vẫn hiển thị ở đầu trang `Home → Deals` — chỉ có trang Bookmarks tổng hợp là chưa có.

**Cách trả lời:** dùng `Home → Tasks` thay cho Todos tổng hợp — màn này đã chạy tốt và gom việc từ mọi pipeline.

---

## 3. Trong Settings — nhóm OPERATION

| Mục | Thông báo |
|---|---|
| `Permissions` | "Role and per-service access control across pipelines, accounts, and contacts. **Lands in the next iteration.**" |
| `Activities` | "Activity types and defaults (meetings, calls, tasks) used across services. **Lands in the next iteration.**" |
| `Webhooks` | "Outbound webhooks for deal, account, and contact events. **Lands in the next iteration.**" |

**Cách trả lời:**
- Phân quyền → "Phân quyền hiện làm ở từng pipeline và từng danh bạ, chi tiết tới 9 loại quyền theo 5 nhóm quan hệ" → mở `Pipeline → Setting → Permissions` cho xem. Bảng này đủ chi tiết để thuyết phục.
- Webhook / tích hợp → hiện chưa có webhook outbound; phương án thay thế là export Excel định kỳ, hoặc dùng các app khác trong hệ Base vốn đã liên thông sẵn dữ liệu.

---

## 4. Teams

Màn `Settings → Teams` chỉ **liệt kê** thành viên workspace với vai trò `ADMIN` / `MEMBER`.

Ghi chú của app: *"Note: team grouping and membership management are coming in the next iteration."*

Nghĩa là: không tạo nhóm, không đổi vai trò, không thêm/bớt người tại đây.

**Lưu ý:** bảng `Permissions` của pipeline vẫn có cột theo team (ví dụ `Sales Enablement`) — team đó đến từ hệ thống tổ chức chung (Base Workforce), không tạo trong Sales.

---

## 5. Inboxes

Khi chưa nối mailbox, app hiện:
> "No mail account connected — Connect your mailbox (Gmail, Outlook, or SMTP) in the Mail app — your personal email will show up here."

Nghĩa là **việc kết nối email nằm ở app Mail**, không làm được trong Sales. Nếu buổi demo cần khoe luồng email, phải nối mailbox trước ở app Mail.

Nếu không kịp: đừng mở tab Inboxes. Vẫn có thể demo email ở cấp deal (nút `Email` trong Work stream) — nhưng nó cũng cần mailbox đã nối.

---

## 6. AI Copilot

Icon tia sáng ở header chỉ hoạt động khi đang mở **một deal, account hoặc report**. Khi không có ngữ cảnh, app hiện dòng chờ: *"Open a deal, account or report to ask Copilot."*

**Cách demo đúng:** mở sẵn một deal đã có đầy dữ liệu rồi mới bấm Copilot. Bấm từ trang danh sách sẽ không có gì xảy ra và trông như lỗi.

Ngoài ra, chất lượng câu trả lời phụ thuộc `AI Copilot rules` của pipeline — nếu chưa viết rule thì copilot chỉ trả lời chung chung.

---

## 7. Các điểm dễ gây hiểu nhầm khác

| Điểm | Thực tế |
|---|---|
| Form tạo Account mặc định tiền tệ **USD** | Phải đổi tay sang VND, nếu không dữ liệu hiện `$0` lẫn lộn |
| `Operation stages` của account/contact mặc định **trống hoàn toàn** | Account sẽ hiện "No stage found", form hiện "No stages configured" |
| Import **không** chuyển deal giữa các pipeline | Dùng `Move to another pipeline` trên từng deal |
| Import **không** đóng được deal won/lost trọn vẹn | Đóng cần reason + required field riêng |
| Import **không** tạo account/contact mới | Chỉ tham chiếu bản ghi đã có |
| `Avg deal value` hiển thị đầy đủ thập phân | Ví dụ `482130555.5555556` — tránh dùng nếu khách soi kỹ |
| Chart lấy dữ liệu **theo quyền của người tạo** | Demo bằng tài khoản khác có thể ra số khác hoặc trống |
| File export chỉ giữ **7 ngày** | Sau đó chỉ còn bản ghi lần chạy |

---

## 8. Nguyên tắc khi bị hỏi về tính năng chưa có

1. **Nói thẳng** là đang trên lộ trình, không vòng vo, không hứa thời điểm
2. **Đưa ngay phương án hiện có** — luôn có một thứ gần đúng để mở ra cho xem
3. **Nếu thuộc app khác trong hệ Base thì nói rõ tên app** — điều này biến một điểm yếu thành cơ hội bán thêm
4. **Ghi lại câu hỏi** — nhu cầu khách hỏi nhiều nhất là thông tin có giá trị cho đội sản phẩm
