# 05 — Forecast service và nhóm OPERATION

## PHẦN A — Forecast service

Mở bằng: `Settings → Forecasts →` nút **Setting**. Modal chỉ có **2 mục**: `General info` và `Quotas`.

### A.1 General info

**Thống kê đầu trang:** `FORECAST OBJECTS` · `TOTAL FORECAST` · `PERIODS COVERED` · `CONTRIBUTORS`

**Edit basic info**
- `Service name` *(bắt buộc)*
- `Description`
- `Service owners`
- `Service followers`
- `Status` — `Active`

**Forecast currency**

> "When set, every forecast value and every quota in this service is measured and shown in this one currency — including the quota targets reps are held to. Leave it off to let each enrolled object keep its own currency."

- Công tắc `Fix a single currency for this forecast`

> **Bẫy demo hay gặp:** để tắt thì mỗi object giữ tiền tệ riêng, màn forecast sẽ hiện lẫn `US$` và `₫` trông rất lộ. Khi dựng demo cho khách Việt Nam, **bật công tắc này và chọn VND**.

**Service info** (chỉ đọc): Created date, Last update, Status.

**Danger zone**
> "Deleting removes this forecast service and all enrolled objects, quotas and history — permanently."
- Nút `Delete service`

### A.2 Quotas

Bảng với cột `USER` / `QUOTA` / `OFFICIAL AT` + menu thao tác từng dòng.

- Dòng tóm tắt: "n rep · <tổng> in force"
- Ô `Search reps…`
- Dropdown `Sort: Name`
- Nút `Import` và `Set quota`

`Set quota` gán hạn mức cho từng rep, `OFFICIAL AT` là ngày hạn mức có hiệu lực. `Import` cho phép nạp quota hàng loạt.

### A.3 Màn hình Forecast khi vận hành

**Ở cấp module** (`Forecast` trên rail trái): chọn forecast service ở menu trái, xem `TOTAL FORECAST`, `THIS MONTH`, `NEXT MONTH`, `ENROLLED OBJECTS` (tách theo deals / accounts / contacts), khối `Forecast by period`. Dropdown `All services` để lọc.

**Ở cấp pipeline** (`Pipeline → Forecast`): màn hình vận hành đầy đủ.

- Breadcrumb: `<tên pipeline> › <tên forecast service>` + chọn tiền tệ
- Dòng hướng dẫn: "Submitting takes a snapshot of the forecast and sends it to the manager."
- Nút `+ Enroll deals` và `Submit forecast`
- 3 tab: `Forecast` · `Submission history` · `Forecast activity`
- Bộ chọn `Sales period:` (ví dụ `Q3 · Jul–Sep 2026`)

**7 thẻ chỉ số:**

| Thẻ | Ý nghĩa |
|---|---|
| `Quota rollup` | Tổng hạn mức của các rep trong kỳ |
| `Forecast call` | Con số rep cam kết |
| `Won` | Đã thắng |
| `Commit` | Chắc chắn |
| `Best case` | Kịch bản tốt nhất |
| `Open` | Chưa đưa vào call |
| `Omitted` | Rep chủ động loại khỏi dự báo |

Mỗi thẻ hiển thị kèm `% of quota`.

**Hai tab bảng:** `Reps` (Name / Last submitted / Forecast call / Won / Commit / Best case / Open / Omitted / Quota) và `Opportunities`.

### A.4 Cách đưa deal vào forecast

1. Ở pipeline: `Settings → General info` → bật `Enable forecast service`
2. Tạo forecast service ở `Settings → Forecasts → Create service`
3. Đặt quota: `Setting → Quotas → Set quota` cho từng rep
4. Enroll deal — hai cách:
   - Từ trang deal: menu `...` → `Enroll into a forecast`, hoặc khối `Forecasts` trên trang deal → `+ Enroll in forecast`
   - Từ màn forecast của pipeline: nút `+ Enroll deals`
5. Rep bấm `Submit forecast` để chốt snapshot gửi quản lý

Khối `Forecasts` trên trang deal hiển thị: số `FORECAST ENTRIES`, trạng thái enroll, và `Weighted value` = giá trị deal × probability (ví dụ `₫6,720,000 (10%)`).

---

## PHẦN B — Nhóm OPERATION

### B.1 Teams — `/settings/teams`

Bảng `Members in this workspace` với 3 cột: `NAME` · `EMAIL` · `ROLE`.

`ROLE` chỉ có 2 giá trị: **`ADMIN`** (badge xanh) và **`MEMBER`** (badge xám).

Cuối trang có ghi chú của app:
> "Note: team grouping and membership management are coming in the next iteration."

Nghĩa là hiện tại màn này **chỉ để xem** — không tạo được nhóm, không đổi vai trò tại đây. Việc quản lý thành viên workspace nằm ở app quản trị chung của Base.

> Lưu ý: bảng `Permissions` của pipeline/directory vẫn có cột theo **team** (ví dụ `Sales Enablement`) — team này đến từ hệ thống tổ chức chung (Base Workforce), không tạo trong Sales.

### B.2 Permissions — `/settings/permissions`

Nội dung hiện tại của trang, nguyên văn:
> "Role and per-service access control across pipelines, accounts, and contacts. **Lands in the next iteration.**"

Tức là phân quyền theo vai trò ở cấp toàn app **chưa có**. Toàn bộ phân quyền hiện phải làm ở từng service (xem file 03 và 04).

### B.3 Activities — `/settings/activities`

> "Activity types and defaults (meetings, calls, tasks) used across services. **Lands in the next iteration.**"

Chưa tuỳ biến được loại hoạt động. Meeting / Call / Task dùng cấu hình mặc định.

### B.4 Webhooks — `/settings/webhooks`

> "Outbound webhooks for deal, account, and contact events. **Lands in the next iteration.**"

Chưa có webhook. Khi khách hỏi tích hợp hệ thống ngoài, hướng sang: export Excel định kỳ, hoặc các app khác trong hệ Base.
