# 02 — Mô hình dữ liệu và thuật ngữ

## 1. Khái niệm cốt lõi: model và service

Base Sales không có "một" pipeline hay "một" danh bạ cố định. Mọi thứ là **service** — một thực thể có thể tạo nhiều bản, mỗi bản thuộc một **model**:

| Model | Gọi trong app | Chứa gì | Tạo ở đâu |
|---|---|---|---|
| `sales.pipeline` | Pipeline / Sales Pipeline | Deal (cơ hội bán hàng) | `Settings → Pipelines → Create pipeline` |
| `sales.account` | Account directory | Account (công ty, khách hàng) | `Settings → Accounts → Create service` |
| `sales.contact` | Contact directory | Contact (người liên hệ) | `Settings → Contacts → Create service` |
| `sales.forecast` | Forecast service | Quota + object được enroll | `Settings → Forecasts → Create service` |

Hệ quả quan trọng khi dựng demo:
- Có thể dựng **nhiều pipeline song song** cho nhiều nghiệp vụ khác nhau (ví dụ thực tế đã thấy: `Bán hàng B2B`, `Quy trình đấu thầu`, `Cơ hội thiết bị công nghiệp`).
- Có thể dựng **nhiều danh bạ account** tách biệt (ví dụ: `B2B` và `Khách hàng B2B CRM`).
- Custom field ở mức `Service Field` dùng chung được cho mọi service **cùng model** — rất tiện khi có 3 pipeline cần chung một trường.

Mỗi service có một `Relative path` dạng `/service/<id>` hiển thị ở `General info`.

## 2. Các đối tượng dữ liệu

### Deal — cơ hội bán hàng
Trường hệ thống:
- `Name` (bắt buộc)
- `Value` + `Currency`
- `Primary account` — liên kết tới 1 account
- `Primary contact` — liên kết tới 1 contact
- `Labels`
- `Deal owner`
- `Pipeline` + `Stage`
- `Probability` (%) — lấy theo stage hoặc đặt tay nếu bật `Custom deal probability`
- `Expected close date`
- `Status`: `Active` / `Won` / `Lost`
- `Followers`, `Collaborators`
- `Close reason`, `Closed at`
- Custom fields của pipeline

Ngoài ra deal còn có: Overview, Action plan (Tasks + Todos), Work stream, Discussion, Deal flows, Deal insights, Deal files, Commerce (Quotes / Orders / Contracts / Subscriptions), Forecast entries.

### Account — công ty / khách hàng
Trường hệ thống: `Account name` (bắt buộc), `Domain`, `Account service` + stage, `Estimated lifetime value` + currency, `Account owner`, `Description`, `Address` (có bản đồ chọn địa điểm), `Labels`.

Account có `Activity overview` (Mails / Meetings / Calls / Notes + thời điểm gần nhất) và `Insights` (Est. lifetime value, Open deals, Contacts).

### Contact — người liên hệ
Cột mặc định trong bảng: NAME, TITLE, ACCOUNT, EMAIL, PHONE, OWNER, COLLABORATORS, STAGE, STATUS, LABELS, CREATED BY, CREATED AT, UPDATED AT, LAST ACTIVITY TIME — cộng các custom field (16 cột mặc định trong tenant mẫu).

### Forecast
Không phải một bảng riêng: forecast là một **service** mà deal/account/contact được **enroll** vào, theo từng kỳ (sales period). Mỗi rep có một `Quota`.

## 3. Quan hệ giữa các đối tượng

```
Account directory ──┬── Account ──┬── Deals (Primary account)
                    │             └── Contacts
Contact directory ──┴── Contact ───── Deals (Primary contact)

Pipeline ── Stage ── Deal ──┬── Tasks / Todos
                            ├── Notes / Emails / Calls / Meetings (Work stream)
                            ├── Commerce: Quotes / Orders / Contracts / Subscriptions
                            └── Forecast entry ── Forecast service ── Quota theo rep
```

Ràng buộc thực tế:
- Deal **phải** trỏ tới account/contact **đã tồn tại** — import không tự tạo account mới.
- Deal **không bao giờ tự chuyển pipeline** qua import; muốn chuyển phải dùng `Move to another pipeline` trên từng deal.
- Forecast chỉ nhận deal từ pipeline đã bật `Enable forecast service`.

## 4. Từ điển thuật ngữ

| Thuật ngữ trong app | Nghĩa |
|---|---|
| **Deal** | Cơ hội bán hàng |
| **Stage** | Giai đoạn trong pipeline |
| **Probability** | Xác suất thắng gắn với stage (%) |
| **Rotting** | Số ngày một deal nằm im trong stage trước khi bị cảnh báo "ôi thiu" |
| **SLA** | Trong Base Sales, SLA cấp pipeline = ngưỡng rotting của từng stage |
| **Owner** | Người sở hữu bản ghi, luôn có đủ quyền |
| **Collaborator** | Người được mời cùng làm trên bản ghi |
| **Follower** | Người theo dõi để nhận thông báo |
| **Segmentation** | Phân khúc — một trường phân loại có danh sách option cố định |
| **Label** | Nhãn màu gắn tự do lên bản ghi |
| **Work stream** | Dòng hoạt động (note, email, call, meeting, quote, order) trên bản ghi |
| **Action plan** | Khối Tasks + Todos trên trang bản ghi |
| **Operation stages** | Vòng đời của account/contact, chia 4 nhóm |
| **Directory** | Một danh bạ account hoặc contact |
| **Enroll** | Đưa một deal vào forecast service hoặc automation |
| **Compute engine** | Nguồn dữ liệu của một chart trong Reports |

## 5. Vai trò người dùng

Ở `Settings → Teams`, mỗi thành viên workspace có vai trò `ADMIN` hoặc `MEMBER`.

Ngoài ra, quyền thực tế trên từng bản ghi được quyết định bởi 4 lớp:
1. **Owner** (pipeline owner / deal owner) — luôn đủ quyền, không chịu bảng permission
2. **Accesses & visibilities** — ai nhìn thấy service và bản ghi
3. **Permissions** — ma trận quyền chi tiết theo nhóm quan hệ
4. **Vai trò workspace** (ADMIN/MEMBER)
