# 06 — Các màn hình nghiệp vụ

## 1. Kanban pipeline

Thanh trên cùng:
- Dropdown `View: Visible deals`
- Dòng tổng: `n deals · Total: <tổng giá trị> · Projected: <giá trị kỳ vọng>`
  - `Projected` = tổng của (giá trị deal × probability của stage)
- Ô `Quick filter deals`
- Nút `Filters ›`
- Nút `+ Add deal`

Mỗi cột stage có header: tên stage (màu theo stage) · số deal · tổng giá trị · `% of pipeline`.

Mỗi thẻ deal hiện: tên deal · (contact · account nếu có) · avatar owner · giá trị. Thẻ đang bị rotting được tô nền cảnh báo. Kéo thả thẻ để chuyển stage.

## 2. Bảng Deals

Thanh công cụ: `View filters` · `Sort` · `Columns (18)` · `Export` · `Import` — cộng `Advanced filters ›`, ô `Quick filter deals`, nút `+ Add deal`. Góc phải: `Showing 1–n of n`.

**18 cột mặc định:**

```
DEAL                 VALUE               STAGE
STAGE JOINED TIME    ACCOUNT             CONTACT
OWNER                LABELS              STATUS
CLOSED AT            CLOSE REASON        FOLLOWERS
COLLABORATORS        CREATED AT          CREATED BY
EXPECTED CLOSE AT    LAST UPDATED AT     LAST ACTIVITY TIME
```

Cột `STAGE` hiển thị dạng `[3/5] Demo scheduled` kèm thanh tiến độ — rất trực quan khi demo.

## 3. Form tạo Deal (`+ Add deal`)

Tiêu đề: "New deal — Create a new opportunity"

| Trường | Ghi chú |
|---|---|
| `Name` *(bắt buộc)* | placeholder "e.g. Acme Robotics – pilot" |
| `Value` + `Currency` | mặc định theo pipeline (ví dụ VND) |
| `Primary account` | ô `Search accounts…` |
| `Primary contact` | ô `Search contacts…` |
| `Labels` | |
| `Deal owner` | mặc định người đang đăng nhập |
| `Pipeline` + `Stage` | |
| `Custom fields` | gom theo nhóm, ví dụ `General information` (8 fields), bấm để mở rộng |

Nút `Cancel` / `Create deal`.

## 4. Trang chi tiết Deal

### 4.1 Khu vực đầu trang
- Tên deal (lớn) + avatar `Deal owner` bên phải
- Dòng meta: giá trị · primary contact · primary account
- **Thanh stage ngang**: các stage hiển thị dạng mũi tên nối tiếp, stage hiện tại tô đậm — bấm để chuyển stage
- Dòng dưới: breadcrumb pipeline › stage · `Probability: 10%` · `⚑ Set expected closed date`

### 4.2 Các khối nội dung (layout Standard)

**Cột trái — dữ liệu**

| Khối | Nội dung |
|---|---|
| `Overview` | `Projected value` (giá trị + badge `Active`), `Probability`, `Pipeline › Stage` |
| `Forecasts` | số `FORECAST ENTRIES`, nút `+ Enroll in forecast`, `Weighted value` = giá trị × probability |
| `Custom fields` | `n/8 fields`, nút `Show empty fields (n)`, gom theo nhóm |
| `Primary contact` | tên, Phone, Email, Labels, Other phones, Other emails + `ADDITIONAL CONTACTS (n)` |
| `Primary account` | tên + domain |
| `Deal flows` | `Created at`, `Current stage` dạng `Qualifications (1/5)` |
| `Deal insights` | |

**Cột giữa — công việc**

| Khối | Nội dung |
|---|---|
| `Action plan` | `Tasks` (ô "Add a task — press Enter to assign to yourself…") và `Todos` (ô "Create todo, use @ to tag followers") |
| `Work stream` | Thanh nút tạo: `Note` · `Email` · `Call` · `Meeting` · (`Quote` · `Order` nếu bật ở Work stream settings). Ô soạn nhanh "Add a note, send an email, log a call…". Bộ lọc: `All` · `Note` · `Email` · `Call` · `Meeting` · `More ▾`. Sắp xếp `Most recent ▾` |

**Cột phải — người và file**

| Khối | Nội dung |
|---|---|
| `Owner & team` | Deal owner, `Collaborators (n)` + nút `Collab`, `Followers` + `Add followers` / `Follow` |
| `Discussion` | ô `Write a comment...`, đính kèm, emoji, công tắc `Press enter to send`, nút `Submit` |
| `Deal forecasts` | |
| `Deal files` | |

### 4.3 Tab Commerce

4 thẻ tổng: `Quotes` · `Orders` · `Contracts` · `Subscriptions` — mỗi thẻ có tổng tiền và dòng mô tả (`n quotes · open value`, `n orders · booked`, `n contracts · contract value`, `n subscriptions · MRR`).

Dưới là 4 khối tương ứng, mỗi khối có nút `+ Add quote` / `+ Add order` / `+ Add contract` / `+ Add subscription` và mô tả:
- Quotes: "Non-binding proposals sent to the customer."
- Orders: "Committed purchases being fulfilled."
- Contracts: "Signed agreements governing the relationship."
- Subscriptions: "Recurring billing plans."

### 4.4 Đóng deal

Nút **Won** → hộp thoại `Close as won` ("Time to celebrate!"):
- `Reason` — dropdown lấy từ `Won reasons` của pipeline
- `Note` — "Optional details for the deal history"
- Nút `Cancel` / `Close as won`

Nút **Lost** → hộp thoại tương tự, lấy `Lost reasons`.

Nếu `Field requirements before closing a deal` đặt ở mức `Strict`, hộp thoại sẽ kèm các field bắt buộc và **từ chối đóng** khi còn trống.

## 5. Trang chi tiết Account

4 tab con: `Overview` · `Deals` · `Contacts` · `Discussion`.

**Overview** gồm:
- `Service & stage` — tên directory + stage (hiện "No stage found" nếu chưa cấu hình operation stage)
- `Owner & team` — Account owner, Collaborators, Followers
- `Details` — Domain, Address, Labels, Created
- `Activity overview` — số Mails / Meetings / Calls / Notes kèm %; `Last activity`: Last email at, Last meeting created at, Last meeting scheduled, Last call at, Last note at
- `Insights` — `Est. lifetime value`, `Open deals`, `Contacts`
- `Action plan` và `Work stream` giống trang deal

## 6. Home → Tasks

3 thẻ số: `Active` · `Overdue` · `Completed`. Bảng `All tasks`.

Mỗi dòng task hiển thị: tên task · tên bản ghi cha · tên pipeline/service · mức ưu tiên (`High` / `Low`) · hạn (ví dụ `Thứ 3, 15 thg 9`) · trạng thái tương đối (`Today`, `Tomorrow`, `1 day overdue`, `No deadline`).

> Đây là màn hình đáng khoe khi demo: nó gom việc từ **mọi pipeline và mọi service** về một chỗ. Nên chuẩn bị sẵn 1 task quá hạn + 1 task hôm nay + 1 task không hạn.

## 7. Home → Meetings / Calls

Danh sách hoạt động. Khi trống hiện "No meetings yet." / "No calls yet."

## 8. SLAs (cấp pipeline)

3 thẻ: `ACTIVE DEALS` · `BREACHING SLA` (kèm dòng "silent past the stage's rotting limit") · `STAGES WITH SLA`.

Bảng `Stage SLAs`: `STAGE` / `SLA (ROTTING)` / `DEALS` / `AVG DAYS INACTIVE` / `BREACHING`.

## 9. Duplications

Hai phần:
- `Merge any 2 records` — gộp thủ công
- `System-detected duplicates` — "Deals sharing the same name and primary contact — or the same name and account — show up here."

## 10. Activity logs

Nhật ký theo ngày, mỗi dòng gồm: avatar · câu mô tả hành động · người thực hiện + thời điểm · `View changes ▾` · badge loại sự kiện.

Các badge đã gặp: `DEAL.ACCOUNT.UPDATED`, `DEAL.CONTACT.UPDATED`, `DEAL.MOVED`, `DEAL.UPDATED.BASIC`, `FIELDS.EDITED`, `PIPELINE.EDITED`.

Bộ lọc: khoảng ngày (`dd/mm/yyyy` – `dd/mm/yyyy`), `Filter by users`, `All actions`.
