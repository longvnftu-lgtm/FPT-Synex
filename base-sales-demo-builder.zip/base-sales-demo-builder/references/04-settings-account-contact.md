# 04 — Settings của Account directory và Contact directory

Mở bằng: `Settings → Accounts` (hoặc `Contacts`) → nút **Setting** trên thẻ directory.

Cấu trúc modal giống nhau cho cả hai, chia 2 nhóm:

**DIRECTORY:** `General info` · `Custom fields` · `Operation stages` · `Accesses & visibilities` · `Permissions` · `Custom views` · `AI Copilot`

**SYSTEM-WIDE SETTINGS:** `Labels & taggings` · `Segmentations`

> So với pipeline: **không có** `Pipeline stages`, `Customized layouts`, `Work stream`, `Won/Lost reasons`. **Có thêm** `Operation stages`.

---

## 1. General info

- `Account directory name` *(bắt buộc)* — với contact là `Contact directory name`
- `Description`
- `Directory owners`
- `Directory followers`
- Nút `Save changes`
- Khối `Directory info` (chỉ đọc): Created date, Last update, Status

---

## 2. Custom fields

Giống hệt cơ chế ở pipeline: 3 phạm vi (`Global Field` / `Service Field` / `Internal Field`), 26 kiểu dữ liệu, cờ `ON FORMS` và `IN VIEWS`, các nút `New Field` / `Pick existing field…` / `Export` / `Import`.

Khi chưa có field: "No custom fields assigned. Add fields to customize forms for this service."

### System fields của Account

| FIELD | SHOW ON FORM | REQUIRED | REQUIRED AFTER STAGE |
|---|---|---|---|
| `Domain` | ✓ | ☐ | Never |
| `Account value` | ✓ | ☐ | Never |
| `Address` | ✓ | ☐ | Never |
| `Labels` | ✓ | ☐ | Never |

Quy tắc `REQUIRED AFTER STAGE` giống pipeline: chỉ kiểm khi bản ghi **đã rời khỏi** stage được chọn.

---

## 3. Operation stages

Đây là điểm khác biệt lớn nhất so với pipeline. Vòng đời của account/contact được chia thành **4 nhóm cố định (bucket)**:

| Bucket | Ý nghĩa |
|---|---|
| `ACTIVE / OPERATIONAL` | Đang hoạt động |
| `CLOSED / SUCCESS / DONE` | Đã đóng, thành công |
| `CLOSED / LOST / FAILED` | Đã đóng, thất bại |
| `DISCARDED / IGNORED / TRASHED` | Bỏ qua, loại |

Mặc định **cả 4 bucket đều trống** — app hiện "No stages in this bucket yet". Tạo stage bằng nút `Create stage` (chọn bucket đích).

Hệ quả khi dựng demo: nếu không tạo stage nào, trang account sẽ hiện "No stage found" và form tạo account hiện "No stages configured". Điều này **không chặn** việc tạo account, nhưng trông thiếu hoàn thiện khi demo. Nếu kịch bản demo có nhắc vòng đời khách hàng thì nên tạo tối thiểu:
- ACTIVE: `Tiềm năng` · `Đang chăm sóc` · `Khách hàng`
- CLOSED/SUCCESS: `Khách hàng đang dùng`
- CLOSED/LOST: `Ngừng hợp tác`
- DISCARDED: `Không phù hợp`

---

## 4. Accesses & visibilities

**Account directory access and visibility** — "Directory owners have full permissions by default."

| Câu hỏi | Lựa chọn |
|---|---|
| `Who can access the account directory?` <br>*(thấy danh bạ, không đồng nghĩa thấy account bên trong)* | `Everyone can access it` / `Limit who can access it` |
| `Who can create new accounts in the directory?` | `Everyone who can access it can create new accounts` / `Limit who can create new accounts` |
| `Who can report on every account of the directory?` | `Only directory owners` / `Directory owners and specific people` |

**Account access and visibility** — "Extra ways into the accounts themselves, on top of owning or following them."

| Câu hỏi | Lựa chọn |
|---|---|
| `Who can access every account of the directory?` <br>*(mặc định chỉ thấy account mình own hoặc follow)* | `Not granted to anyone` / `Only directory owners` / `Directory owners and specific people` |
| `Who can access accounts with no owner?` | `Only directory owners` / `Directory owners and specific people` |

---

## 5. Permissions

> "Directory owners and account owners always have every permission — this table does not apply to them."

**Cột:** `Service followers` · `Account followers` · `Managers of account owner` · `Peers of account owner` · *(các team, ví dụ `Sales Enablement`)*

**Hàng:**

| Mã | Tên | Nội dung |
|---|---|---|
| `edit.general` | General edits | Sửa mọi thông tin account, trừ controlling và lifecycle |
| `edit.primary` | Edit controlling fields | Sửa owner và collaborators |
| `edit.lifecycle` | Update account lifecycle status | Đổi directory, đổi stage, hoặc merge account |
| `ops.general` | Basic operations | Tasks, todos, log activities (notes, files, quicklogs) |
| `ops.mail` | Mail operation | Gửi và đọc mail |
| `ops.call` | Call operation | Tạo và nhận cuộc gọi |
| `ops.meeting` | Meeting operation | Tạo và theo dõi cuộc họp |
| `data.basic` | Basic associated data | Feedbacks, stories, kudos, channels |

> So với pipeline: account **có thêm** `ops.call`, **không có** `data.commerce` và `data.contract`. Nội dung `data.basic` cũng khác (feedbacks/stories/kudos/channels thay vì feed posts/comments).

---

## 6. Custom views

Giống pipeline: danh sách view bật/tắt, `+ Create view` với phạm vi `Private — only you` / `Public — everyone on this pipeline`.

---

## 7. AI Copilot

Giống pipeline: danh sách `AI Copilot rules` áp cho mọi account trong directory, nút `+ Add rule`.

Rule cho account nên tập trung vào: mức độ gắn kết của khách hàng, tần suất tiếp xúc gần nhất, cơ hội mở rộng, dấu hiệu rủi ro rời bỏ — khác với rule cho deal (tập trung vào chốt đơn).

---

## 8. Labels & taggings / Segmentations

Nằm trong nhóm **SYSTEM-WIDE SETTINGS**, cơ chế giống ở pipeline: nhãn theo tên + mã màu, phân khúc theo tên + danh sách option.

---

## 9. Form tạo Account (`+ Add account`)

| Trường | Ghi chú |
|---|---|
| `Account name` *(bắt buộc)* | placeholder "e.g. Acme Robotics" |
| `Domain` | placeholder "acme.com" |
| `Account service` *(bắt buộc)* | chọn directory + ô stage bên cạnh (hiện "No stages configured" nếu chưa tạo operation stage) |
| `Estimated lifetime value` | số + chọn tiền tệ (mặc định `USD — US Dollar`) |
| `Account owner` | mặc định người đang đăng nhập |
| `Description` | |
| `Address` | ô `Search an address or place…` + bản đồ tương tác |

Nút `Cancel` / `Create account`.

> Lưu ý demo: tiền tệ mặc định ở form account là **USD**, không phải VND. Phải đổi thủ công hoặc dữ liệu sẽ hiện `$0` lẫn lộn.

---

## 10. Bảng danh sách Account / Contact

Thanh công cụ: `Filters` · `Sort` · `Columns (n)` · `Export` · `Import` — cộng `Advanced filters ›`, ô tìm kiếm, nút `+ Add account` / `+ Add contact`, và dropdown `View: Visible accounts`.

**Cột mặc định của Account (13):** NAME, DOMAIN, ADDRESS, OWNER, COLLABORATORS, STAGE, STATUS, LABELS, VALUE, CREATED BY, CREATED AT, UPDATED AT, LAST ACTIVITY TIME

**Cột mặc định của Contact (16):** NAME, TITLE, ACCOUNT, EMAIL, PHONE, OWNER, COLLABORATORS, STAGE, STATUS, LABELS, *(các custom field)*, CREATED BY, CREATED AT, UPDATED AT, LAST ACTIVITY TIME

Menu trái của module Accounts/Contacts: `Accounts`/`Contacts` · `Activities` — và ở cuối: `Duplications` · `Import & export history` · `Settings`.
