# 08 — Reports và Dashboard

## 1. Màn hình Reports — `/reports`

Hai tab: `All dashboards` · `My dashboards`. Dòng mô tả: "Analyze and visualize your sales data".

Bảng dashboard: `NAME` / `CREATED BY` / `CHARTS` / `UPDATED`. Mỗi dòng có tên + mô tả, số chart, người tạo, thời điểm cập nhật, menu `…`.

Nút `+ New dashboard` (góc phải trên và cuối menu trái).

## 2. Bên trong một dashboard

Header: tên dashboard · `n charts` · icon ghim.

Thanh nút: `Ask` · `Explain` · `Filter` · `+ Add chart` · menu `…`

- **`Ask`** — hỏi dữ liệu bằng ngôn ngữ tự nhiên
- **`Explain`** — để AI diễn giải dashboard
- **`Filter`** — lọc chung cho toàn dashboard

Mỗi chart là một thẻ, có các icon: ghim, phóng to, sửa, xoá.

## 3. Trình tạo chart (`+ Add chart`)

Tiêu đề: "Add chart — Pick a compute engine and choose how to visualize it."

Hai tab: **`Data`** và **`Visualization`**.

### 3.1 Tab Data

**GENERAL**

| Trường | Lựa chọn |
|---|---|
| `Compute Engine` | `Deals` · `Accounts` · `Contacts` · `Activity` |
| `Chart name` *(bắt buộc)* | placeholder "e.g. Meetings by service" |

Dưới `Compute Engine` có dòng giải thích, ví dụ với Deals: *"Aggregate across all deals you can access"* — tức phạm vi dữ liệu phụ thuộc quyền của người tạo chart. Đây là lý do `Who can report on every deal of the pipeline?` trong Accesses & visibilities quan trọng.

**FILTERS** (khi engine là Deals)

| Bộ lọc | Mặc định |
|---|---|
| `Pipeline` | All pipelines |
| `Stage` | All stages |
| `Status` | All |
| `Owner` | All owners |
| `Created date` | khoảng từ – đến |

### 3.2 Tab Visualization

**`DESCRIBE THE CHART`** — ô nhập mô tả bằng câu chữ (placeholder: *"e.g. deal value by stage over the last 6 months"*) + nút `Build`. Đây là cách nhanh nhất để dựng chart khi demo.

**`CHART TYPE`** — 9 loại:

```
Bar          Line            Pie             Summary
Stacked bar  Stacked column  Funnel
Word cloud   Pivot table
```

**`MEASURES`** (với engine Deals) — chọn nhiều:
- `Deals` (đếm số deal)
- `Deal value` (tổng giá trị)
- `Avg deal value`

**`GROUP BY`** — 7 lựa chọn:
```
None (total)   Pipeline   Stage   Status
Owner          Lost reason   Currency
```

**`OVER TIME`** — mặc định `None`.

**`PREVIEW`** — xem trước ngay bên phải, cập nhật theo thao tác.

Nút `Cancel` / `Add chart`.

## 4. Bộ chart tối thiểu cho một buổi demo

Hai chart này đủ kể câu chuyện và đã chạy thật:

### Chart 1 — "Tổng quan pipeline"
- Compute Engine: `Deals`
- Filter: `Pipeline` = pipeline đang demo
- Chart type: `Summary`
- Measures: `Deals` + `Deal value` + `Avg deal value`
- Group by: `None (total)`

Kết quả: 3 ô số lớn — số deal, tổng giá trị, giá trị trung bình.

### Chart 2 — "Phễu chuyển đổi theo giai đoạn"
- Compute Engine: `Deals`
- Filter: `Pipeline` = pipeline đang demo, `Status` = All
- Chart type: `Funnel`
- Measures: `Deals`
- Group by: `Stage`

Kết quả: phễu nhiều tầng với số deal và % từng stage.

## 5. Bộ chart mở rộng (khi khách hỏi sâu)

| Câu hỏi của khách | Cấu hình chart |
|---|---|
| "Ai đang bán tốt nhất?" | Bar · Measure `Deal value` · Group by `Owner` |
| "Vì sao chúng tôi thua?" | Pie · Measure `Deals` · Group by `Lost reason` · Filter Status = lost |
| "Doanh số theo thời gian?" | Line · Measure `Deal value` · Over time = tháng |
| "So sánh các pipeline?" | Stacked column · Measure `Deal value` · Group by `Pipeline` |
| "Giá trị đang nằm ở giai đoạn nào?" | Bar · Measure `Deal value` · Group by `Stage` |
| "Bảng chéo giai đoạn × nhân viên" | Pivot table · Group by `Stage`, cột theo `Owner` |

## 6. Lưu ý khi dựng chart demo

- **Kiểm tra con số trước buổi demo.** Chart lấy dữ liệu thật, nếu import sai thì sai luôn trên báo cáo.
- **Giá trị trung bình hiện đầy đủ thập phân** (ví dụ `482130555.5555556`) — trông xấu. Nếu khách soi kỹ, dùng `Deal value` và `Deals` riêng thay vì `Avg deal value`.
- **Funnel cần deal rải đủ các stage.** Một stage trống làm phễu gãy và mất ý nghĩa.
- **Đặt tên chart bằng tiếng Việt, theo ngôn ngữ khách dùng** — đây là thứ khách đọc đầu tiên.
- Dashboard tạo bởi ai thì thấy dữ liệu theo quyền của người đó. Nếu demo bằng tài khoản khác, kiểm tra lại chart có ra số không.

## 7. Liên hệ với Forecast

Reports trả lời câu hỏi **"đang có gì"**. Forecast trả lời **"sẽ về bao nhiêu"**.

Nếu buổi demo chỉ có 20 phút, dựng Reports là đủ. Forecast cần thêm: bật `Enable forecast service`, tạo forecast service, đặt quota, enroll deal — và nếu không đủ dữ liệu thì màn forecast trống trơn, phản tác dụng.

Chi tiết vận hành forecast xem file `05-settings-forecast-operation.md`, phần A.3.
