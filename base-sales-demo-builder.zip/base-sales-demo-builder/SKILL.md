---
name: base-sales-demo-builder
description: Dựng hệ thống demo trên app Base Sales (Standard CRM, sales.base.com.vn) — bản đồ tính năng, điều hướng, toàn bộ màn Settings và quy trình cấu hình + nạp dữ liệu demo theo ngành. Dùng khi cần chuẩn bị tài khoản demo cho khách, cấu hình pipeline/field/quyền, nạp deal–account–contact mẫu, dựng báo cáo demo, hoặc giải thích một màn hình trong Base Sales.
---

# Dựng hệ thống demo trên Base Sales

Toàn bộ nội dung trong skill này được **ghi từ màn hình thật** của `sales.base.com.vn` (bản 09/2026). UI của app là tiếng Anh, dữ liệu là tiếng Việt — tên menu giữ nguyên tiếng Anh như trong app để tra cứu không lệch.

## Dùng skill này khi

- Chuẩn bị tài khoản demo Base Sales cho một khách hàng cụ thể
- Cấu hình pipeline, stage, custom field, phân quyền, báo cáo
- Nạp dữ liệu demo bằng import Excel/CSV
- Giải thích một màn hình / khái niệm trong Base Sales cho khách hoặc đồng nghiệp
- Đối chiếu tính năng khi trả hồ sơ thầu hoặc so sánh với đối thủ

## Cách đọc bộ tài liệu

| File | Nội dung |
|---|---|
| `references/01-dieu-huong.md` | Bản đồ điều hướng đầy đủ: module, menu con, URL |
| `references/02-mo-hinh-du-lieu.md` | Model, service, thuật ngữ, quan hệ giữa các đối tượng |
| `references/03-settings-pipeline.md` | 13 mục cấu hình của một pipeline — chi tiết từng tuỳ chọn |
| `references/04-settings-account-contact.md` | Cấu hình danh bạ công ty và người liên hệ |
| `references/05-settings-forecast-operation.md` | Forecast service, quota, Teams / Permissions / Activities / Webhooks |
| `references/06-man-hinh-nghiep-vu.md` | Kanban, bảng deal, trang chi tiết deal/account, Home, Inboxes |
| `references/07-import-export.md` | Đặc tả 27 cột file import deal, luồng import/export, duplications |
| `references/08-reports-forecast.md` | Dashboard, trình tạo chart, vận hành forecast |
| `references/09-playbook-dung-demo.md` | **Quy trình 10 bước dựng demo** + checklist nghiệm thu |
| `references/10-gioi-han.md` | Tính năng "coming soon" đã kiểm chứng — đừng hứa với khách |
| `references/11-faq.md` | Câu hỏi khách hay gặp và cách trả lời |

**Luồng dùng chuẩn:** đọc `09-playbook-dung-demo.md` trước để biết làm gì theo thứ tự nào, rồi tra sang các file chi tiết khi cần đúng tuỳ chọn.

## Tóm tắt 60 giây

Base Sales là CRM: mọi thứ là **service** thuộc một **model** (`sales.pipeline`, `sales.account`, `sales.contact`, `sales.forecast`). Một tenant có nhiều pipeline và nhiều danh bạ song song.

Thứ tự dựng demo không được đảo: **danh bạ → pipeline → field → reference data → quyền → dữ liệu → forecast/report → chi tiết deal → nghiệm thu**. Đảo thứ tự sẽ phải sửa ngược, vì deal tham chiếu account/contact theo tên và import sẽ fail nếu chưa có sẵn.

Ba thứ hay bị quên và làm hỏng buổi demo:
1. Chưa bật `Enable forecast service` ở pipeline → không enroll deal vào forecast được
2. Import deal trước khi có account/contact → cột `account`, `contact` bỏ trống hàng loạt
3. Toàn bộ deal cùng mốc thời gian `just now` → khách nhận ra là data giả ngay

## Quy ước khi viết tài liệu này

- Tên menu, nút, trường: giữ nguyên tiếng Anh như app hiển thị
- Mã quyền, mã field, tên cột import: viết trong `code block`
- Chỗ nào app ghi "coming soon" / "lands in the next iteration" đều được đánh dấu rõ, không suy đoán
