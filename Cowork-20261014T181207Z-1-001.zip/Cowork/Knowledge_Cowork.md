---
app: Base Cowork
url: https://cowork.base.com.vn
nguồn: khảo sát trực tiếp trên giao diện ứng dụng (không dùng tài liệu giới thiệu hay nguồn web)
ngày khảo sát: 23–24/08/2026
môi trường: DEMO — tenant Công ty CP Base Enterprise
---

# Base Cowork — Knowledge base tính năng

## 1. Sản phẩm này là gì

Base Cowork là ứng dụng quản trị dự án đa loại công việc. Điểm khác biệt so với một công cụ
quản lý việc thông thường: trong **cùng một dự án**, doanh nghiệp đặt cạnh nhau được bảng công
việc, luồng xử lý có cổng duyệt, sổ rủi ro, kho tài liệu, kế hoạch ngân sách và kế hoạch nhân
lực — rồi **nối chúng lại**. Mỗi giờ công và mỗi đồng chi phí thực tế được ghi nhận ngược về
đúng dòng kế hoạch và đúng công việc đã tiêu thụ nó.

Ứng dụng tự mô tả trong phần Settings ▸ Extra settings: *"Cowork — concept build on the platform
layer."*

### Bốn điểm cốt lõi
1. **Nhiều loại board trong một dự án** — 8 model board chia 3 nhóm, bật/tắt theo nhu cầu.
2. **Kế hoạch và thực chi nối liền nhau** — dòng ngân sách → bản ghi tiêu thụ → công việc.
3. **Quản trị theo tầng** — workspace (khối/phòng ban) → dự án → board.
4. **Báo cáo và check-in dựng sẵn** — không phải tự dựng dashboard.

---

## 2. Mô hình dữ liệu (kiến trúc khái niệm)

```
Công ty
└── Workspace                 (khối / phòng ban; có pipeline giai đoạn riêng)
    └── Dự án                 (chạy qua các giai đoạn của pipeline; có mã PRD-xxx)
        ├── Board             (8 model, chia 3 nhóm — xem §4)
        │   ├── Stage / Step  (cột kanban của board Task | bước của board Flow)
        │   ├── Tasklist      (lane / nhóm việc của board Task)
        │   └── Item          (Task | Flow item | Issue | Doc | File | Plan line)
        ├── WBS               (Work plan → Work package, có giờ công)
        ├── Milestone         (cột mốc, có deliverable)
        ├── Roadmap           (pha + cột mốc trên trục thời gian)
        ├── Outcome           (định nghĩa hoàn thành của dự án)
        ├── Backlog           (Epic → User Story, có điểm và giai đoạn riêng)
        ├── Issue             (sổ rủi ro & sự cố)
        ├── Plan line         (dòng ngân sách / dòng nhân lực)
        │   └── Booking       (bản ghi tiêu thụ thực tế, gắn được vào một công việc)
        └── Check-in          (báo cáo tiến độ định kỳ)
```

**Danh mục dùng chung ở cấp công ty**: Item types (5 nhóm) và Templates (mẫu dự án).

---

## 3. Ba tầng điều hướng

### 3.1 Tầng ứng dụng (thanh bên trái)
| Mục | Nội dung |
|---|---|
| **Home** | Trang chủ cá nhân, nhiều tab, ghép từ block |
| **Projects** | Danh mục toàn bộ dự án, hai chế độ List / Card |
| **My works** | My tasks · My milestones · My projects, lọc Open / Overdue / Done |
| *(dự án đã gắn sao)* | Ghim thẳng lên thanh điều hướng |
| **WORKSPACES** | Danh sách khối / phòng ban |
| **Templates** | Thư viện mẫu dự án |
| **Settings** | Workspaces · Projects · Item types · Extra settings |

Thanh trên cùng: ô **Search anything…** (`Ctrl/⌘K`), trợ giúp, thông báo, chuyển sáng/tối, avatar.

### 3.2 Tầng workspace
Trang `/workspaces/<id>`: hai chế độ **List | Board**. Chế độ Board là **kanban dự án theo
pipeline giai đoạn** của workspace đó. Thẻ dự án hiển thị mã dự án, nhãn sức khoẻ lấy từ
check-in gần nhất, tiến độ, hạn, chủ trì.

### 3.3 Tầng dự án
```
Overview · Roadmap · Boards · Work breakdown · Backlog*
WORK BOARDS       → các board model task / flow / dynamic_flow / issue
DOCUMENTS         → các board model doc / file
COSTS & CONTROLS  → Costs · Workloads · Issues* · Checkins · các board model cost / workload
People · Reports · Settings
```
`*` chỉ hiện khi bật ở Settings của dự án.

---

## 4. Tám model board

| Nhóm | Model | Mô tả trên màn hình | Dùng khi nào |
|---|---|---|---|
| **Plan** | **Cost Plan** | Planned budget & costs — linkable to tasks | Lập ngân sách theo dòng, theo dõi phần đã tiêu |
| | **Workload Plan** | Planned effort (hours/days) — linkable to tasks | Lập kế hoạch ngày công theo đội |
| **Work** | **Tasks** | Nestable tasks across stages, lists & a kanban | Công việc thông thường, 6 chế độ xem |
| | **Flow** | A delivery workflow — items advance through gated steps | Việc đi theo quy trình cố định, có duyệt và SLA |
| | **Dynamic Flow** `PREVIEW` | A dynamic task-flow (DAG, branching, approvals) | Quy trình có rẽ nhánh (bản xem trước) |
| | **Issue Board** | A register of realized problems, tracked as work items | Sổ rủi ro & sự cố |
| **Documents** | **Docs** | Notion-like rich pages — specs, notes, runbooks | Tài liệu dự án |
| | **Files** `MVP` | A registry of files & assets (link or upload) | Kho tệp và liên kết |

Mỗi board khai báo: **tên**, **code prefix** (sinh mã item dạng `DEV-001`, để trống thì tự chọn),
**màu**, và **phạm vi**: `Project-level` (kế thừa thành viên dự án) hoặc `Private` (chỉ người được thêm).

---

## 5. Chi tiết từng nhóm tính năng

### 5.1 Home — trang chủ ghép từ block
Nhiều tab, lưới 12 cột, kéo thả và đổi kích thước. Vào chế độ **Edit** → **Add Block**:

| Nhóm nguồn | Block | Kiểu hiển thị |
|---|---|---|
| **My Work** *(across the whole app, focused on you)* | My tasks · My overdue tasks · My projects | Data table · Chart |
| **Workspace** *(scoped to one workspace)* | Workspace projects · Modeling definitions | Data table · Chart |
| **Project** *(focused on a single project)* | Project tasks · Project issues · Project milestones | Data table · Chart |
| **Custom** | Custom HTML *(free-form rich content: notes, links, embeds)* | HTML |

Mỗi block cấu hình được tiêu đề, icon, bộ lọc (trạng thái, cửa sổ đến hạn, cách sắp xếp,
giới hạn dòng) và cách nhóm khi vẽ biểu đồ.

### 5.2 Projects — danh mục dự án
- **List**: vòng % tiến độ · tên + khoảng ngày · trạng thái · workspace · **thanh 5 đốt giai đoạn**
  kèm nhãn `3/5 Đang triển khai` · chủ trì · ngày cập nhật.
- **Card**: % lớn, `7/19 tasks`, nhãn đỏ `1 overdue`, thanh phân bố trạng thái, **thanh thời gian
  có chấm đánh dấu ngày hôm nay**.
- Lọc theo `All / Starred / từng workspace`, mỗi tab có số đếm.
- **New Project**: tên\* · workspace\* · giai đoạn khởi điểm · màu · icon · mô tả rich text ·
  ngày đến hạn.

### 5.3 Overview — trang tổng quan dự án
| Khối | Nội dung |
|---|---|
| About this project | Mô tả rich text |
| Progress | Total · In progress · Done · Overdue + thanh phân bố |
| Expected outcomes | *Definition of done*; mỗi kết quả có người chịu trách nhiệm và hạn |
| Milestones | Cột mốc + ngày; quá hạn hiện ⚠ và ngày đỏ |
| Work breakdown structure | Cây nhóm → gói, giờ công, trạng thái, tổng giờ và tỉ lệ gói xong |
| *(cột phải)* | Nhãn sức khoẻ + Update status · tóm tắt check-in mới nhất · ngày bắt đầu/kết thúc · Project roles · Recent activity |

### 5.4 Board Task — 6 chế độ xem
| Chế độ | Đặc điểm |
|---|---|
| **Table** | CODE · TASK · STATUS · STAGE · TYPE · TAGS · ASG · DUE · BY · UPDATED · WORKLOAD · COST |
| **List** | Nhóm theo lane, mỗi nhóm có **dòng tổng**: dải phân bố trạng thái, khoảng thời gian gộp, tổng giờ, tổng chi phí |
| **Board** | Kanban theo giai đoạn, kéo thả, `+ Add task` mỗi cột, `+ Add stage` |
| **Timeline** | Gantt cấp việc, thanh dài hiện mã việc |
| **Calendar** | Lịch tháng/tuần theo hạn, nút Today |
| **People** | Thẻ theo người: `1 open · 2 done` + danh sách việc |

**Manage view**: đặt tên view + bật/tắt cột (Status, Stage, Tags, Assignee, Due date,
Created by, Updated, Workload, Cost). *"The item name is always shown."*

**Trạng thái việc**: `Done` (xanh) · `Active` (xám) · `Overdue` (đỏ) · `Failed` (đỏ đậm).
Việc đã xong bị gạch ngang.

### 5.5 Panel chi tiết việc
Mở bằng cách bấm tên việc (`?item=<id>` trên URL). Gồm:
- Tiêu đề, Deadline + *Started on*, **Assigned by**.
- Điều khiển **trạng thái** và **người được giao**.
- **DESCRIPTION** · **SUB-ITEMS** (Enter để tạo).
- **RESOURCES & MATERIALS** → `+ Log resource` (vật tư/chi phí thực tế).
- **WORKLOADS** → `+ Log workload` (công thực tế), hiển thị số bản ghi và tổng công.
- **LINKED ISSUES** → `+ Log issue`.
- **Comments** — có đính kèm tệp, Edit / Delete, công tắc *Press enter to send*.
- Cột **DETAILS**: Linked stage · Tags · Linked milestone · Linked work package ·
  Owners · Followers · Created / Updated.

> **Phân biệt quan trọng**: **Assignee** (người được giao, một người) khác **Owner**
> (người sở hữu, nhiều người). Các màn hình *My works*, block *My tasks* và bảng
> *By assignee* trong Reports đều đọc theo **Assignee**.

### 5.6 Board Flow — luồng có cổng duyệt
Ba tab **Board · Table · Steps**.

Mô tả của chính ứng dụng ở màn hình Steps: *"Items advance through these steps in order.
**Active** steps hold work in progress; **Done / Failed** steps are terminal. A step's
**owners** gatekeep it — only they (or a project manager) confirm items in/out — and a
round-robin assignment draws from them. Each step can also set an SLA and what happens
to the assignee on entry."*

Mỗi bước khai báo:
| Thuộc tính | Giá trị |
|---|---|
| Loại (kind) | `Active` (đang xử lý) · `Done` · `Failed` — hai loại sau là bước kết thúc |
| Người gác cổng (owners) | Chỉ họ hoặc quản lý dự án mới xác nhận item vào/ra |
| SLA | Tính theo ngày, hiển thị trên đầu cột và đếm ngược trên thẻ (`Due in 23h`) |
| Cách giao việc | `Keep assignee` · `Manual pick` · `Round-robin` |
| Quay lui | Cho phép trả về bước trước kèm lý do |

Thẻ trên chế độ Board: mã item, tên, trích mô tả, và hoặc huy hiệu cam **Pending assignment**
+ nút **Assign**, hoặc avatar người xử lý + đồng hồ đếm ngược.

### 5.7 Work breakdown structure (WBS)
Hai cấp **Work plan** (nhóm) → **Work package** (gói). Mỗi gói có giờ công, người phụ trách và
trạng thái `Planned` / `In progress` / `Done`. Giờ công cộng dồn từ gói lên nhóm lên dự án.
Thanh tổng: `1432h · 1 Done · 9 In Progress · 4 Planned · 1/10 packages`.

Panel chi tiết một nút: nhãn loại, trạng thái, tổng giờ, người phụ trách, nút
`+ Work plan / + Work package / Edit / Remove`, danh sách gói con kèm tiến độ, Created by, Updated.

Công việc trên board Task gắn được vào một gói WBS (trường *Linked work package*).

### 5.8 Chi phí và nhân lực
Hai màn hình song song, cấu trúc giống nhau:

| Tab | Nội dung |
|---|---|
| **Plannings** | Dòng kế hoạch: NAME (+ mô tả) · UNIT · **PLANNED** · ROLLUP · **BOOKED** (số + %) |
| **Bookings** | Bản ghi tiêu thụ thực tế, gom theo **board đã tiêu thụ** rồi theo **loại chi phí / loại nhân sự**, kèm QUANTITY và COST |

Ba trạng thái dòng kế hoạch: `Planned` · `Approved` · `Rejected` (khoản bị từ chối vẫn lưu kèm lý do).
Ba số lớn đầu trang: Total cost / Total effort · số bookings · số board.

**Cách số liệu chạy**: khai dòng kế hoạch trên board Cost Plan / Workload Plan → khi làm việc,
người thực hiện bấm `Log resource` / `Log workload` trong panel việc → bản ghi trừ vào đúng dòng
kế hoạch và gắn với đúng công việc → trang Costs, Workloads và Reports cập nhật tức thì.

### 5.9 Issues — sổ rủi ro và sự cố
| Trường | Giá trị |
|---|---|
| Mã | Tự sinh theo prefix board (`RUI-006`) |
| Loại | Item type nhóm Issue |
| **Severity** | `Low` · `Medium` · `High` · `Critical` |
| **Status** | `Open` · `Investigating` · `On hold` · `Resolved` · `Won't fix` |
| Owner / Assignee / Due | Người phụ trách, người xử lý, hạn |

Loại issue khai báo ở Settings ▸ Item types với **Probability** (1 = rare → 5 = near-certain),
**Impact** (1 = negligible → 5 = severe), **Severity** tự tính (*P × I, derived*) và
**Response strategy**: `Avoid` · `Mitigate` · `Transfer` · `Accept`.

### 5.10 Backlog
Hai cấp **Epic → User Story**. Mỗi mục có: điểm ước lượng (PTS), mức ưu tiên
(`High` / `Medium` / `Low`), **số phiếu bình chọn**, tiêu chí chấp nhận (hiển thị `0/3`), người
phụ trách. Hai chế độ **List | Board**; sắp xếp theo **Rank · Priority · Votes · Recent**.
Giai đoạn backlog cấu hình riêng cho từng dự án, mỗi giai đoạn có người gác cổng.

### 5.11 Roadmap
Gantt hai vùng: **PHASE** (thanh ngang, *độ tô đầy = tiến độ*, nhãn %) và **MILESTONES**
(hình thoi trên trục thời gian). Đường kẻ dọc **Today**. Bộ chuyển **Month | Week**.
Chú giải: *Phase bar (fill = progress)* · *Milestone checkpoint* · *Today* ·
*Drag a bar's edge to adjust its dates*.

### 5.12 Reports
| Khối | Nội dung |
|---|---|
| 6 thẻ chỉ số | COMPLETION · SCHEDULE (`98d left`, `% elapsed`) · MILESTONES · COST (đã đặt chỗ / tổng ngân sách) · EFFORT · ISSUES |
| WORK PROGRESS | Status distribution · Work by board · Work by type |
| Throughput | Đường 12 tuần: **Completed** vs **Created** |
| By assignee | ASSIGNEE · TOTAL · DONE · OPEN · OVERDUE · PROGRESS |
| SCHEDULE | Bảng cột mốc (`Done` / `Overdue` / `Upcoming`) + dãy chip WBS |
| BUDGET & EFFORT | Hai biểu đồ cột kế hoạch so với đã dùng |

Tiêu đề ghi rõ **live snapshot** — không cần bấm làm mới.

### 5.13 Check-in
Hộp thoại **Update status**:
| Trường | Giá trị |
|---|---|
| **Status \*** | `On track` (xanh) · `At risk` (cam) · `Off track` (đỏ) |
| **Progress** | Thanh trượt 0–100%, *"Completion at this point in time."* |
| **Summary** | Rich text, *"What changed, blockers, what's next."* |
| **What has been done?** | Danh sách đánh số, kéo đổi thứ tự |
| **What are blockers?** | Danh sách đánh số |

Trang **Checkins** hiển thị thẻ *CURRENT STATUS* và dòng thời gian các lần check-in.

### 5.14 Templates
4 mẫu dựng sẵn (nhãn `BUILT-IN`): **Software Project** (engineering) · **Construction Project**
(construction) · **Marketing Campaign** (marketing) · **Event Plan** (events).
Thao tác: **Use template** (đặt tên + chọn workspace) · **From project** (lưu dự án đang chạy
thành mẫu) · **Import** (nạp từ tệp) · biểu tượng tải xuống (xuất mẫu).

Mẫu mang theo: cấu trúc board (lane, giai đoạn, việc mẫu), WBS kèm giờ công, cột mốc theo số ngày
lệch, các pha roadmap, khung dòng chi phí và nhân lực. Mẫu **không** mang theo người phụ trách,
mô tả chi tiết hay bình luận.

### 5.15 Settings tầng công ty
| Pane | Nội dung |
|---|---|
| **Workspaces** | Danh sách + `New Workspace`. Hộp thoại sửa có 3 mục: **General** (tên, màu huy hiệu, mô tả) · **Stages** (kéo đổi thứ tự, đổi tên/màu, thêm/xoá — mỗi thay đổi tự lưu) · **Danger zone** (*Removing … archives it and hides its projects from the app. Projects themselves are not deleted.*) |
| **Projects** | Bản sao trang /projects |
| **Item types** | 5 nhóm loại — xem bảng dưới |
| **Extra settings** | Thẻ công ty, thẻ người dùng, About (chỉ đọc) |

**Item types — trường theo từng nhóm**
| Nhóm | Trường riêng |
|---|---|
| Task / Backlog | *(chỉ có)* Name\* · Color · Icon · Description |
| **Issue** | + Probability (1–5) · Impact (1–5) · **Severity** (P × I, chỉ đọc) · Response strategy · Status |
| **Cost / Workload** | + **Unit** (*"Realized costs inherit this unit."*) · **Rate** (*"Templated unit cost."*) · **Currency** (ISO) |

28 icon dựng sẵn: folder, code, megaphone, gauge, users, rocket, zap, smartphone, search,
trendingdown, palette, edit, mail, bookopen, shield, building, package, userplus, message,
lifebuoy, helpcircle, sparkles, target, checklist, bug, flask, boxes, wrench.

### 5.16 Settings tầng dự án
| Khối | Nội dung |
|---|---|
| **Enabled features** | Work breakdown structure · Backlog · Issues · Costs · Workloads. *"Disabled sections are hidden from the sidebar (their data is kept, never deleted) and can be re-enabled any time."* |
| **Measure & currency** | **Workload unit** (Days \| Hours) và **Currency** (ISO). Đơn vị này quyết định cách cộng dồn công trên toàn dự án |
| **Backlog stages** | Danh sách giai đoạn backlog; mỗi giai đoạn có **owners** là người gác cổng; một giai đoạn được đánh dấu `Done` |

---

## 6. Thuật ngữ

| Thuật ngữ trên giao diện | Nghĩa nghiệp vụ |
|---|---|
| **Workspace** | Khối / phòng ban; có pipeline giai đoạn dự án riêng |
| **Pipeline stage** | Giai đoạn trong vòng đời dự án (cột kanban ở trang workspace) |
| **Board** | Không gian làm việc con trong dự án, chọn 1 trong 8 model |
| **Board model** | Kiểu board: Tasks / Flow / Issue / Docs / Files / Cost Plan / Workload Plan / Dynamic Flow |
| **Scope** (của board) | `Project-level` kế thừa thành viên dự án; `Private` chỉ người được thêm |
| **Code prefix** | Tiền tố sinh mã item, ví dụ `DEV-001`, `RUI-006`, `YC-005` |
| **Stage** | Cột trạng thái trên board Task |
| **Tasklist** | Lane / nhóm việc trên board Task |
| **Step** | Bước trên board Flow, có loại, người gác cổng và SLA |
| **Assignee** | Người được giao việc (một người) |
| **Owner** | Người sở hữu việc / nút WBS / issue (nhiều người) |
| **Work plan / Work package** | Nhóm và gói trong cấu trúc phân rã công việc |
| **Outcome** | Định nghĩa hoàn thành của cả dự án |
| **Milestone** | Cột mốc, có danh sách deliverable |
| **Plan line** | Một dòng ngân sách hoặc một dòng kế hoạch nhân lực |
| **Booking** | Bản ghi tiêu thụ thực tế trừ vào một plan line |
| **Log resource / Log workload** | Thao tác ghi nhận chi phí / công thực tế từ panel công việc |
| **Check-in** | Báo cáo tiến độ định kỳ với nhãn On track / At risk / Off track |
| **Item type** | Loại đối tượng dùng chung cấp công ty (5 nhóm) |

---

## 7. Câu hỏi thường gặp

**Một dự án bắt buộc phải có đủ mọi tính năng không?**
Không. Settings của dự án có 5 công tắc (WBS, Backlog, Issues, Costs, Workloads). Tắt mục nào
thì mục đó biến mất khỏi thanh bên, dữ liệu vẫn giữ nguyên và bật lại được bất cứ lúc nào.

**Khác nhau giữa WBS và danh sách công việc?**
WBS mô tả **phạm vi** (dự án gồm những hạng mục gì, nặng bao nhiêu giờ), danh sách công việc mô tả
**thực thi** (ai làm gì, khi nào). Chính màn hình ghi rõ: *"Deliverables & work packages — scope,
not tasks."* Một việc gắn được vào một gói WBS để đối chiếu hai bên.

**Khi nào dùng board Tasks, khi nào dùng board Flow?**
Tasks cho công việc tự do, mỗi việc đi theo nhịp riêng. Flow cho việc đi theo **một quy trình cố
định có người gác cổng và SLA từng bước** — yêu cầu khách hàng, đề nghị nội bộ, hồ sơ cần duyệt.

**Chi phí ghi ở đâu?**
Hai lớp. Lớp kế hoạch: dòng ngân sách trên board Cost Plan. Lớp thực tế: bấm `Log resource` trong
panel công việc, khoản chi trừ thẳng vào dòng kế hoạch và gắn với công việc đã tiêu thụ nó.
Trang Costs ▸ Plannings hiển thị phần trăm đã tiêu của từng dòng.

**Báo cáo có phải tự dựng không?**
Không. Mỗi dự án có sẵn trang Reports với 6 chỉ số, 5 biểu đồ và 2 bảng, cập nhật theo thời gian
thực (*live snapshot*). Ngoài ra người dùng tự ghép trang Home riêng từ các block.

**Ai nhìn thấy gì?**
Board đặt `Project-level` thì mọi thành viên dự án thấy; đặt `Private` thì chỉ người được thêm.
Ở cấp dự án phân hai vai: **Project managers** và **Members**.

**Có dùng lại cấu trúc dự án được không?**
Có. Lưu bất kỳ dự án đang chạy nào thành mẫu bằng **From project**, hoặc dùng 4 mẫu dựng sẵn.
Mẫu xuất ra tệp và nhập vào tenant khác được.

**Đơn vị tính công là giờ hay ngày?**
Đặt ở Settings của từng dự án (Days hoặc Hours). Loại nhân sự trong Item types cũng có trường
Unit riêng — hai chỗ này phải khớp nhau, nếu không hệ thống báo lỗi khi ghi nhận công.

---

## 8. Hạn chế ghi nhận được trong quá trình khảo sát

Ba điểm dưới đây quan sát trực tiếp trên ứng dụng, không ảnh hưởng số liệu, chỉ ảnh hưởng cách
hiển thị:

1. **Board Cost Plan / Workload Plan liệt kê bản ghi của toàn hệ thống.** Màn hình board kế hoạch
   hiện ra 58 dòng thuộc 9 dự án khác nhau, trong đó 41 dòng là bản ghi *workload* hiển thị nhầm
   với giá trị `USD 0`. → Khi trình diễn nên dùng màn hình **Costs** và **Workloads** ở cấp dự án,
   hai màn hình này lọc đúng.
2. **Cột Cost trên lưới board Task hiển thị `USD`** kể cả khi dự án đặt đơn vị tiền là VND.
   Trang Costs và Reports hiển thị đúng ký hiệu `₫`.
3. **Đổi tên dự án không cập nhật tên đã lưu kèm** trong board và trong công việc tạo trước đó,
   nên màn hình *My works* có thể hiện tên dự án cũ. Khắc phục bằng cách tạo lại board/công việc.

Ngoài ra: chuyển nhanh giữa các tab view của board Task đôi lúc hiện toast đỏ `Unknown view`
(đổi tab lại là hết); tiêu đề mục WORKLOADS trong panel việc ghi tổng bằng `h` trong khi dòng chi
tiết ghi theo đơn vị của dự án; dãy chip WBS trong Reports báo `0 work packages` trong khi trang
Work breakdown của cùng dự án hiển thị đủ số gói.

---

*Nguồn: khảo sát trực tiếp 49 màn hình trên `cowork.base.com.vn` ngày 23–24/08/2026. Không sử
dụng tài liệu giới thiệu, help center hay bất kỳ nguồn web nào.*
